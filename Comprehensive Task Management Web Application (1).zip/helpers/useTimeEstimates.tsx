import { useCallback } from 'react';
import { useTaskStorage, Task } from './TaskStorage';

export type Size = 'small' | 'medium' | 'large';
export type Priority = 'low' | 'medium' | 'high';
export type Complexity = 'low' | 'medium' | 'high';

export type EmotionalWeight = 'none' | 'minimal' | 'significant';
export type MentalComplexity = 'easy' | 'moderate' | 'complex';

export interface Progress {
  completedMinutes: number;
  totalMinutes: number;
  percent: number;
}

export interface EstimateAnalysis {
  totalEstimated: number;
  averageEstimate: number;
  tasksWithEstimates: number;
}

/**
 * Recursively sums estimatedMinutes for a task and its subtasks.
 */
export const calculateTotalEstimate = (task: Task): number => {
  const self = task.estimatedMinutes ?? 0;
  const subs = task.subtasks?.reduce((sum, st) => sum + calculateTotalEstimate(st), 0) ?? 0;
  return self + subs;
};

/**
 * Recursively sums estimatedMinutes of completed tasks/subtasks.
 */
export const calculateCompletedEstimate = (task: Task): number => {
  let sum = 0;
  if (task.completed && task.estimatedMinutes) {
    sum += task.estimatedMinutes;
  }
  if (task.subtasks) {
    sum += task.subtasks.reduce((s, st) => s + calculateCompletedEstimate(st), 0);
  }
  return sum;
};

/**
 * Formats minutes into "Xh Ym" or "Ym" string.
 */
export const formatTime = (totalMinutes: number): string => {
  const minutes = Math.max(0, Math.trunc(totalMinutes));
  const hrs = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hrs > 0 && mins > 0) {
    return `${hrs}h ${mins}m`;
  }
  if (hrs > 0) {
    return `${hrs}h`;
  }
  return `${mins}m`;
};

/**
 * Suggest a base estimate from task size (legacy).
 */
export const suggestBasedOnSize = (size: Size): number => {
  switch (size) {
    case 'small':
      return 15;
    case 'medium':
      return 45;
    case 'large':
      return 120;
  }
};

/**
 * Suggest a base estimate from emotionalWeight.
 */
export const suggestBasedOnEmotionalWeight = (weight: EmotionalWeight): number => {
  switch (weight) {
    case 'none':
      return 15;
    case 'minimal':
      return 45;
    case 'significant':
      return 120;
  }
};

/**
 * Factor adjustment by priority.
 */
export const priorityFactor = (priority: Priority): number => {
  switch (priority) {
    case 'low':
      return 0.9;
    case 'medium':
      return 1;
    case 'high':
      return 1.1;
  }
};

/**
 * Factor adjustment by complexity (legacy).
 */
export const complexityFactor = (complexity: Complexity): number => {
  switch (complexity) {
    case 'low':
      return 0.8;
    case 'medium':
      return 1;
    case 'high':
      return 1.2;
  }
};

/**
 * Factor adjustment by mentalComplexity.
 */
export const mentalComplexityFactor = (mc: MentalComplexity): number => {
  switch (mc) {
    case 'easy':
      return 0.8;
    case 'moderate':
      return 1;
    case 'complex':
      return 1.2;
  }
};

export interface SuggestOptions {
  // New primary fields:
  emotionalWeight?: EmotionalWeight;
  mentalComplexity?: MentalComplexity;
  // Backward-compatibility:
  size?: Size;
  complexity?: Complexity;
  priority: Priority;
}

/**
 * Suggests an estimate in minutes combining emotionalWeight (or legacy size),
 * priority, and mentalComplexity (or legacy complexity).
 */
export const suggestTime = ({
  emotionalWeight,
  size,
  priority,
  mentalComplexity,
  complexity,
}: SuggestOptions): number => {
  const base = emotionalWeight
    ? suggestBasedOnEmotionalWeight(emotionalWeight)
    : size
    ? suggestBasedOnSize(size)
    : 0;
  const pF = priorityFactor(priority);
  const mCF = mentalComplexity
    ? mentalComplexityFactor(mentalComplexity)
    : complexity
    ? complexityFactor(complexity)
    : 1;
  return Math.round(base * pF * mCF);
};

/**
 * Given a task, returns completed vs total estimate and percentage done.
 */
export const trackProgress = (task: Task): Progress => {
  const total = calculateTotalEstimate(task);
  const done = calculateCompletedEstimate(task);
  const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
  return { completedMinutes: done, totalMinutes: total, percent: pct };
};

/**
 * Analyze all tasks for total, average, and count of tasks with estimates.
 */
export const analyzeEstimates = (tasks: Task[]): EstimateAnalysis => {
  let total = 0;
  let count = 0;
  tasks.forEach((t) => {
    if (t.estimatedMinutes != null) {
      total += t.estimatedMinutes;
      count += 1;
    }
    if (t.subtasks) {
      const sub = analyzeEstimates(t.subtasks);
      total += sub.totalEstimated;
      count += sub.tasksWithEstimates;
    }
  });
  const avg = count > 0 ? Math.round(total / count) : 0;
  return { totalEstimated: total, averageEstimate: avg, tasksWithEstimates: count };
};

/**
 * React hook to manage and compute time estimates for tasks.
 */
export const useTimeEstimates = () => {
  const { tasks, updateTask } = useTaskStorage();

  const totalEstimate = useCallback(
    (task: Task) => calculateTotalEstimate(task),
    []
  );

  const formatted = useCallback((mins: number) => formatTime(mins), []);

  const suggest = useCallback(
    (opts: SuggestOptions) => suggestTime(opts),
    []
  );

  const progress = useCallback((task: Task) => trackProgress(task), []);

  const addEstimate = useCallback(
    (taskId: string, minutes: number) => {
      updateTask(taskId, { estimatedMinutes: minutes });
    },
    [updateTask]
  );

  const updateEstimate = useCallback(
    (taskId: string, minutes: number) => {
      updateTask(taskId, { estimatedMinutes: minutes });
    },
    [updateTask]
  );

  const removeEstimate = useCallback(
    (taskId: string) => {
      updateTask(taskId, { estimatedMinutes: undefined });
    },
    [updateTask]
  );

  const analyzeAll = useCallback(() => analyzeEstimates(tasks), [tasks]);

  return {
    // utilities
    totalEstimate,
    formatTime: formatted,
    suggestTime: suggest,
    trackProgress: progress,
    analyzeEstimates: analyzeAll,
    // CRUD on estimates
    addEstimate,
    updateEstimate,
    removeEstimate,
    // data
    tasks,
  };
};