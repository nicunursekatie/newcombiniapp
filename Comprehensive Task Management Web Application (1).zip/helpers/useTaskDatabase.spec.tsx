import React, { useState, useEffect } from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { useTaskDatabase } from './useTaskDatabase';
import * as tasksApi from '../endpoints/tasks_GET.schema';
import * as tasksPostApi from '../endpoints/tasks_POST.schema';
import * as projectsApi from '../endpoints/projects_GET.schema';
import * as categoriesApi from '../endpoints/categories_GET.schema';
import * as clearApi from '../endpoints/tasks/clearCompleted_POST.schema';
import * as deleteProjectApi from '../endpoints/projects/delete_POST.schema';
import * as deleteCategoryApi from '../endpoints/categories/delete_POST.schema';

describe('useTaskDatabase', () => {
  it('fetches and loads tasks, projects, and categories', async () => {
    const mockTasks = [
      {
        id: '1',
        title: 'Task1',
        dueDate: null,
        status: 'completed',
        parentId: null,
        projectId: null,
        project: null,
        categories: [],
        tasks: [],
        archived: false,
      },
    ];
    const mockProjects = [{ id: 'p1', name: 'Proj1', description: null }];
    const mockCategories = [{ id: 'c1', name: 'Cat1', color: 'red' }];

    spyOn(tasksApi, 'getTasks').and.returnValue(Promise.resolve(mockTasks));
    spyOn(projectsApi, 'getProjects').and.returnValue(Promise.resolve(mockProjects));
    spyOn(categoriesApi, 'getCategories').and.returnValue(Promise.resolve(mockCategories));

    const TestComp = () => {
      const { isLoaded, tasks, projects, categories } = useTaskDatabase();
      if (!isLoaded) return <>Loading</>;
      return (
        <>
          <span data-testid="tasks">{tasks.map(t => t.title).join(',')}</span>
          <span data-testid="projects">{projects.map(p => p.title).join(',')}</span>
          <span data-testid="categories">{categories.map(c => c.title).join(',')}</span>
        </>
      );
    };

    render(<TestComp />);
    await waitFor(() => {
      if (!screen.queryByTestId('tasks')) throw new Error('not loaded yet');
    });
    expect(screen.getByTestId('tasks').textContent).toBe('Task1');
    expect(screen.getByTestId('projects').textContent).toBe('Proj1');
    expect(screen.getByTestId('categories').textContent).toBe('Cat1');
  });

  it('assigns a category to multiple tasks', async () => {
    const mockTasks = [
      {
        id: '1',
        title: 'Task1',
        dueDate: null,
        status: 'pending',
        parentId: null,
        projectId: null,
        project: null,
        categories: [],
        tasks: [],
        archived: false,
      },
      {
        id: '2',
        title: 'Task2',
        dueDate: null,
        status: 'completed',
        parentId: null,
        projectId: null,
        project: null,
        categories: [],
        tasks: [],
        archived: false,
      },
    ];
    const mockProjects = [{ id: 'p1', name: 'Proj1', description: null }];
    const mockCategories = [{ id: 'c1', name: 'Cat1', color: 'red' }];

    spyOn(tasksApi, 'getTasks').and.returnValue(Promise.resolve(mockTasks));
    spyOn(projectsApi, 'getProjects').and.returnValue(Promise.resolve(mockProjects));
    spyOn(categoriesApi, 'getCategories').and.returnValue(Promise.resolve(mockCategories));

    spyOn(tasksPostApi, 'postTask').and.callFake(async (payload: any) => {
      const cats = payload.categories ?? [];
      return {
        id: payload.id!,
        title: payload.title,
        dueDate: payload.dueDate ?? null,
        status: payload.status,
        parentId: payload.parentId ?? null,
        projectId: payload.projectId ?? null,
        project: null,
        categories: cats.map((cid: string) => ({
          id: cid,
          name: 'Cat1',
          color: 'red',
        })),
        tasks: [],
        archived: false,
      };
    });

    const TestComp = () => {
      const { isLoaded, tasks, assignCategoryToTasks } = useTaskDatabase();
      const [done, setDone] = useState(false);

      useEffect(() => {
        if (isLoaded && !done) {
          assignCategoryToTasks(['1', '2'], 'c1').then(() => {
            setDone(true);
          });
        }
      }, [isLoaded, done, assignCategoryToTasks]);

      if (!isLoaded) return <>Loading</>;
      if (!done) return <>Assigning</>;

      return (
        <span data-testid="assigned">
          {tasks.map(t => `${t.id}:${t.categoryId}`).join(',')}
        </span>
      );
    };

    render(<TestComp />);
    await waitFor(() => {
      if (!screen.queryByTestId('assigned')) throw new Error('not assigned yet');
    });
    expect(screen.getByTestId('assigned').textContent).toBe('1:c1,2:c1');
  });

  it('clears completed tasks and refreshes tasks', async () => {
    const initialTasks = [
      {
        id: '1',
        title: 'DoneTask',
        dueDate: null,
        status: 'completed',
        parentId: null,
        projectId: null,
        project: null,
        categories: [],
        tasks: [],
        archived: false,
      },
      {
        id: '2',
        title: 'PendingTask',
        dueDate: null,
        status: 'pending',
        parentId: null,
        projectId: null,
        project: null,
        categories: [],
        tasks: [],
        archived: false,
      },
    ];
    const updatedTasks = [
      {
        id: '2',
        title: 'PendingTask',
        dueDate: null,
        status: 'pending',
        parentId: null,
        projectId: null,
        project: null,
        categories: [],
        tasks: [],
        archived: false,
      },
    ];
    spyOn(projectsApi, 'getProjects').and.returnValue(Promise.resolve([]));
    spyOn(categoriesApi, 'getCategories').and.returnValue(Promise.resolve([]));
    let callCount = 0;
    spyOn(tasksApi, 'getTasks').and.callFake(() => {
      callCount++;
      return Promise.resolve(callCount === 1 ? initialTasks : updatedTasks);
    });
    spyOn(clearApi, 'postClearCompleted').and.returnValue(
      Promise.resolve({ success: true, message: '', tasksAffected: 1, taskIds: ['1'] })
    );

    const TestComp = () => {
      const { isLoaded, tasks, clearCompleted } = useTaskDatabase();
      const [done, setDone] = useState(false);

      useEffect(() => {
        if (isLoaded && !done) {
          clearCompleted().then(() => setDone(true));
        }
      }, [isLoaded, done, clearCompleted]);

      if (!isLoaded) return <>Loading</>;
      if (!done) return <>Clearing</>;

      return (
        <span data-testid="remaining">
          {tasks.map(t => t.id).join(',')}
        </span>
      );
    };

    render(<TestComp />);
    await waitFor(() => {
      if (!screen.queryByTestId('remaining')) throw new Error('not cleared yet');
    });
    expect(screen.getByTestId('remaining').textContent).toBe('2');
  });

  it('updates a task status via updateTask', async () => {
    const initialTasks = [
      {
        id: '1',
        title: 'Task1',
        dueDate: null,
        status: 'pending',
        parentId: null,
        projectId: null,
        project: null,
        categories: [],
        tasks: [],
        archived: false,
      },
      {
        id: '2',
        title: 'Task2',
        dueDate: null,
        status: 'pending',
        parentId: null,
        projectId: null,
        project: null,
        categories: [],
        tasks: [],
        archived: false,
      },
    ];
    const mockProjects = [{ id: 'p1', name: 'Proj1', description: null }];
    const mockCategories = [{ id: 'c1', name: 'Cat1', color: 'red' }];

    spyOn(tasksApi, 'getTasks').and.returnValue(Promise.resolve(initialTasks));
    spyOn(projectsApi, 'getProjects').and.returnValue(Promise.resolve(mockProjects));
    spyOn(categoriesApi, 'getCategories').and.returnValue(Promise.resolve(mockCategories));

    spyOn(tasksPostApi, 'postTask').and.callFake(async (payload: any) => ({
      id: payload.id,
      title: payload.title,
      dueDate: payload.dueDate ?? null,
      status: payload.status,
      parentId: payload.parentId ?? null,
      projectId: payload.projectId ?? null,
      project: null,
      categories: [],
      tasks: [],
      archived: false,
    }));

    const TestComp = () => {
      const { isLoaded, tasks, updateTask } = useTaskDatabase();
      const [done, setDone] = useState(false);

      useEffect(() => {
        if (isLoaded && !done) {
          updateTask('1', { completed: true }).then(() => setDone(true));
        }
      }, [isLoaded, done, updateTask]);

      if (!isLoaded) return <>Loading</>;
      if (!done) return <>Updating</>;

      return (
        <span data-testid="updated">
          {tasks.map(t => `${t.id}:${t.completed}`).join(',')}
        </span>
      );
    };

    render(<TestComp />);
    await waitFor(() => {
      if (!screen.queryByTestId('updated')) throw new Error('not updated yet');
    });
    expect(screen.getByTestId('updated').textContent).toBe('1:true,2:false');
  });

  it('deletes a project via deleteProject', async () => {
    const mockTasks: any[] = [];
    const mockProjects = [
      { id: 'p1', name: 'Proj1', description: null },
      { id: 'p2', name: 'Proj2', description: 'desc2' },
    ];
    const mockCategories: any[] = [];

    spyOn(tasksApi, 'getTasks').and.returnValue(Promise.resolve(mockTasks));
    spyOn(projectsApi, 'getProjects').and.returnValue(Promise.resolve(mockProjects));
    spyOn(categoriesApi, 'getCategories').and.returnValue(Promise.resolve(mockCategories));
    spyOn(deleteProjectApi, 'deleteProject').and.returnValue(
      Promise.resolve({ success: true, message: 'deleted' })
    );

    const TestComp = () => {
      const { isLoaded, projects, deleteProject } = useTaskDatabase();
      const [done, setDone] = useState(false);

      useEffect(() => {
        if (isLoaded && !done) {
          deleteProject('p1').then(() => setDone(true));
        }
      }, [isLoaded, done, deleteProject]);

      if (!isLoaded) return <>Loading</>;
      if (!done) return <>Deleting</>;

      return (
        <span data-testid="remaining-projects">
          {projects.map(p => p.id).join(',')}
        </span>
      );
    };

    render(<TestComp />);
    await waitFor(() => {
      if (!screen.queryByTestId('remaining-projects')) throw new Error('not deleted yet');
    });
    expect(screen.getByTestId('remaining-projects').textContent).toBe('p2');
  });

  it('deletes a category via deleteCategory', async () => {
    const mockTasks: any[] = [];
    const mockProjects: any[] = [];
    const mockCategories = [
      { id: 'c1', name: 'Cat1', color: 'red' },
      { id: 'c2', name: 'Cat2', color: 'blue' },
    ];

    spyOn(tasksApi, 'getTasks').and.returnValue(Promise.resolve(mockTasks));
    spyOn(projectsApi, 'getProjects').and.returnValue(Promise.resolve(mockProjects));
    spyOn(categoriesApi, 'getCategories').and.returnValue(Promise.resolve(mockCategories));
    spyOn(deleteCategoryApi, 'deleteCategory').and.returnValue(
      Promise.resolve({ success: true, message: 'deleted' })
    );

    const TestComp = () => {
      const { isLoaded, categories, deleteCategory } = useTaskDatabase();
      const [done, setDone] = useState(false);

      useEffect(() => {
        if (isLoaded && !done) {
          deleteCategory('c1').then(() => setDone(true));
        }
      }, [isLoaded, done, deleteCategory]);

      if (!isLoaded) return <>Loading</>;
      if (!done) return <>Deleting</>;

      return (
        <span data-testid="remaining-categories">
          {categories.map(c => c.id).join(',')}
        </span>
      );
    };

    render(<TestComp />);
    await waitFor(() => {
      if (!screen.queryByTestId('remaining-categories')) throw new Error('not deleted yet');
    });
    expect(screen.getByTestId('remaining-categories').textContent).toBe('c2');
  });
});