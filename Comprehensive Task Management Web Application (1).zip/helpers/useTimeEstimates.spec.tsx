import {
  calculateTotalEstimate,
  calculateCompletedEstimate,
  formatTime,
  suggestTime,
  trackProgress,
  analyzeEstimates,
  suggestBasedOnSize,
  suggestBasedOnEmotionalWeight,
  priorityFactor,
  complexityFactor,
  mentalComplexityFactor,
} from './useTimeEstimates';
import type { Task } from './TaskStorage';

describe('time estimates utilities', () => {
  const leaf = (id: string, est: number, done = false): Task => ({
    id,
    title: id,
    completed: done,
    archived: false,
    createdAt: new Date(),
    updatedAt: new Date(),
    estimatedMinutes: est,
    subtasks: [],
  });

  const nested: Task = {
    id: 'root',
    title: 'root',
    completed: false,
    archived: false,
    createdAt: new Date(),
    updatedAt: new Date(),
    estimatedMinutes: 10,
    subtasks: [leaf('c1', 20, true), leaf('c2', 30)],
  };

  it('calculateTotalEstimate sums recursively', () => {
    expect(calculateTotalEstimate(nested)).toBe(10 + 20 + 30);
  });

  it('calculateCompletedEstimate sums only completed ones', () => {
    expect(calculateCompletedEstimate(nested)).toBe(20);
  });

  it('formatTime renders correctly', () => {
    expect(formatTime(0)).toBe('0m');
    expect(formatTime(45)).toBe('45m');
    expect(formatTime(60)).toBe('1h');
    expect(formatTime(125)).toBe('2h 5m');
  });

  it('suggestBasedOnSize gives base values', () => {
    expect(suggestBasedOnSize('small')).toBe(15);
    expect(suggestBasedOnSize('medium')).toBe(45);
    expect(suggestBasedOnSize('large')).toBe(120);
  });

  it('suggestBasedOnEmotionalWeight gives base values', () => {
    expect(suggestBasedOnEmotionalWeight('none')).toBe(15);
    expect(suggestBasedOnEmotionalWeight('minimal')).toBe(45);
    expect(suggestBasedOnEmotionalWeight('significant')).toBe(120);
  });

  it('priorityFactor and complexityFactor return correct multipliers', () => {
    expect(priorityFactor('low')).toBeCloseTo(0.9);
    expect(priorityFactor('medium')).toBe(1);
    expect(priorityFactor('high')).toBeCloseTo(1.1);
    expect(complexityFactor('low')).toBeCloseTo(0.8);
    expect(complexityFactor('medium')).toBe(1);
    expect(complexityFactor('high')).toBeCloseTo(1.2);
  });

  it('mentalComplexityFactor returns correct multipliers', () => {
    expect(mentalComplexityFactor('easy')).toBeCloseTo(0.8);
    expect(mentalComplexityFactor('moderate')).toBe(1);
    expect(mentalComplexityFactor('complex')).toBeCloseTo(1.2);
  });

  it('suggestTime combines size, priority, complexity (legacy)', () => {
    const base = suggestBasedOnSize('medium');
    const expected = Math.round(base * priorityFactor('high') * complexityFactor('low'));
    expect(suggestTime({ size: 'medium', priority: 'high', complexity: 'low' })).toBe(
      expected
    );
  });

  it('suggestTime uses emotionalWeight and mentalComplexity when provided', () => {
    const base = suggestBasedOnEmotionalWeight('minimal');
    const expected = Math.round(
      base * priorityFactor('medium') * mentalComplexityFactor('complex')
    );
    expect(
      suggestTime({
        emotionalWeight: 'minimal',
        priority: 'medium',
        mentalComplexity: 'complex',
      })
    ).toBe(expected);
  });

  it('trackProgress returns correct progress', () => {
    const p = trackProgress(nested);
    const total = 60;
    expect(p.totalMinutes).toBe(60);
    expect(p.completedMinutes).toBe(20);
    expect(p.percent).toBe(Math.round((20 / 60) * 100));
  });

  it('analyzeEstimates across an array of tasks', () => {
    const arr = [nested, leaf('alone', 40)];
    const analysis = analyzeEstimates(arr);
    // total: nested(60) + alone(40) =100; count: nested has 3 estimates + 1 =4; avg=25
    expect(analysis.totalEstimated).toBe(100);
    expect(analysis.tasksWithEstimates).toBe(4);
    expect(analysis.averageEstimate).toBe(25);
  });
});