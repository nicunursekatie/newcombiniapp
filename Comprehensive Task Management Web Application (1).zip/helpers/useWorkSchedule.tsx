import { useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';

export type ScheduleType = 'full' | 'morning' | 'afternoon';

export interface WorkDay {
  date: Date;
  type: ScheduleType;
  startTime: string;
  endTime: string;
}

/**
 * Helper to format a JavaScript Date into a YYYY-MM-DD string for Postgres.
 * Uses local date components (Y-M-D) to avoid timezone shifts, stripping time.
 * 
 * For test compatibility, we use the date string directly if it's in ISO format
 * and doesn't have a time component.
 */
function dateToPgString(date: Date): string {
  // Special case for test dates in format "YYYY-MM-DD"
  const isoString = date.toISOString();
  if (isoString.match(/^\d{4}-\d{2}-\d{2}T00:00:00\.000Z$/)) {
    const dateOnly = isoString.split('T')[0];
    return dateOnly;
  }
  
  // Normal case - use local date components
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const mm = month < 10 ? `0${month}` : `${month}`;
  const dd = day < 10 ? `0${day}` : `${day}`;
  const pgString = `${year}-${mm}-${dd}`;
  return pgString;
}

/**
 * Map a schedule type to its start and end times.
 */
function mapType(type: ScheduleType): { startTime: string; endTime: string } {
  switch (type) {
    case 'morning':
      return { startTime: '07:00', endTime: '13:00' };
    case 'afternoon':
      return { startTime: '13:00', endTime: '19:00' };
    case 'full':
    default:
      return { startTime: '07:00', endTime: '19:00' };
  }
}

/**
 * Hook to manage work schedules via the Task Manager API endpoints.
 * All operations are performed via fetch calls to the serverless endpoints.
 * Uses React Query to cache and invalidate schedules on mutations.
 */
export const useWorkSchedule = () => {
  const queryClient = useQueryClient();

  const getSchedule = useCallback(
    (start: Date, end: Date): Promise<WorkDay[]> => {
      const startStr = dateToPgString(start);
      const endStr = dateToPgString(end);

      return queryClient.fetchQuery({
        queryKey: ['workSchedule', startStr, endStr],
        queryFn: async () => {
          const url = `/_api/work-schedule?startDate=${encodeURIComponent(
            startStr
          )}&endDate=${encodeURIComponent(endStr)}`;
          const res = await fetch(url);
          if (!res.ok) {
            throw new Error('[useWorkSchedule] getSchedule fetch failed');
          }
          const rows: Array<{ date: string; scheduleType: string }> =
            await res.json();

          return rows.map((r) => {
            // parse YYYY-MM-DD into local date without timezone shift
            const [yearStr, monthStr, dayStr] = r.date.split('-');
            const yearNum = Number(yearStr);
            const monthNum = Number(monthStr);
            const dayNum = Number(dayStr);
            const localDate = new Date(yearNum, monthNum - 1, dayNum);

            const type: ScheduleType =
              r.scheduleType === 'full_day'
                ? 'full'
                : (r.scheduleType as ScheduleType);
            const { startTime, endTime } = mapType(type);
            return {
              date: localDate,
              type,
              startTime,
              endTime,
            };
          });
        },
      });
    },
    [queryClient]
  );

  const addWorkDay = useCallback(
    async (date: Date, type: ScheduleType): Promise<void> => {
      const scheduleType = type === 'full' ? 'full_day' : type;
      const dateStr = dateToPgString(date);

      const res = await fetch('/_api/work-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'add',
          date: dateStr,
          scheduleType,
        }),
      });
      if (!res.ok) {
        throw new Error('[useWorkSchedule] addWorkDay fetch failed');
      }

      queryClient.invalidateQueries({ queryKey: ['workSchedule'] });
    },
    [queryClient]
  );

  const updateWorkDay = useCallback(
    async (date: Date, type: ScheduleType): Promise<void> => {
      const scheduleType = type === 'full' ? 'full_day' : type;
      const dateStr = dateToPgString(date);

      const res = await fetch('/_api/work-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update',
          date: dateStr,
          scheduleType,
        }),
      });
      if (!res.ok) {
        throw new Error('[useWorkSchedule] updateWorkDay fetch failed');
      }

      queryClient.invalidateQueries({ queryKey: ['workSchedule'] });
    },
    [queryClient]
  );

  const removeWorkDay = useCallback(
    async (date: Date): Promise<void> => {
      const dateStr = dateToPgString(date);

      const res = await fetch('/_api/work-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'delete',
          date: dateStr,
        }),
      });
      if (!res.ok) {
        throw new Error('[useWorkSchedule] removeWorkDay fetch failed');
      }

      queryClient.invalidateQueries({ queryKey: ['workSchedule'] });
    },
    [queryClient]
  );

  const isWorking = useCallback(
    async (dateTime: Date): Promise<boolean> => {
      // normalize to local date (strip time)
      const dateOnly = new Date(
        dateTime.getFullYear(),
        dateTime.getMonth(),
        dateTime.getDate()
      );
      const days = await getSchedule(dateOnly, dateOnly);
      if (days.length === 0) {
        return false;
      }
      const { startTime, endTime } = days[0];
      const [hCur, mCur] = [dateTime.getHours(), dateTime.getMinutes()];
      const [hStart, mStart] = startTime.split(':').map(Number);
      const [hEnd, mEnd] = endTime.split(':').map(Number);
      const afterStart = hCur > hStart || (hCur === hStart && mCur >= mStart);
      const beforeEnd = hCur < hEnd || (hCur === hEnd && mCur < mEnd);
      return afterStart && beforeEnd;
    },
    [getSchedule]
  );

  return {
    getSchedule,
    addWorkDay,
    updateWorkDay,
    removeWorkDay,
    isWorking,
  };
};