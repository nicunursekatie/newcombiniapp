import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { useQueryClient } from '@tanstack/react-query';
import { QueryProvider } from './queryProvider';

describe('queryProvider', () => {
  it('provides QueryClient to children via context', async () => {
    const TestComp = () => {
      const client = useQueryClient();
      // If client is defined, it's been provided correctly
      return (
        <span data-testid="provided">
          {client ? 'provided' : 'not-provided'}
        </span>
      );
    };

    render(
      <QueryProvider>
        <TestComp />
      </QueryProvider>
    );

    await waitFor(() => {
      if (!screen.queryByTestId('provided')) {
        throw new Error('Child component did not render');
      }
    });

    expect(screen.getByTestId('provided').textContent).toBe('provided');
  });
});