import React, { useState, useEffect } from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useWorkSchedule, ScheduleType, WorkDay } from './useWorkSchedule';

function createWrapper() {
  const client = new QueryClient();
  return ({ children }: { children?: React.ReactNode }) => (
    <QueryClientProvider client={client}>{children}</QueryClientProvider>
  );
}

describe('useWorkSchedule', () => {
  const wrapper = createWrapper();

  beforeEach(() => {
    if ((global.fetch as any)?.and) {
      (global.fetch as any).and.callThrough?.();
    }
  });

  it('getSchedule returns mapped work days', async () => {
    const mockRows = [{ date: '2023-01-02', scheduleType: 'afternoon' }];
    spyOn(global, 'fetch').and.returnValue(
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockRows),
      } as any)
    );

    const TestComp = () => {
      const { getSchedule } = useWorkSchedule();
      const [days, setDays] = useState<WorkDay[] | null>(null);
      useEffect(() => {
        // Create dates with time set to midnight UTC for test consistency
        const startDate = new Date('2023-01-01T00:00:00.000Z');
        const endDate = new Date('2023-01-05T00:00:00.000Z');
        getSchedule(startDate, endDate).then(setDays);
      }, [getSchedule]);
      if (!days) return <>Loading</>;
      return (
        <span data-testid="out">
          {days
            .map(
              (d) =>
                `${d.date.toISOString().slice(0, 10)}:${d.startTime}-${d.endTime}`
            )
            .join(';')}
        </span>
      );
    };

    render(<TestComp />, { wrapper });
    await waitFor(() => {
      if (!screen.queryByTestId('out')) throw new Error('not loaded');
    });
    expect(screen.getByTestId('out').textContent).toBe(
      '2023-01-02:13:00-19:00'
    );
    expect(global.fetch).toHaveBeenCalledWith(
      '/_api/work-schedule?startDate=2023-01-01&endDate=2023-01-05'
    );
  });

  it('isWorking returns true within working hours', async () => {
    spyOn(global, 'fetch').and.returnValue(
      Promise.resolve({
        ok: true,
        json: () =>
          Promise.resolve([{ date: '2023-01-10', scheduleType: 'morning' }]),
      } as any)
    );

    const TestComp = () => {
      const { isWorking } = useWorkSchedule();
      const [ok, setOk] = useState<boolean | null>(null);
      useEffect(() => {
        // Create a date with explicit year/month/day/hour/minute
        // Month is 0-indexed in JS Date
        isWorking(new Date(2023, 0, 10, 8, 30)).then(setOk);
      }, [isWorking]);
      if (ok === null) return <>Checking</>;
      return <span data-testid="res">{String(ok)}</span>;
    };

    render(<TestComp />, { wrapper });
    await waitFor(() => {
      if (!screen.queryByTestId('res')) throw new Error('not ready');
    });
    expect(screen.getByTestId('res').textContent).toBe('true');
    expect(global.fetch).toHaveBeenCalledWith(
      '/_api/work-schedule?startDate=2023-01-10&endDate=2023-01-10'
    );
  });

  it('isWorking returns false outside working hours', async () => {
    spyOn(global, 'fetch').and.returnValue(
      Promise.resolve({
        ok: true,
        json: () =>
          Promise.resolve([{ date: '2023-01-10', scheduleType: 'afternoon' }]),
      } as any)
    );

    const TestComp = () => {
      const { isWorking } = useWorkSchedule();
      const [ok, setOk] = useState<boolean | null>(null);
      useEffect(() => {
        isWorking(new Date(2023, 0, 10, 10, 0)).then(setOk);
      }, [isWorking]);
      if (ok === null) return <>Checking</>;
      return <span data-testid="res">{String(ok)}</span>;
    };

    render(<TestComp />, { wrapper });
    await waitFor(() => {
      if (!screen.queryByTestId('res')) throw new Error('not ready');
    });
    expect(screen.getByTestId('res').textContent).toBe('false');
    expect(global.fetch).toHaveBeenCalledWith(
      '/_api/work-schedule?startDate=2023-01-10&endDate=2023-01-10'
    );
  });

  it('addWorkDay calls fetch once', async () => {
    spyOn(global, 'fetch').and.returnValue(
      Promise.resolve({ ok: true } as any)
    );

    const TestComp = () => {
      const { addWorkDay } = useWorkSchedule();
      useEffect(() => {
        // Create date with time set to midnight UTC for test consistency
        addWorkDay(new Date('2023-02-01T00:00:00.000Z'), 'full').catch(console.error);
      }, [addWorkDay]);
      return <></>;
    };

    render(<TestComp />, { wrapper });
    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        '/_api/work-schedule',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'add',
            date: '2023-02-01',
            scheduleType: 'full_day',
          }),
        }
      );
    });
  });
});