import { useState, useEffect } from 'react';
import type {
  Task as LocalTask,
  Project as LocalProject,
  Category as LocalCategory,
} from './TaskStorage';
import { getTasks } from '../endpoints/tasks_GET.schema';
import type { Task as RemoteGetTask } from '../endpoints/tasks_GET.schema';
import type { Task as RemotePostTask } from '../endpoints/tasks_POST.schema';
import { getProjects } from '../endpoints/projects_GET.schema';
import type { OutputType as RemoteProjectArray } from '../endpoints/projects_GET.schema';
import { getCategories } from '../endpoints/categories_GET.schema';
import type { OutputType as RemoteCategoryArray } from '../endpoints/categories_GET.schema';
import { postTask } from '../endpoints/tasks_POST.schema';
import { postClearCompleted } from '../endpoints/tasks/clearCompleted_POST.schema';
import { deleteProject as deleteProjectApi } from '../endpoints/projects/delete_POST.schema';
import { deleteCategory as deleteCategoryApi } from '../endpoints/categories/delete_POST.schema';

// Extract the item type from the projects array and augment with optional position
type RemoteProject = RemoteProjectArray extends Array<infer U> ? U : never;
type RemoteProjectWithPosition = RemoteProject & { position?: number | null };

export const useTaskDatabase = () => {
  const [tasks, setTasks] = useState<LocalTask[]>([]);
  const [projects, setProjects] = useState<LocalProject[]>([]);
  const [categories, setCategories] = useState<LocalCategory[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    async function fetchAll() {
      try {
        const [remoteTasks, remoteProjects, remoteCategories] = await Promise.all([
          getTasks(),
          getProjects(),
          getCategories(),
        ]);

        // Map tasks (including any subtasks)
        const localTasks = remoteTasks.map(mapRemoteTask);
        setTasks(localTasks);

        // Sort projects by position and map into local shape
        const sortedProjects = (remoteProjects as RemoteProjectWithPosition[]).sort(
          (a, b) => (a.position ?? 0) - (b.position ?? 0)
        );
        setProjects(
          sortedProjects.map(rp => ({
            id: rp.id,
            title: rp.name,
            description: rp.description ?? undefined,
            tasks: undefined,
            createdAt: new Date(),
            updatedAt: new Date(),
          }))
        );

        // Map categories
        setCategories(
          remoteCategories.map(rc => ({
            id: rc.id,
            title: rc.name,
            color: rc.color,
            tasks: undefined,
            createdAt: new Date(),
            updatedAt: new Date(),
          }))
        );
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoaded(true);
      }
    }
    fetchAll();
  }, []);

  function mapRemoteTask(rt: RemoteGetTask | RemotePostTask): LocalTask {
    const subtasks = rt.tasks?.map(mapRemoteTask);
    const firstCategoryId =
      rt.categories && rt.categories.length > 0 ? rt.categories[0].id : undefined;
    // Handle archived flag from API if present, default to false
    const archived = (rt as any).archived ?? false;
    return {
      id: rt.id,
      title: rt.title,
      description: undefined,
      completed: rt.status === 'completed',
      archived,
      dueDate: rt.dueDate ? new Date(rt.dueDate) : undefined,
      projectId: rt.projectId != null ? String(rt.projectId) : undefined,
      categoryId: firstCategoryId,
      parentTaskId: rt.parentId ?? undefined,
      energyLevel: rt.energyLevel ?? undefined,
      // activationEnergy is not in LocalTask, so omit it here
      subtasks,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
  }

  // Create a new task via the remote endpoint
  const addTask = async (
    taskData: Omit<LocalTask, 'id' | 'createdAt' | 'updatedAt' | 'subtasks'>
  ): Promise<LocalTask> => {
    const payload = {
      title: taskData.title,
      dueDate: taskData.dueDate ? taskData.dueDate.toISOString() : null,
      status: taskData.completed ? 'completed' : 'pending',
      parentId: taskData.parentTaskId ?? null,
      projectId: taskData.projectId ?? null,
      categories: taskData.categoryId ? [taskData.categoryId] : [],
    };
    const remote = await postTask(payload);
    const newTask = mapRemoteTask(remote);
    // If it's a subtask, update the parent; otherwise add to root tasks
    setTasks(prev => {
      if (newTask.parentTaskId) {
        return prev.map(task =>
          task.id === newTask.parentTaskId
            ? { ...task, subtasks: [...(task.subtasks ?? []), newTask] }
            : task
        );
      }
      return [...prev, newTask];
    });
    return newTask;
  };

  // Assign a category to multiple tasks
  const assignCategoryToTasks = async (
    taskIds: string[],
    categoryId: string
  ): Promise<void> => {
    const updated: LocalTask[] = [];
    for (const id of taskIds) {
      const local = tasks.find(t => t.id === id);
      if (!local) continue;
      const payload = {
        id: local.id,
        title: local.title,
        dueDate: local.dueDate ? local.dueDate.toISOString() : null,
        status: local.completed ? 'completed' : 'pending',
        parentId: local.parentTaskId ?? null,
        projectId: local.projectId ?? null,
        categories: [categoryId],
      };
      const remote = await postTask(payload);
      updated.push(mapRemoteTask(remote));
    }
    setTasks(prev =>
      prev.map(t => {
        const u = updated.find(x => x.id === t.id);
        return u ?? t;
      })
    );
  };

  // Clear completed tasks via the remote endpoint and refresh task list
  const clearCompleted = async (): Promise<void> => {
    await postClearCompleted();
    try {
      const remoteTasks = await getTasks();
      setTasks(remoteTasks.map(mapRemoteTask));
    } catch (error) {
      console.error('Error refreshing tasks after clearing completed:', error);
    }
  };

  // Update a task via the remote endpoint and update local state
  const updateTask = async (
    id: string,
    updates: Partial<Omit<LocalTask, 'id' | 'createdAt' | 'updatedAt' | 'subtasks'>>
  ): Promise<LocalTask> => {
    const existing = tasks.find(t => t.id === id);
    if (!existing) {
      throw new Error(`Task with id ${id} not found`);
    }
    const payload: any = {
      id: existing.id,
      title: updates.title !== undefined ? updates.title : existing.title,
      dueDate:
        updates.dueDate !== undefined
          ? updates.dueDate
            ? updates.dueDate.toISOString()
            : null
          : existing.dueDate
          ? existing.dueDate.toISOString()
          : null,
      status:
        updates.completed !== undefined
          ? updates.completed
            ? 'completed'
            : 'pending'
          : existing.completed
          ? 'completed'
          : 'pending',
      parentId:
        updates.parentTaskId !== undefined ? updates.parentTaskId : existing.parentTaskId ?? null,
      projectId: updates.projectId !== undefined ? updates.projectId : existing.projectId ?? null,
      categories:
        updates.categoryId !== undefined
          ? updates.categoryId
            ? [updates.categoryId]
            : []
          : existing.categoryId
          ? [existing.categoryId]
          : [],
    };
    if (updates.energyLevel !== undefined) {
      payload.energyLevel = updates.energyLevel;
    }
    // activationEnergy is not updatable via LocalTask, so omit it
    const remote = await postTask(payload);
    const updatedTask = mapRemoteTask(remote);
    // Preserve archived flag or apply new archived update
    if (updates.archived !== undefined) {
      updatedTask.archived = updates.archived;
    }
    setTasks(prev =>
      prev.map(t => (t.id === updatedTask.id ? updatedTask : t))
    );
    return updatedTask;
  };

  // Delete a project via the remote endpoint and update local state
  const deleteProject = async (projectId: string): Promise<void> => {
    await deleteProjectApi({ projectId });
    setProjects(prev => prev.filter(p => p.id !== projectId));
  };

  // Delete a category via the remote endpoint and update local state
  const deleteCategory = async (categoryId: string): Promise<void> => {
    await deleteCategoryApi({ categoryId });
    setCategories(prev => prev.filter(c => c.id !== categoryId));
  };

  return {
    tasks,
    projects,
    categories,
    isLoaded,
    addTask,
    assignCategoryToTasks,
    clearCompleted,
    updateTask,
    deleteProject,
    deleteCategory,
  };
};