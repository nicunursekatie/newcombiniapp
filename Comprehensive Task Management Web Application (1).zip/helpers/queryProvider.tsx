import React, { ReactNode, useMemo } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

interface QueryProviderProps {
  children?: ReactNode;
}

/**
 * queryProvider - wraps application with a React Query client.
 * Logs client creation and provider rendering for debugging.
 */
export const QueryProvider = ({ children }: QueryProviderProps) => {
  const queryClient = useMemo(() => {
    console.log('[queryProvider] Initializing QueryClient');
    return new QueryClient({
      defaultOptions: {
        queries: {
          // retry twice on failure, you can customize as needed
          retry: 2,
          // stale after 5 minutes by default
          staleTime: 1000 * 60 * 5,
        },
      },
    });
  }, []);

  console.log('[queryProvider] Rendering QueryClientProvider with client:', queryClient);

  return (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  );
};