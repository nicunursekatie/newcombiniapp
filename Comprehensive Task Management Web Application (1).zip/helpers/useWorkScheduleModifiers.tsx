import { useWorkSchedule, WorkDay } from './useWorkSchedule';
import { useQuery, useQueryClient } from '@tanstack/react-query';

export interface WorkScheduleModifiers {
  fullDaySchedule: Date[];
  morningSchedule: Date[];
  afternoonSchedule: Date[];
  // allow arbitrary modifier keys so this shape is assignable to Calendar's modifiers prop
  [modifier: string]: Date[];
}

export interface UseWorkScheduleModifiersResult {
  modifiers: WorkScheduleModifiers;
  isLoading: boolean;
  error: Error | null;
}

/**
 * Hook to fetch work schedules for a given date range and format them
 * into DayPicker modifiers: fullDaySchedule, morningSchedule, afternoonSchedule.
 * Uses React Query v5 with placeholderData to retain previous data.
 */
export const useWorkScheduleModifiers = (
  startDate: Date,
  endDate: Date
): UseWorkScheduleModifiersResult => {
  const { getSchedule } = useWorkSchedule();
  const queryClient = useQueryClient();

  const startKey = startDate.toISOString();
  const endKey = endDate.toISOString();
  const queryKey = ['workScheduleModifiers', startKey, endKey] as const;

  // grab any previous data from cache to use as placeholder while fetching new
  const previousData = queryClient.getQueryData<WorkDay[]>(queryKey);

  const {
    data: fetchedSchedule,
    isLoading,
    error,
  } = useQuery<WorkDay[], Error, WorkDay[]>({
    queryKey,
    queryFn: () => getSchedule(startDate, endDate),
    placeholderData: previousData ?? undefined,
  });

  const schedule: WorkDay[] = fetchedSchedule ?? [];

  const modifiers: WorkScheduleModifiers = {
    fullDaySchedule: [],
    morningSchedule: [],
    afternoonSchedule: [],
  };

  for (let i = 0; i < schedule.length; i++) {
    const wd = schedule[i];
    if (wd.type === 'full') {
      modifiers.fullDaySchedule.push(wd.date);
      modifiers.morningSchedule.push(wd.date);
      modifiers.afternoonSchedule.push(wd.date);
    } else if (wd.type === 'morning') {
      modifiers.morningSchedule.push(wd.date);
    } else if (wd.type === 'afternoon') {
      modifiers.afternoonSchedule.push(wd.date);
    }
  }

  return {
    modifiers,
    isLoading,
    error: error ?? null,
  };
};