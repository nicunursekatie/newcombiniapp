import { pgTable, varchar, text, integer, foreignKey, check, timestamp, boolean, date, primaryKey, index } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"



export const categories = pgTable("categories", {
	id: varchar({ length: 50 }).primaryKey().notNull(),
	name: varchar({ length: 100 }).notNull(),
	color: varchar({ length: 50 }).notNull(),
});

export const projects = pgTable("projects", {
	id: varchar({ length: 50 }).primaryKey().notNull(),
	name: varchar({ length: 100 }).notNull(),
	description: text(),
	position: integer().default(0),
});

export const tasks = pgTable("tasks", {
	id: varchar({ length: 50 }).primaryKey().notNull(),
	title: text().notNull(),
	dueDate: timestamp("due_date", { mode: "date" }),
	status: varchar({ length: 20 }).notNull(),
	parentId: varchar("parent_id", { length: 50 }),
	projectId: varchar("project_id", { length: 50 }),
	energyLevel: varchar("energy_level", { length: 10 }),
	activationEnergy: varchar("activation_energy", { length: 10 }),
	archived: boolean().default(false),
	estimatedMinutes: integer("estimated_minutes"),
	priority: varchar({ length: 10 }),
	size: varchar({ length: 10 }),
	emotionalWeight: varchar().default('none'),
	mentalComplexity: varchar().default('easy'),
}, (table) => {
	return {
		tasksParentIdFkey: foreignKey({
			columns: [table.parentId],
			foreignColumns: [table.id],
			name: "tasks_parent_id_fkey"
		}).onDelete("cascade"),
		tasksProjectIdFkey: foreignKey({
			columns: [table.projectId],
			foreignColumns: [projects.id],
			name: "tasks_project_id_fkey"
		}).onDelete("set null"),
		tasksEnergyLevelCheck: check("tasks_energy_level_check", sql`(energy_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])`),
		tasksActivationEnergyCheck: check("tasks_activation_energy_check", sql`(activation_energy)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])`),
		tasksEmotionalWeightCheck: check("tasks_emotional_weight_check", sql`("emotionalWeight")::text = ANY (ARRAY['none'::text, 'minimal'::text, 'significant'::text])`),
		tasksMentalComplexityCheck: check("tasks_mental_complexity_check", sql`("mentalComplexity")::text = ANY (ARRAY['easy'::text, 'moderate'::text, 'complex'::text])`),
	}
});

export const timeBlocks = pgTable("time_blocks", {
	id: varchar({ length: 50 }).primaryKey().notNull(),
	title: text().notNull(),
	startTime: varchar("start_time", { length: 10 }).notNull(),
	endTime: varchar("end_time", { length: 10 }).notNull(),
	date: date().notNull(),
	taskId: varchar("task_id", { length: 50 }),
}, (table) => {
	return {
		timeBlocksTaskIdFkey: foreignKey({
			columns: [table.taskId],
			foreignColumns: [tasks.id],
			name: "time_blocks_task_id_fkey"
		}).onDelete("cascade"),
	}
});

export const workSchedule = pgTable("work_schedule", {
	date: date().primaryKey().notNull(),
	scheduleType: varchar("schedule_type", { length: 20 }).notNull(),
}, (table) => {
	return {
		workScheduleScheduleTypeCheck: check("work_schedule_schedule_type_check", sql`(schedule_type)::text = ANY ((ARRAY['full_day'::character varying, 'morning'::character varying, 'afternoon'::character varying])::text[])`),
	}
});

export const taskCategories = pgTable("task_categories", {
	taskId: varchar("task_id", { length: 50 }).notNull(),
	categoryId: varchar("category_id", { length: 50 }).notNull(),
}, (table) => {
	return {
		taskCategoriesTaskIdFkey: foreignKey({
			columns: [table.taskId],
			foreignColumns: [tasks.id],
			name: "task_categories_task_id_fkey"
		}).onDelete("cascade"),
		taskCategoriesCategoryIdFkey: foreignKey({
			columns: [table.categoryId],
			foreignColumns: [categories.id],
			name: "task_categories_category_id_fkey"
		}).onDelete("cascade"),
		taskCategoriesPkey: primaryKey({ columns: [table.taskId, table.categoryId], name: "task_categories_pkey"}),
	}
});

export const timeBlockTasks = pgTable("time_block_tasks", {
	timeBlockId: varchar("time_block_id", { length: 50 }).notNull(),
	taskId: varchar("task_id", { length: 50 }).notNull(),
}, (table) => {
	return {
		idxTimeBlockTasksTaskId: index("idx_time_block_tasks_task_id").using("btree", table.taskId.asc().nullsLast().op("text_ops")),
		idxTimeBlockTasksTimeBlockId: index("idx_time_block_tasks_time_block_id").using("btree", table.timeBlockId.asc().nullsLast().op("text_ops")),
		timeBlockTasksTimeBlockIdFkey: foreignKey({
			columns: [table.timeBlockId],
			foreignColumns: [timeBlocks.id],
			name: "time_block_tasks_time_block_id_fkey"
		}).onDelete("cascade"),
		timeBlockTasksTaskIdFkey: foreignKey({
			columns: [table.taskId],
			foreignColumns: [tasks.id],
			name: "time_block_tasks_task_id_fkey"
		}).onDelete("cascade"),
		timeBlockTasksPkey: primaryKey({ columns: [table.timeBlockId, table.taskId], name: "time_block_tasks_pkey"}),
	}
});

import { relations } from "drizzle-orm/relations";

export const tasksRelations = relations(tasks, ({one, many}) => ({
	task: one(tasks, {
		fields: [tasks.parentId],
		references: [tasks.id],
		relationName: "tasks_parentId_tasks_id"
	}),
	tasks: many(tasks, {
		relationName: "tasks_parentId_tasks_id"
	}),
	project: one(projects, {
		fields: [tasks.projectId],
		references: [projects.id]
	}),
	timeBlocks: many(timeBlocks),
	taskCategories: many(taskCategories),
	timeBlockTasks: many(timeBlockTasks),
}));

export const projectsRelations = relations(projects, ({many}) => ({
	tasks: many(tasks),
}));

export const timeBlocksRelations = relations(timeBlocks, ({one, many}) => ({
	task: one(tasks, {
		fields: [timeBlocks.taskId],
		references: [tasks.id]
	}),
	timeBlockTasks: many(timeBlockTasks),
}));

export const taskCategoriesRelations = relations(taskCategories, ({one}) => ({
	task: one(tasks, {
		fields: [taskCategories.taskId],
		references: [tasks.id]
	}),
	category: one(categories, {
		fields: [taskCategories.categoryId],
		references: [categories.id]
	}),
}));

export const categoriesRelations = relations(categories, ({many}) => ({
	taskCategories: many(taskCategories),
}));

export const timeBlockTasksRelations = relations(timeBlockTasks, ({one}) => ({
	timeBlock: one(timeBlocks, {
		fields: [timeBlockTasks.timeBlockId],
		references: [timeBlocks.id]
	}),
	task: one(tasks, {
		fields: [timeBlockTasks.taskId],
		references: [tasks.id]
	}),
}));