import { renderHook, act } from '@testing-library/react';
import { useDataExport } from './dataExport';

describe('useDataExport', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('returns error on invalid JSON file', async () => {
    const { result } = renderHook(() => useDataExport());
    const badFile = new File(['not a json'], 'bad.json', {
      type: 'application/json',
    });
    let res: any;
    await act(async () => {
      res = await result.current.importData(badFile);
    });
    expect(res.errors).toContain('Invalid JSON file');
    expect(res.success).toEqual([]);
  });

  it('imports empty arrays without errors', async () => {
    const { result } = renderHook(() => useDataExport());
    const content = JSON.stringify({
      tasks: [],
      projects: [],
      categories: [],
      timeBlocks: [],
    });
    const file = new File([content], 'empty.json', {
      type: 'application/json',
    });
    let res: any;
    await act(async () => {
      res = await result.current.importData(file);
    });
    expect(res.errors).toEqual([]);
    expect(res.success).toEqual([]);
  });

  it('imports tasks with name instead of title and categoryIds array', async () => {
    // Prepare JSON with "name" and categoryIds
    const now = new Date().toISOString();
    const importObj = {
      tasks: [
        {
          id: 'task-1',
          name: 'Task Name',
          description: 'Test desc',
          completed: true,
          dueDate: null,
          projectId: null,
          categoryIds: ['cat-A', 'cat-B'],
          parentTaskId: null,
          energyLevel: null,
          activationEnergy: null,
          createdAt: now,
          updatedAt: now,
        },
      ],
    };
    const content = JSON.stringify(importObj);
    const file = new File([content], 'with-name.json', {
      type: 'application/json',
    });

    const { result } = renderHook(() => useDataExport());
    let res: any;
    await act(async () => {
      res = await result.current.importData(file);
    });

    // No schema errors and task added
    expect(res.errors).toEqual([]);
    expect(res.success).toContain('Added task "Task Name"');

    // Verify that the task was stored with correct title and categoryId
    const stored = JSON.parse(localStorage.getItem('tasks') || '[]');
    expect(stored.length).toBe(1);
    expect(stored[0].title).toBe('Task Name');
    expect(stored[0].categoryId).toBe('cat-A');
  });
});