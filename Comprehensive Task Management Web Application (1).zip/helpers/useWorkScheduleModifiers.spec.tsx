import React, { useEffect, useState } from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useWorkScheduleModifiers } from './useWorkScheduleModifiers';
import * as useWSModule from './useWorkSchedule';

function createWrapper() {
  const client = new QueryClient();
  return ({ children }: { children?: React.ReactNode }) => (
    <QueryClientProvider client={client}>{children}</QueryClientProvider>
  );
}

describe('useWorkScheduleModifiers', () => {
  const wrapper = createWrapper();

  it('builds modifiers correctly for full and morning shifts', async () => {
    const mockSchedule = [
      { date: new Date('2023-03-01T00:00:00.000Z'), type: 'full' },
      { date: new Date('2023-03-02T00:00:00.000Z'), type: 'morning' },
    ];
    console.log('[Test] stubbing useWorkSchedule.getSchedule');
    const getScheduleSpy = jasmine
      .createSpy('getSchedule')
      .and.returnValue(Promise.resolve(mockSchedule));
    spyOn(useWSModule, 'useWorkSchedule').and.returnValue({
      getSchedule: getScheduleSpy,
    } as any);

    const TestComp = () => {
      const [counts, setCounts] = useState<{
        full: number;
        morn: number;
        aft: number;
      } | null>(null);
      const { modifiers, isLoading, error } = useWorkScheduleModifiers(
        new Date('2023-03-01T00:00:00.000Z'),
        new Date('2023-03-02T00:00:00.000Z')
      );
      console.log(
        '[TestComp] render',
        { isLoading, error, modifiers }
      );
      useEffect(() => {
        console.log(
          '[TestComp] effect',
          { isLoading, error, modifiers }
        );
        if (!isLoading && !error) {
          const fullCount = modifiers.fullDaySchedule.length;
          const mornCount = modifiers.morningSchedule.length;
          const aftCount = modifiers.afternoonSchedule.length;
          console.log(
            '[TestComp] setting counts',
            { fullCount, mornCount, aftCount }
          );
          setCounts({ full: fullCount, morn: mornCount, aft: aftCount });
        }
      }, [isLoading, error, modifiers]);

      if (isLoading) {
        console.log('[TestComp] still loading');
        return <>loading</>;
      }
      if (error) {
        console.log('[TestComp] encountered error', error);
        return <span data-testid="err">{error.message}</span>;
      }
      console.log('[TestComp] displaying counts', counts);
      return (
        <span data-testid="out">
          full={counts?.full}, morn={counts?.morn}, aft={counts?.aft}
        </span>
      );
    };

    render(<TestComp />, { wrapper });

    await waitFor(() => {
      const el = screen.queryByTestId('out');
      if (!el) throw new Error('out not rendered yet');
      if (el.textContent !== 'full=1, morn=2, aft=1') {
        throw new Error(`Modifiers incorrect: ${el.textContent}`);
      }
    });
  });
});