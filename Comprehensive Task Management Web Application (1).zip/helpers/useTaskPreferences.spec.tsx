import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import { useTaskPreferences } from "./useTaskPreferences";

describe("useTaskPreferences hook", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  function TestComponent() {
    const { hideCompleted, setHideCompleted } = useTaskPreferences();
    return React.createElement(
      "div",
      null,
      React.createElement(
        "span",
        { "data-testid": "hideCompleted" },
        hideCompleted.toString()
      ),
      React.createElement(
        "button",
        {
          "data-testid": "toggle",
          onClick: () => setHideCompleted(!hideCompleted),
        },
        "toggle"
      )
    );
  }

  it("returns default hideCompleted as false", () => {
    render(React.createElement(TestComponent));
    expect(screen.getByTestId("hideCompleted").textContent).toBe("false");
  });

  it("toggles hideCompleted and persists to localStorage", () => {
    render(React.createElement(TestComponent));
    const button = screen.getByTestId("toggle");
    fireEvent.click(button);
    expect(screen.getByTestId("hideCompleted").textContent).toBe("true");
    const stored = JSON.parse(
      localStorage.getItem("taskPreferences")!
    ) as { hideCompleted: boolean };
    expect(stored.hideCompleted).toBeTrue();
  });

  it("initializes from localStorage", () => {
    localStorage.setItem(
      "taskPreferences",
      JSON.stringify({ hideCompleted: true })
    );
    render(React.createElement(TestComponent));
    expect(screen.getByTestId("hideCompleted").textContent).toBe("true");
  });
});