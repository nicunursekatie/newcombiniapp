import { renderHook, act, waitFor } from '@testing-library/react';
import { useTaskStorage, Task } from './TaskStorage';

describe('useTaskStorage archived functionality', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('defaults archived to false when adding a new task', async () => {
    const { result } = renderHook(() => useTaskStorage());
    await waitFor(() => { if (!result.current.isLoaded) throw new Error(); });

    act(() => {
      result.current.addTask({ title: 'Test Task', completed: false });
    });

    const [task] = result.current.tasks;
    expect(task.archived).toBe(false);
  });

  it('allows updating the archived property via updateTask', async () => {
    const { result } = renderHook(() => useTaskStorage());
    await waitFor(() => { if (!result.current.isLoaded) throw new Error(); });

    let created: Task;
    act(() => {
      created = result.current.addTask({ title: 'To Archive', completed: false });
    });

    act(() => {
      result.current.updateTask(created.id, { archived: true });
    });

    const updated = result.current.tasks.find(t => t.id === created.id);
    expect(updated!.archived).toBe(true);
  });

  it('persists archived flag in localStorage', async () => {
    const { result } = renderHook(() => useTaskStorage());
    await waitFor(() => { if (!result.current.isLoaded) throw new Error(); });

    act(() => {
      result.current.addTask({ title: 'Persisted', completed: false, archived: true });
    });

    const stored = JSON.parse(localStorage.getItem('tasks') || '[]');
    expect(stored[0].archived).toBe(true);
  });
});

describe('useTaskStorage estimation, priority, emotionalWeight, and mentalComplexity', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('allows setting estimatedMinutes, priority, emotionalWeight, and mentalComplexity via addTask and persists', async () => {
    const { result } = renderHook(() => useTaskStorage());
    await waitFor(() => { if (!result.current.isLoaded) throw new Error(); });

    act(() => {
      result.current.addTask({
        title: 'Detailed Task',
        completed: false,
        estimatedMinutes: 45,
        priority: 'high',
        emotionalWeight: 'significant',
        mentalComplexity: 'complex',
      });
    });

    const [task] = result.current.tasks;
    expect(task.estimatedMinutes).toBe(45);
    expect(task.priority).toBe('high');
    expect(task.emotionalWeight).toBe('significant');
    expect(task.mentalComplexity).toBe('complex');

    const stored = JSON.parse(localStorage.getItem('tasks') || '[]');
    expect(stored[0].estimatedMinutes).toBe(45);
    expect(stored[0].priority).toBe('high');
    expect(stored[0].emotionalWeight).toBe('significant');
    expect(stored[0].mentalComplexity).toBe('complex');
  });

  it('allows updating priority, estimatedMinutes, emotionalWeight, and mentalComplexity via updateTask', async () => {
    const { result } = renderHook(() => useTaskStorage());
    await waitFor(() => { if (!result.current.isLoaded) throw new Error(); });

    let created: Task;
    act(() => {
      created = result.current.addTask({ title: 'Updatable Task', completed: false });
    });

    act(() => {
      result.current.updateTask(created.id, {
        estimatedMinutes: 120,
        priority: 'low',
        emotionalWeight: 'minimal',
        mentalComplexity: 'moderate',
      });
    });

    const updated = result.current.tasks.find(t => t.id === created.id);
    expect(updated!.estimatedMinutes).toBe(120);
    expect(updated!.priority).toBe('low');
    expect(updated!.emotionalWeight).toBe('minimal');
    expect(updated!.mentalComplexity).toBe('moderate');
  });
});