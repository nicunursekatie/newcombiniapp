import { useTaskStorage } from './TaskStorage';
import { useTimeBlocks, TimeBlock } from './useTimeBlocks';
import { z, ZodError } from 'zod';

type Sections = {
  tasks?: boolean;
  projects?: boolean;
  categories?: boolean;
  timeBlocks?: boolean;
};

const dataSchema = z.object({
  tasks: z
    .array(
      z.object({
        id: z.string(),
        title: z.string(),
        description: z.string().optional(),
        completed: z.boolean(),
        dueDate: z.string().nullable().optional(),
        projectId: z.string().nullable().optional(),
        categoryId: z.string().nullable().optional(),
        parentTaskId: z.string().nullable().optional(),
        energyLevel: z
          .union([z.literal('low'), z.literal('medium'), z.literal('high')])
          .nullable()
          .optional(),
        activationEnergy: z
          .union([z.literal('low'), z.literal('medium'), z.literal('high')])
          .nullable()
          .optional(),
        createdAt: z.string(),
        updatedAt: z.string(),
        subtasks: z.array(z.any()).optional(),
      })
    )
    .optional(),
  projects: z
    .array(
      z.object({
        id: z.string(),
        title: z.string(),
        description: z.string().optional(),
        tasks: z.array(z.string()).optional(),
        createdAt: z.string(),
        updatedAt: z.string(),
      })
    )
    .optional(),
  categories: z
    .array(
      z.object({
        id: z.string(),
        title: z.string(),
        color: z.string(),
        tasks: z.array(z.string()).optional(),
        createdAt: z.string(),
        updatedAt: z.string(),
      })
    )
    .optional(),
  timeBlocks: z
    .array(
      z.object({
        id: z.string(),
        title: z.string(),
        startTime: z.string(),
        endTime: z.string(),
        date: z.string(),
        taskId: z.string().nullable(),
        task: z.any().nullable(),
      })
    )
    .optional(),
});

const normalizeData = (raw: any): any => {
  const data = { ...raw };
  // Projects: allow "name" as title
  if (Array.isArray(data.projects)) {
    data.projects = data.projects.map((p: any) => {
      const proj = { ...p };
      if (!proj.title && proj.name) {
        proj.title = proj.name;
      }
      return proj;
    });
  }
  // Categories: allow "name" as title
  if (Array.isArray(data.categories)) {
    data.categories = data.categories.map((c: any) => {
      const cat = { ...c };
      if (!cat.title && cat.name) {
        cat.title = cat.name;
      }
      return cat;
    });
  }
  // Tasks: allow "name" as title, allow categoryIds
  if (Array.isArray(data.tasks)) {
    data.tasks = data.tasks.map((t: any) => {
      const task = { ...t };
      if (!task.title && task.name) {
        task.title = task.name;
      }
      if (task.categoryIds && !task.categoryId) {
        if (Array.isArray(task.categoryIds) && task.categoryIds.length > 0) {
          task.categoryId = task.categoryIds[0];
        } else {
          task.categoryId = null;
        }
      }
      delete task.categoryIds;
      return task;
    });
  }
  return data;
};

export const useDataExport = () => {
  const {
    tasks,
    projects,
    categories,
    addTask,
    updateTask,
    getTaskById,
    addProject,
    updateProject,
    getProjectById,
    addCategory,
    updateCategory,
    getCategoryById,
  } = useTaskStorage();
  const {
    timeBlocks,
    createTimeBlock,
    updateTimeBlock,
  } = useTimeBlocks();

  const exportData = (sections?: Sections): void => {
    try {
      const exportObj: any = {};
      if (!sections || sections.tasks) exportObj.tasks = tasks;
      if (!sections || sections.projects) exportObj.projects = projects;
      if (!sections || sections.categories) exportObj.categories = categories;
      if (!sections || sections.timeBlocks) exportObj.timeBlocks = timeBlocks;
      const json = JSON.stringify(
        exportObj,
        (_key, value) => (value instanceof Date ? value.toISOString() : value),
        2
      );
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `export_${new Date().toISOString()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export failed:', err);
    }
  };

  const importData = async (
    file: File,
    sections?: Sections
  ): Promise<{ success: string[]; errors: string[] }> => {
    const successes: string[] = [];
    const errors: string[] = [];
    try {
      const text = await file.text();
      let parsedRaw: unknown;
      try {
        parsedRaw = JSON.parse(text);
      } catch {
        errors.push('Invalid JSON file');
        return { success: successes, errors };
      }

      // Normalize various incoming formats
      const normalized = normalizeData(parsedRaw);

      let data: z.infer<typeof dataSchema>;
      try {
        data = dataSchema.parse(normalized);
      } catch (err: any) {
        if (err instanceof ZodError) {
          err.errors.forEach(e => {
            const path = e.path.length ? e.path.join('.') : 'root';
            errors.push(`Schema error at "${path}": ${e.message}`);
          });
        } else {
          errors.push('Imported data has incorrect structure');
        }
        return { success: successes, errors };
      }

      // Import tasks
      if ((!sections || sections.tasks) && data.tasks) {
        for (const t of data.tasks) {
          try {
            const existing = getTaskById(t.id);
            const taskData = {
              title: t.title,
              description: t.description,
              completed: t.completed,
              dueDate: t.dueDate ? new Date(t.dueDate) : undefined,
              projectId: t.projectId ?? undefined,
              categoryId: t.categoryId ?? undefined,
              parentTaskId: t.parentTaskId ?? undefined,
              energyLevel: t.energyLevel ?? undefined,
              activationEnergy: t.activationEnergy ?? undefined,
            };
            if (existing) {
              await updateTask(t.id, taskData);
              successes.push(`Updated task "${t.title}"`);
            } else {
              await addTask(taskData);
              successes.push(`Added task "${t.title}"`);
            }
          } catch (e: any) {
            errors.push(`Task "${t.title}": ${e.message}`);
          }
        }
      }
      // Import projects
      if ((!sections || sections.projects) && data.projects) {
        for (const p of data.projects) {
          try {
            const existing = getProjectById(p.id);
            const projData = { title: p.title, description: p.description };
            if (existing) {
              await updateProject(p.id, projData);
              successes.push(`Updated project "${p.title}"`);
            } else {
              await addProject(projData);
              successes.push(`Added project "${p.title}"`);
            }
          } catch (e: any) {
            errors.push(`Project "${p.title}": ${e.message}`);
          }
        }
      }
      // Import categories
      if ((!sections || sections.categories) && data.categories) {
        for (const c of data.categories) {
          try {
            const existing = getCategoryById(c.id);
            const catData = { title: c.title, color: c.color };
            if (existing) {
              await updateCategory(c.id, catData);
              successes.push(`Updated category "${c.title}"`);
            } else {
              await addCategory(catData);
              successes.push(`Added category "${c.title}"`);
            }
          } catch (e: any) {
            errors.push(`Category "${c.title}": ${e.message}`);
          }
        }
      }
      // Import time blocks
      if ((!sections || sections.timeBlocks) && data.timeBlocks) {
        for (const b of data.timeBlocks) {
          try {
            const existing = timeBlocks.find((tb) => tb.id === b.id);
            const tbData = {
              title: b.title,
              startTime: b.startTime,
              endTime: b.endTime,
              date: b.date,
              taskId: b.taskId ?? undefined,
            };
            if (existing) {
              await updateTimeBlock({ ...existing, ...b } as TimeBlock);
              successes.push(`Updated time block "${b.title}"`);
            } else {
              await createTimeBlock(tbData);
              successes.push(`Added time block "${b.title}"`);
            }
          } catch (e: any) {
            errors.push(`Time block "${b.title}": ${e.message}`);
          }
        }
      }
    } catch (e: any) {
      errors.push(`Import failed: ${e.message}`);
    }
    return { success: successes, errors };
  };

  return { exportData, importData };
};