export type LogLevel = 'info' | 'warn' | 'error';

export interface DebugOptions {
  componentName: string;
  functionName?: string;
  level?: LogLevel;
  message?: string;
}

/**
 * Logs debug information to the console only in development mode.
 * Prefixes logs with component and function context and supports different levels.
 */
export function consoleDebugger(
  options: DebugOptions,
  ...data: any[]
): void {
  // Only log in development mode
  if (process.env.NODE_ENV !== 'development') {
    return;
  }

  const {
    componentName,
    functionName,
    level = 'info',
    message,
  } = options;

  const prefixParts: string[] = [`[${componentName}]`];
  if (functionName) {
    prefixParts.push(`[${functionName}]`);
  }
  const prefix = prefixParts.join('');

  // Prepare the arguments to log
  const logs: any[] = [];
  if (message) {
    logs.push(message);
  }
  if (data.length > 0) {
    logs.push(...data);
  }

  // Call the appropriate console method
  switch (level) {
    case 'warn':
      console.warn(prefix, ...logs);
      break;
    case 'error':
      console.error(prefix, ...logs);
      break;
    case 'info':
    default:
      console.info(prefix, ...logs);
      break;
  }
}