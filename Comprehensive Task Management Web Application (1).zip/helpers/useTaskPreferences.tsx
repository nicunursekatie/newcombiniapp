import { useState } from "react";

export interface TaskPreferences {
  hideCompleted: boolean;
  // add future preferences here
}

const STORAGE_KEY = "taskPreferences";

function loadPreferences(): TaskPreferences {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored) as Partial<TaskPreferences>;
      return {
        hideCompleted: parsed.hideCompleted ?? false,
      };
    }
  } catch {
    // ignore parse errors
  }
  return { hideCompleted: false };
}

/**
 * React hook to get and set task display preferences (currently hideCompleted),
 * persisted to localStorage and extensible for future options.
 */
export function useTaskPreferences(): {
  hideCompleted: boolean;
  setHideCompleted: (value: boolean) => void;
  updatePreferences: (updates: Partial<TaskPreferences>) => void;
} {
  const [preferences, setPreferences] = useState<TaskPreferences>(() =>
    loadPreferences()
  );

  const updatePreferences = (updates: Partial<TaskPreferences>) => {
    setPreferences((prev) => {
      const newPrefs = { ...prev, ...updates };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newPrefs));
      } catch {
        // ignore storage errors
      }
      return newPrefs;
    });
  };

  const setHideCompleted = (value: boolean) => {
    updatePreferences({ hideCompleted: value });
  };

  return {
    hideCompleted: preferences.hideCompleted,
    setHideCompleted,
    updatePreferences,
  };
}