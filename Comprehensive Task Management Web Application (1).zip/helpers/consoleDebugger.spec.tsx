import { consoleDebugger, DebugOptions } from './consoleDebugger';

describe('consoleDebugger', () => {
  beforeEach(() => {
    spyOn(console, 'info');
    spyOn(console, 'warn');
    spyOn(console, 'error');
  });

  afterEach(() => {
    // Clean up environment override
    delete process.env.NODE_ENV;
  });

  it('logs info by default in development mode with data', () => {
    process.env.NODE_ENV = 'development';
    consoleDebugger(
      { componentName: 'TestComp', functionName: 'doSomething' },
      { foo: 'bar' }
    );
    expect(console.info).toHaveBeenCalledWith(
      '[TestComp][doSomething]',
      { foo: 'bar' }
    );
  });

  it('logs warn when level is warn', () => {
    process.env.NODE_ENV = 'development';
    consoleDebugger(
      {
        componentName: 'WarningComp',
        functionName: 'warnFn',
        level: 'warn',
      },
      'warning data'
    );
    expect(console.warn).toHaveBeenCalledWith(
      '[WarningComp][warnFn]',
      'warning data'
    );
  });

  it('logs error when level is error', () => {
    process.env.NODE_ENV = 'development';
    consoleDebugger(
      {
        componentName: 'ErrorComp',
        functionName: 'errorFn',
        level: 'error',
      },
      'error data'
    );
    expect(console.error).toHaveBeenCalledWith(
      '[ErrorComp][errorFn]',
      'error data'
    );
  });

  it('includes custom message before data', () => {
    process.env.NODE_ENV = 'development';
    consoleDebugger(
      {
        componentName: 'Comp',
        functionName: 'fn',
        message: 'custom message',
      },
      { baz: 123 }
    );
    expect(console.info).toHaveBeenCalledWith(
      '[Comp][fn]',
      'custom message',
      { baz: 123 }
    );
  });

  it('does not log anything in production mode', () => {
    process.env.NODE_ENV = 'production';
    consoleDebugger(
      { componentName: 'ProdComp', functionName: 'noLog' },
      'should not appear'
    );
    expect(console.info).not.toHaveBeenCalled();
    expect(console.warn).not.toHaveBeenCalled();
    expect(console.error).not.toHaveBeenCalled();
  });
});