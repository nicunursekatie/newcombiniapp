import { AppLayout } from '../components/AppLayout';
export default [AppLayout];