"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { useTaskDatabase } from '../helpers/useTaskDatabase';
import type { Task } from '../helpers/TaskStorage';
import { TaskList } from '../components/TaskList';
import { TaskDetail } from '../components/TaskDetail';
import { Button } from '../components/Button';
import { Toggle } from '../components/Toggle';
import { Archive, CheckSquare, AlertTriangle, RefreshCw, Search } from 'lucide-react';
import styles from './archived-tasks.module.css';
import { Input } from '../components/Input';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from '../components/Dialog';

export default function ArchivedTasksPage() {
  const {
    tasks,
    projects,
    categories,
    isLoaded,
    updateTask
  } = useTaskDatabase();
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isConfirmRestoreDialogOpen, setIsConfirmRestoreDialogOpen] = useState(false);
  const [taskToRestore, setTaskToRestore] = useState<Task | null>(null);
  
  // Filter archived tasks
  const archivedTasks = tasks.filter(task => task.archived);
  
  // Filter tasks based on search, project, and category
  const filteredTasks = useCallback(() => {
    return archivedTasks.filter(task => {
      // Filter by search term
      const matchesSearch = searchTerm === '' || 
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (task.description && task.description.toLowerCase().includes(searchTerm.toLowerCase()));
      
      // Filter by project
      const matchesProject = selectedProject === null || task.projectId === selectedProject;
      
      // Filter by category
      const matchesCategory = selectedCategory === null || task.categoryId === selectedCategory;
      
      return matchesSearch && matchesProject && matchesCategory;
    });
  }, [archivedTasks, searchTerm, selectedProject, selectedCategory]);

  const handleTaskSelect = (task: Task) => {
    setSelectedTask(task);
    setIsTaskDialogOpen(true);
  };

  // Function to refresh tasks after restoration
  const refreshTasks = useCallback(async () => {
    try {
      setIsLoading(true);
      // The useTaskDatabase hook will automatically refresh tasks
      // This is just to trigger a re-render and show loading state
      await new Promise(resolve => setTimeout(resolve, 500));
    } catch (err) {
      console.error("Error refreshing tasks:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleRestoreTask = (task: Task) => {
    setTaskToRestore(task);
    setIsConfirmRestoreDialogOpen(true);
  };

  const handleConfirmRestore = async () => {
    if (!taskToRestore) return;
    
    try {
      setIsLoading(true);
      await updateTask(taskToRestore.id, { archived: false } as Partial<Task>);
      setIsConfirmRestoreDialogOpen(false);
      setTaskToRestore(null);
      setSuccess(`Task "${taskToRestore.title}" has been restored successfully.`);
      
      // Close the task detail dialog if the restored task was being viewed
      if (selectedTask && selectedTask.id === taskToRestore.id) {
        setIsTaskDialogOpen(false);
      }
      
      // Refresh the task list
      await refreshTasks();
    } catch (err) {
      setError("Failed to restore task. Please try again.");
      console.error("Error restoring task:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Clear success message after 3 seconds
  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => {
        setSuccess(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [success]);

  // Clear error message after 5 seconds
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        setError(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  if (!isLoaded || isLoading) {
    return (
      <div className={styles.loading}>
        {isLoading ? 'Updating tasks...' : 'Loading archived tasks...'}
        <div className={styles.loadingSpinner}>
          <RefreshCw className={styles.spinnerIcon} size={24} />
        </div>
      </div>
    );
  }
  
  const renderErrorMessage = () => {
    if (!error) return null;
    
    return (
      <div className={styles.errorMessage}>
        <AlertTriangle size={18} />
        {error}
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setError(null)}
          className={styles.dismissButton}
        >
          Dismiss
        </Button>
      </div>
    );
  };

  const renderSuccessMessage = () => {
    if (!success) return null;
    
    return (
      <div className={styles.successMessage}>
        <CheckSquare size={18} />
        {success}
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setSuccess(null)}
          className={styles.dismissButton}
        >
          Dismiss
        </Button>
      </div>
    );
  };

  return (
    <div className={styles.container}>
      {renderErrorMessage()}
      {renderSuccessMessage()}
      
      <div className={styles.header}>
        <div className={styles.titleContainer}>
          <h1 className={styles.title}>
            <Archive className={styles.titleIcon} />
            Archived Tasks
          </h1>
        </div>
      </div>
      
      <div className={styles.filters}>
        <div className={styles.searchBox}>
          <Search size={18} className={styles.searchIcon} />
          <Input
            type="text"
            placeholder="Search archived tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={styles.searchInput}
          />
        </div>

        <div className={styles.filterSelects}>
          <select
            value={selectedProject || ''}
            onChange={(e) => setSelectedProject(e.target.value || null)}
            className={styles.filterSelect}
          >
            <option value="">All Projects</option>
            {projects.map(project => (
              <option key={project.id} value={project.id}>
                {project.title}
              </option>
            ))}
          </select>

          <select
            value={selectedCategory || ''}
            onChange={(e) => setSelectedCategory(e.target.value || null)}
            className={styles.filterSelect}
          >
            <option value="">All Categories</option>
            {categories.map(category => (
              <option key={category.id} value={category.id}>
                {category.title}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <div className={styles.content}>
        {filteredTasks().length > 0 ? (
          <div className={styles.taskList}>
            {filteredTasks().map(task => (
              <div key={task.id} className={styles.taskItem}>
                <div 
                  className={styles.taskContent}
                  onClick={() => handleTaskSelect(task)}
                >
                  <div className={styles.taskTitle}>
                    {task.title}
                  </div>
                  
                  <div className={styles.taskMeta}>
                    {task.projectId && (
                      <div className={styles.taskMetaItem}>
                        Project: {projects.find(p => p.id === task.projectId)?.title || 'Unknown'}
                      </div>
                    )}
                    
                    {task.categoryId && (
                      <div className={styles.taskMetaItem}>
                        Category: {categories.find(c => c.id === task.categoryId)?.title || 'Unknown'}
                      </div>
                    )}
                    
                    {task.dueDate && (
                      <div className={styles.taskMetaItem}>
                        Due: {new Date(task.dueDate).toLocaleDateString()}
                      </div>
                    )}
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleRestoreTask(task)}
                  className={styles.restoreButton}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <RefreshCw size={16} className={styles.spinnerIcon} /> Restoring...
                    </>
                  ) : (
                    <>
                      <RefreshCw size={16} /> Restore
                    </>
                  )}
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className={styles.emptyState}>
            <Archive size={48} className={styles.emptyIcon} />
            <h3>No archived tasks found</h3>
            <p>
              {searchTerm || selectedProject || selectedCategory 
                ? 'Try adjusting your filters to see more results.' 
                : 'When you archive tasks, they will appear here.'}
            </p>
          </div>
        )}
      </div>

      <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
        <DialogContent className={styles.taskDetailDialog}>
          <DialogHeader>
            <DialogTitle>Archived Task Details</DialogTitle>
            <DialogDescription>
              This task is archived. You can view its details or restore it.
            </DialogDescription>
          </DialogHeader>
          
          {selectedTask && (
            <div className={styles.readOnlyTaskDetail}>
              <h3 className={styles.detailTitle}>{selectedTask.title}</h3>
              
              {selectedTask.description && (
                <div className={styles.detailSection}>
                  <h4 className={styles.detailSectionTitle}>Description</h4>
                  <p className={styles.detailDescription}>{selectedTask.description}</p>
                </div>
              )}
              
              <div className={styles.detailGrid}>
                {selectedTask.dueDate && (
                  <div className={styles.detailItem}>
                    <span className={styles.detailLabel}>Due Date:</span>
                    <span className={styles.detailValue}>
                      {new Date(selectedTask.dueDate).toLocaleDateString()}
                    </span>
                  </div>
                )}
                
                {selectedTask.projectId && (
                  <div className={styles.detailItem}>
                    <span className={styles.detailLabel}>Project:</span>
                    <span className={styles.detailValue}>
                      {projects.find(p => p.id === selectedTask.projectId)?.title || 'Unknown'}
                    </span>
                  </div>
                )}
                
                {selectedTask.categoryId && (
                  <div className={styles.detailItem}>
                    <span className={styles.detailLabel}>Category:</span>
                    <span className={styles.detailValue}>
                      {categories.find(c => c.id === selectedTask.categoryId)?.title || 'Unknown'}
                    </span>
                  </div>
                )}
                
                <div className={styles.detailItem}>
                  <span className={styles.detailLabel}>Status:</span>
                  <span className={styles.detailValue}>
                    {selectedTask.completed ? 'Completed' : 'Incomplete'}
                  </span>
                </div>
              </div>
              
              {selectedTask.subtasks && selectedTask.subtasks.length > 0 && (
                <div className={styles.detailSection}>
                  <h4 className={styles.detailSectionTitle}>Subtasks</h4>
                  <ul className={styles.subtasksList}>
                    {selectedTask.subtasks.map(subtask => (
                      <li key={subtask.id} className={styles.subtaskItem}>
                        <span className={`${subtask.completed ? styles.completedSubtask : ''}`}>
                          {subtask.title}
                        </span>
                        {subtask.completed && <span className={styles.completedTag}>Completed</span>}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsTaskDialogOpen(false)}
            >
              Close
            </Button>
            <Button 
              onClick={() => {
                setIsTaskDialogOpen(false);
                if (selectedTask) {
                  handleRestoreTask(selectedTask);
                }
              }}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <RefreshCw size={16} className={styles.spinnerIcon} /> Restoring...
                </>
              ) : (
                <>
                  <RefreshCw size={16} /> Restore Task
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog 
        open={isConfirmRestoreDialogOpen} 
        onOpenChange={(open) => {
          if (!isLoading) {
            setIsConfirmRestoreDialogOpen(open);
          }
        }}
      >
        <DialogContent className={styles.confirmDialog}>
          <DialogHeader>
            <DialogTitle>Restore Task</DialogTitle>
            <DialogDescription>
              Are you sure you want to restore this task from the archive? It will be moved back to your active tasks.
            </DialogDescription>
          </DialogHeader>
          <div className={styles.confirmTaskInfo}>
            <h4>{taskToRestore?.title}</h4>
            {taskToRestore?.dueDate && (
              <p className={styles.confirmTaskMeta}>
                Due: {new Date(taskToRestore.dueDate).toLocaleDateString()}
              </p>
            )}
            {taskToRestore?.projectId && (
              <p className={styles.confirmTaskMeta}>
                Project: {projects.find(p => p.id === taskToRestore?.projectId)?.title || 'Unknown'}
              </p>
            )}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsConfirmRestoreDialogOpen(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleConfirmRestore}
              disabled={isLoading}
              className={styles.restoreConfirmButton}
            >
              {isLoading ? (
                <>
                  <RefreshCw size={16} className={styles.spinnerIcon} /> Restoring...
                </>
              ) : (
                <>
                  <RefreshCw size={16} /> Restore Task
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}