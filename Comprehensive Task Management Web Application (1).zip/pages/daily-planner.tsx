import React from 'react';
import { Helmet } from 'react-helmet';
import { DailyPlannerContent } from '../components/DailyPlannerContent';

const DailyPlannerPage: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Daily Planner | TaskFlow</title>
        <meta name="description" content="Plan your day with time blocks and manage your tasks efficiently" />
      </Helmet>
      <DailyPlannerContent />
    </>
  );
};

export default DailyPlannerPage;