import React, { useState, useRef } from 'react';
import { WorkSchedulePrefetcher } from '../components/WorkSchedulePrefetcher';
import { SonnerToaster } from '../components/SonnerToaster';
import { CalendarMonthView } from '../components/CalendarMonthView';
import { Button } from '../components/Button';
import { Badge } from '../components/Badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../components/Tooltip';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Briefcase, Clock } from 'lucide-react';
import { WorkScheduleEditor } from '../components/WorkScheduleEditor';
import styles from './calendar.module.css';
import { useTaskDatabase } from '../helpers/useTaskDatabase';
import type { Task } from '../helpers/TaskStorage';
import { format, addDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, isSameDay, addMonths, subMonths, addWeeks, subWeeks, getHours, getMinutes } from 'date-fns';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { CalendarWorkSchedule } from '../components/CalendarWorkSchedule';
import { ScheduleType } from '../helpers/useWorkSchedule';
import { CalendarViewSelector, CalendarView } from '../components/CalendarViewSelector';
import { Helmet } from 'react-helmet';

const CalendarPage: React.FC = () => {
  const { tasks, updateTask, isLoaded } = useTaskDatabase();
  const [view, setView] = useState<CalendarView>('month');
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [isWorkScheduleEditorVisible, setIsWorkScheduleEditorVisible] = useState<boolean>(false);
  const calendarContentRef = useRef<HTMLDivElement>(null);
  
  // Get date range for current view
  const getDateRange = () => {
    if (view === 'month') {
      return {
        start: startOfMonth(currentDate),
        end: endOfMonth(currentDate),
        title: format(currentDate, 'MMMM yyyy')
      };
    } else if (view === 'week') {
      const start = startOfWeek(currentDate, { weekStartsOn: 1 });
      const end = endOfWeek(currentDate, { weekStartsOn: 1 });
      return {
        start,
        end,
        title: `${format(start, 'MMM d')} - ${format(end, 'MMM d, yyyy')}`
      };
    } else {
      return {
        start: currentDate,
        end: currentDate,
        title: format(currentDate, 'EEEE, MMMM d, yyyy')
      };
    }
  };

  const dateRange = getDateRange();
  
  // Filter tasks with due dates
  const tasksWithDueDates = tasks.filter((task: Task) => task.dueDate);

  // Navigation functions
  const goToToday = () => setCurrentDate(new Date());
  
  const goToPrevious = () => {
    if (view === 'month') {
      setCurrentDate(subMonths(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(subWeeks(currentDate, 1));
    } else {
      setCurrentDate(addDays(currentDate, -1));
    }
  };
  
  const goToNext = () => {
    if (view === 'month') {
      setCurrentDate(addMonths(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(addWeeks(currentDate, 1));
    } else {
      setCurrentDate(addDays(currentDate, 1));
    }
  };

  // Get tasks for a specific day
  const getTasksForDay = (date: Date) => {
    return tasksWithDueDates.filter((task: Task) => task.dueDate && isSameDay(task.dueDate, date));
  };

  // Generate days for week view
  const generateWeekDays = () => {
    const start = startOfWeek(currentDate, { weekStartsOn: 1 });
    const days = [];
    
    for (let i = 0; i < 7; i++) {
      const day = addDays(start, i);
      days.push(day);
    }
    
    return days;
  };

  const weekDays = generateWeekDays();

  // Generate time slots for day view
  const generateTimeSlots = () => {
    const slots = [];
    for (let i = 0; i < 24; i++) {
      const hour = i.toString().padStart(2, '0');
      slots.push(`${hour}:00`);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  // Mark a task as completed
  const markTaskCompleted = async (taskId: string, completed: boolean) => {
    try {
      await updateTask(taskId, { completed });
      toast.success('Success', {
        description: completed ? 'Task marked as completed' : 'Task marked as incomplete'
      });
    } catch (error) {
      toast.error('Error', {
        description: 'Failed to update task status'
      });
    }
  };

  // Handle work schedule click
  const handleWorkScheduleClick = (date: Date, scheduleType: ScheduleType) => {
    setCurrentDate(date);
    setView('day');
  };
  
  // Render month view
  const renderMonthView = () => {
    return (
      <CalendarMonthView
        currentDate={currentDate}
        onDateSelect={(date) => {
          setCurrentDate(date);
          setView('day');
        }}
        getTasksForDay={getTasksForDay}
        dateRange={dateRange}
        onWorkScheduleClick={handleWorkScheduleClick}
      />
    );
  };

  // Render week view
  const renderWeekView = () => {
    return (
      <div className={styles.weekView}>
        <div className={styles.weekHeader}>
          {weekDays.map((day, index) => (
            <div 
              key={index} 
              className={`${styles.weekDay} ${isSameDay(day, new Date()) ? styles.weekDayToday : ''}`}
              onClick={() => setCurrentDate(day)}
              data-date={format(day, 'yyyy-MM-dd')}
              data-testid={`week-header-${format(day, 'yyyy-MM-dd')}`}
            >
              <div className={styles.weekDayName}>{format(day, 'EEE')}</div>
              <div className={styles.weekDayNumber}>{format(day, 'd')}</div>
            </div>
          ))}
        </div>
        <div className={styles.weekBody}>
          {weekDays.map((day, dayIndex) => {
            const tasksForDay = getTasksForDay(day);
            return (
              <div 
                key={dayIndex} 
                className={`${styles.weekDayColumn} ${isSameDay(day, new Date()) ? styles.weekDayColumnToday : ''}`}
                data-date={format(day, 'yyyy-MM-dd')}
                data-testid={`week-column-${format(day, 'yyyy-MM-dd')}`}
              >
                <CalendarWorkSchedule 
                  date={day} 
                  view="week" 
                  onClick={handleWorkScheduleClick}
                  dateRange={dateRange}
                />
                
                {tasksForDay.length > 0 ? (
                  <div className={styles.weekDayTasks}>
                    {tasksForDay.map(task => (
                      <div 
                        key={task.id} 
                        className={styles.weekDayTask}
                        onClick={() => markTaskCompleted(task.id, !task.completed)}
                        title={task.title}
                      >
                        <div className={styles.weekDayTaskContent}>
                        <div 
                          className={`${styles.weekDayTaskTitle} ${task.completed ? styles.taskCompleted : ''}`}
                          title={task.title}
                        >
                          {task.title}
                        </div>
                          {task.dueDate && hasTimeSpecified(task.dueDate) && (
                            <div className={styles.weekDayTaskTime}>
                              <CalendarIcon size={12} />
                              {format(task.dueDate, 'h:mm a')}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className={styles.weekDayEmpty}>
                    No tasks for {format(day, 'EEEE')}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Render day view
  const renderDayView = () => {
    const tasksForDay = getTasksForDay(currentDate);
    
    return (
      <div className={styles.dayView} data-date={format(currentDate, 'yyyy-MM-dd')} data-testid={`day-view-${format(currentDate, 'yyyy-MM-dd')}`}>
        <div className={styles.dayHeader}>
          <div className={styles.dayDate}>{format(currentDate, 'EEEE, MMMM d')}</div>
        </div>
        
        {/* Work Schedule Information */}
        <div className={styles.dayScheduleContainer}>
          <CalendarWorkSchedule 
            date={currentDate} 
            view="day" 
            onClick={handleWorkScheduleClick}
            className={styles.dayScheduleComponent}
            dateRange={dateRange}
          />
        </div>
        
        <div className={styles.dayContent}>
          {tasksForDay.length > 0 ? (
            <div className={styles.dayTasks}>
              {tasksForDay.map(task => (
                <div 
                  key={task.id} 
                  className={styles.dayTask}
                >
                  <div className={styles.dayTaskHeader}>
                    <div className={styles.dayTaskCheckbox}>
                      <input
                        type="checkbox"
                        checked={task.completed}
                        onChange={(e) => markTaskCompleted(task.id, e.target.checked)}
                        className={styles.taskCheckbox}
                      />
                    </div>
                    <div className={`${styles.dayTaskTitle} ${task.completed ? styles.taskCompleted : ''}`}>
                      {task.title}
                    </div>
                  </div>
                  
                  {task.dueDate && hasTimeSpecified(task.dueDate) && (
                    <div className={styles.dayTaskTime}>
                      <CalendarIcon size={14} />
                      {format(task.dueDate, 'h:mm a')}
                    </div>
                  )}
                  
                  {task.description && (
                    <div className={styles.dayTaskDescription}>
                      {task.description}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className={styles.dayEmpty}>
              <p>No tasks scheduled for today</p>
              <p>Go to the Daily Planner to schedule tasks for this day</p>
            </div>
          )}
        </div>
      </div>
    );
  };

  const isLoading = !isLoaded;

  // Helper function to check if a date has a specific time set
  const hasTimeSpecified = (date: Date): boolean => {
    return getHours(date) !== 0 || getMinutes(date) !== 0;
  };

  return (
    <div className={styles.calendarPage} data-testid="calendar-page">
        <Helmet>
          <title>Calendar | Task Manager</title>
          <meta name="description" content="View your tasks in a calendar format" />
        </Helmet>
        
        <SonnerToaster />
        <header className={styles.header}>
          <div className={styles.headerLeft}>
            <h1 className={styles.title}>Calendar</h1>
            <div className={styles.navigation}>
              <Button variant="ghost" size="icon-sm" onClick={goToPrevious}>
                <ChevronLeft size={16} />
              </Button>
              <Button variant="ghost" size="sm" onClick={goToToday}>
                Today
              </Button>
              <Button variant="ghost" size="icon-sm" onClick={goToNext}>
                <ChevronRight size={16} />
              </Button>
              <span className={styles.currentPeriod}>{dateRange.title}</span>
            </div>
          </div>
          <div className={styles.headerRight}>
            <CalendarViewSelector 
              view={view} 
              onViewChange={setView} 
            />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={isWorkScheduleEditorVisible ? "primary" : "outline"}
                    size="sm" 
                    onClick={() => {
                      setIsWorkScheduleEditorVisible(!isWorkScheduleEditorVisible);
                    }}
                    className={styles.workScheduleButton}
                    data-testid="work-schedule-button"
                    aria-label="Toggle work schedule editor"
                  >
                    <Briefcase size={16} className={styles.buttonIcon} />
                    <span className={styles.buttonText}>
                      {isWorkScheduleEditorVisible ? "Hide Work Schedule" : "Work Schedule"}
                    </span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  Configure your working hours and non-working days to better visualize your availability
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <Link to="/daily-planner">
              <Button variant="primary" size="sm">
                Go to Daily Planner
              </Button>
            </Link>
          </div>
        </header>
        
        <div className={styles.calendarContainer}>
          {isLoading ? (
            <div className={styles.loadingContainer}>
              <LoadingSpinner size="lg" />
              <p>Loading calendar data...</p>
            </div>
          ) : (
            <div className={styles.calendarViewContainer} data-testid="calendar-view-container">
              {/* Prefetch work schedule data for the current view */}
              <WorkSchedulePrefetcher 
                startDate={dateRange.start} 
                endDate={dateRange.end} 
              />
              <div className={styles.calendarContent} ref={calendarContentRef}>
                {view === 'month' && renderMonthView()}
                {view === 'week' && renderWeekView()}
                {view === 'day' && renderDayView()}
              </div>
              
              {/* Work Schedule Legend */}
              <div className={styles.workScheduleLegend}>
                <div className={styles.legendHeader}>
                  <Briefcase size={14} />
                  <div className={styles.legendTitle}>Work Schedule</div>
                </div>
                <div className={styles.legendDescription}>
                  Shows your configured work hours on the calendar
                </div>
                <div className={styles.legendItems}>
                  <div className={styles.legendItem}>
                    <div className={`${styles.legendColor} ${styles.fullDayColor}`}>
                      <Clock size={12} />
                    </div>
                    <span>Full Day (7am-7pm)</span>
                  </div>
                  <div className={styles.legendItem}>
                    <div className={`${styles.legendColor} ${styles.morningColor}`}>
                      <Clock size={12} />
                    </div>
                    <span>Morning (7am-1pm)</span>
                  </div>
                  <div className={styles.legendItem}>
                    <div className={`${styles.legendColor} ${styles.afternoonColor}`}>
                      <Clock size={12} />
                    </div>
                    <span>Afternoon (1pm-7pm)</span>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className={styles.legendButton}
                  onClick={() => setIsWorkScheduleEditorVisible(true)}
                >
                  Edit Schedule
                </Button>
              </div>
            </div>
          )}
        </div>
        
        {/* Work Schedule Editor */}
        {isWorkScheduleEditorVisible && (
          <div className={styles.workScheduleEditorContainer}>
            <div className={styles.workScheduleEditorOverlay} onClick={() => {
              setIsWorkScheduleEditorVisible(false);
            }} />
            <div className={styles.workScheduleEditorWrapper}>
              <div className={styles.workScheduleEditorHeader}>
                <h2>Work Schedule Editor</h2>
                <p className={styles.workScheduleEditorDescription}>
                  Configure your working hours to better visualize your availability on the calendar.
                  Set full day, morning, or afternoon schedules for specific dates.
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => {
                    setIsWorkScheduleEditorVisible(false);
                  }}
                  className={styles.closeEditorButton}
                >
                  <ChevronLeft size={16} />
                  Close
                </Button>
              </div>
              <WorkScheduleEditor 
                initialDate={currentDate}
                onClose={() => {
                  setIsWorkScheduleEditorVisible(false);
                }}
                className={styles.workScheduleEditor}
              />
            </div>
          </div>
        )}
      </div>
  );
};

export default CalendarPage;