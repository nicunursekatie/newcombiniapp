import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { Clock, Filter, Calendar, BarChart2, AlertCircle } from 'lucide-react';
import { TaskTimeAnalytics } from '../components/TaskTimeAnalytics';
import { useTimeEstimates } from '../helpers/useTimeEstimates';
import { useTaskStorage, Task } from '../helpers/TaskStorage';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '../components/Select';
import styles from './time-analytics.module.css';

const TimeAnalyticsPage: React.FC = () => {
  const { tasks, projects, categories } = useTaskStorage();
  const { totalEstimate, formatTime } = useTimeEstimates();
  
  // Filter states
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [dateRangeFilter, setDateRangeFilter] = useState<string>('all');
  const [searchFilter, setSearchFilter] = useState<string>('');
  
  // Filtered tasks based on selected filters
  const filteredTasks = useMemo(() => {
    let filtered = [...tasks];
    
    // Filter by project
    if (projectFilter !== 'all') {
      filtered = filtered.filter(task => task.projectId === projectFilter);
    }
    
    // Filter by category
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(task => task.categoryId === categoryFilter);
    }
    
    // Filter by date range
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (dateRangeFilter === 'today') {
      filtered = filtered.filter(task => {
        if (!task.dueDate) return false;
        const taskDate = new Date(task.dueDate);
        taskDate.setHours(0, 0, 0, 0);
        return taskDate.getTime() === today.getTime();
      });
    } else if (dateRangeFilter === 'week') {
      const weekLater = new Date(today);
      weekLater.setDate(weekLater.getDate() + 7);
      
      filtered = filtered.filter(task => {
        if (!task.dueDate) return false;
        const taskDate = new Date(task.dueDate);
        return taskDate >= today && taskDate <= weekLater;
      });
    } else if (dateRangeFilter === 'month') {
      const monthLater = new Date(today);
      monthLater.setMonth(monthLater.getMonth() + 1);
      
      filtered = filtered.filter(task => {
        if (!task.dueDate) return false;
        const taskDate = new Date(task.dueDate);
        return taskDate >= today && taskDate <= monthLater;
      });
    }
    
    // Filter by search term
    if (searchFilter.trim()) {
      const searchTerm = searchFilter.toLowerCase().trim();
      filtered = filtered.filter(task => 
        task.title.toLowerCase().includes(searchTerm)
      );
    }
    
    return filtered;
  }, [tasks, projectFilter, categoryFilter, dateRangeFilter, searchFilter]);
  
  // Tasks sorted by estimated time (largest to smallest)
  const tasksByEstimatedTime = useMemo(() => {
    return [...filteredTasks]
      .filter(task => task.estimatedMinutes && task.estimatedMinutes > 0)
      .sort((a, b) => {
        const totalA = totalEstimate(a);
        const totalB = totalEstimate(b);
        return totalB - totalA;
      })
      .slice(0, 10); // Top 10 tasks
  }, [filteredTasks, totalEstimate]);
  
  // Tasks without time estimates
  const tasksWithoutEstimates = useMemo(() => {
    return filteredTasks.filter(task => 
      !task.estimatedMinutes || task.estimatedMinutes === 0
    ).slice(0, 10); // Top 10 tasks
  }, [filteredTasks]);
  
  // Daily time estimates for the upcoming week
  const weeklyTimeEstimates = useMemo(() => {
    const estimates = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() + i);
      
      const dayTasks = tasks.filter(task => {
        if (!task.dueDate) return false;
        const taskDate = new Date(task.dueDate);
        taskDate.setHours(0, 0, 0, 0);
        return taskDate.getTime() === date.getTime();
      });
      
      const totalMinutes = dayTasks.reduce((sum, task) => sum + totalEstimate(task), 0);
      
      estimates.push({
        date,
        totalMinutes,
        formattedTotal: formatTime(totalMinutes),
        taskCount: dayTasks.length
      });
    }
    
    return estimates;
  }, [tasks, totalEstimate, formatTime]);
  
  // Format date for display
  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  // Check if a date is today
  const isToday = (date: Date): boolean => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear();
  };
  
  // Reset all filters
  const resetFilters = () => {
    setProjectFilter('all');
    setCategoryFilter('all');
    setDateRangeFilter('all');
    setSearchFilter('');
  };
  
  return (
    <div className={styles.container}>
      <Helmet>
        <title>Time Analytics | TaskFlow</title>
        <meta name="description" content="Analyze time estimates for your tasks" />
      </Helmet>
      
      <header className={styles.header}>
        <div className={styles.titleContainer}>
          <Clock className={styles.titleIcon} />
          <h1 className={styles.title}>Time Analytics</h1>
        </div>
        
        <div className={styles.filterContainer}>
          <div className={styles.filterGroup}>
            <Filter size={18} className={styles.filterIcon} />
            <span className={styles.filterLabel}>Filters:</span>
            
            <div className={styles.filterControls}>
              <Select value={projectFilter} onValueChange={setProjectFilter}>
                <SelectTrigger className={styles.filterSelect}>
                  <SelectValue placeholder="Project" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="all">All Projects</SelectItem>
                    {projects.map(project => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.title}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
              
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className={styles.filterSelect}>
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map(category => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.title}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
              
              <Select value={dateRangeFilter} onValueChange={setDateRangeFilter}>
                <SelectTrigger className={styles.filterSelect}>
                  <SelectValue placeholder="Date Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">Next 7 Days</SelectItem>
                    <SelectItem value="month">Next 30 Days</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
              
              <Input
                type="search"
                placeholder="Search tasks..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className={styles.searchInput}
              />
              
              <Button 
                variant="outline" 
                size="sm" 
                onClick={resetFilters}
                className={styles.resetButton}
              >
                Reset
              </Button>
            </div>
          </div>
        </div>
      </header>
      
      <main className={styles.content}>
        {/* Main analytics component */}
        <section className={styles.mainAnalytics}>
          <TaskTimeAnalytics 
            tasks={filteredTasks} 
            className={styles.analyticsComponent} 
          />
        </section>
        
        {/* Tasks by estimated time */}
        <section className={styles.section}>
          <div className={styles.sectionHeader}>
            <BarChart2 size={20} />
            <h2 className={styles.sectionTitle}>Top Tasks by Estimated Time</h2>
          </div>
          
          <div className={styles.tasksList}>
            {tasksByEstimatedTime.length > 0 ? (
              tasksByEstimatedTime.map(task => (
                <div key={task.id} className={styles.taskItem}>
                  <div className={styles.taskInfo}>
                    <h3 className={styles.taskTitle}>{task.title}</h3>
                    <div className={styles.taskMeta}>
                      {task.projectId && (
                        <span className={styles.taskProject}>
                          {projects.find(p => p.id === task.projectId)?.title || 'Unknown Project'}
                        </span>
                      )}
                      {task.categoryId && (
                        <span className={styles.taskCategory}>
                          {categories.find(c => c.id === task.categoryId)?.title || 'Unknown Category'}
                        </span>
                      )}
                      {task.dueDate && (
                        <span className={styles.taskDueDate}>
                          Due: {formatDate(task.dueDate)}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className={styles.taskEstimate}>
                    {formatTime(totalEstimate(task))}
                  </div>
                </div>
              ))
            ) : (
              <div className={styles.emptyState}>
                <p>No tasks with time estimates found.</p>
              </div>
            )}
          </div>
        </section>
        
        {/* Tasks without estimates */}
        <section className={styles.section}>
          <div className={styles.sectionHeader}>
            <AlertCircle size={20} />
            <h2 className={styles.sectionTitle}>Tasks Needing Estimates</h2>
          </div>
          
          <div className={styles.tasksList}>
            {tasksWithoutEstimates.length > 0 ? (
              tasksWithoutEstimates.map(task => (
                <div key={task.id} className={styles.taskItem}>
                  <div className={styles.taskInfo}>
                    <h3 className={styles.taskTitle}>{task.title}</h3>
                    <div className={styles.taskMeta}>
                      {task.projectId && (
                        <span className={styles.taskProject}>
                          {projects.find(p => p.id === task.projectId)?.title || 'Unknown Project'}
                        </span>
                      )}
                      {task.categoryId && (
                        <span className={styles.taskCategory}>
                          {categories.find(c => c.id === task.categoryId)?.title || 'Unknown Category'}
                        </span>
                      )}
                      {task.dueDate && (
                        <span className={styles.taskDueDate}>
                          Due: {formatDate(task.dueDate)}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className={styles.taskEstimate}>
                    <Button size="sm" variant="outline">Add Estimate</Button>
                  </div>
                </div>
              ))
            ) : (
              <div className={styles.emptyState}>
                <p>All tasks have time estimates. Great job!</p>
              </div>
            )}
          </div>
        </section>
        
        {/* Weekly time estimates */}
        <section className={styles.section}>
          <div className={styles.sectionHeader}>
            <Calendar size={20} />
            <h2 className={styles.sectionTitle}>Upcoming Week Time Estimates</h2>
          </div>
          
          <div className={styles.weeklyEstimates}>
            {weeklyTimeEstimates.map((day, index) => (
              <div key={index} className={`${styles.dayEstimate} ${isToday(day.date) ? styles.today : ''}`}>
                <div className={styles.dayHeader}>
                  <span className={styles.dayName}>{formatDate(day.date)}</span>
                  {isToday(day.date) && <span className={styles.todayBadge}>Today</span>}
                </div>
                <div className={styles.dayContent}>
                  <div className={styles.dayTasks}>
                    <span className={styles.taskCount}>{day.taskCount}</span>
                    <span className={styles.taskLabel}>
                      {day.taskCount === 1 ? 'task' : 'tasks'}
                    </span>
                  </div>
                  <div className={styles.dayEstimateTime}>
                    {day.formattedTotal}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};

export default TimeAnalyticsPage;