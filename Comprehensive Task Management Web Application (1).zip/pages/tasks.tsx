"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { useTaskPreferences } from '../helpers/useTaskPreferences';
import { useTaskDatabase } from '../helpers/useTaskDatabase';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { TaskList } from '../components/TaskList';
import { TaskDetail } from '../components/TaskDetail';
import { QuickTaskDialog } from '../components/QuickTaskDialog';
import { Button } from '../components/Button';
import { Toggle } from '../components/Toggle';
import { Plus, Archive, AlertTriangle } from 'lucide-react';
import styles from './tasks.module.css';
import { Task } from '../helpers/TaskStorage';
import { postTasksArchive } from '../endpoints/tasks/archive_POST.schema';
import { getTasks } from '../endpoints/tasks_GET.schema';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from '../components/Dialog';

export default function TasksPage() {
  const {
    tasks,
    projects,
    categories,
    isLoaded,
    addTask,
    updateTask,
    clearCompleted,
    assignCategoryToTasks
  } = useTaskDatabase();
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
  const [isQuickTaskDialogOpen, setIsQuickTaskDialogOpen] = useState(false);
  const [isArchiveConfirmDialogOpen, setIsArchiveConfirmDialogOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [selectedProjectName, setSelectedProjectName] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedCategoryName, setSelectedCategoryName] = useState<string | null>(null);
  const { hideCompleted, setHideCompleted } = useTaskPreferences();
  
  // Get URL query parameters
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Set initial project and category filters from URL query parameters
  useEffect(() => {
    const projectId = searchParams.get('project');
    const categoryId = searchParams.get('category');
    
    if (projectId) {
      setSelectedProject(projectId);
      
      // Find the project name
      const project = projects.find(p => p.id === projectId);
      if (project) {
        setSelectedProjectName(project.title);
      }
    } else {
      setSelectedProject(null);
      setSelectedProjectName(null);
    }
    
    if (categoryId) {
      setSelectedCategory(categoryId);
      
      // Find the category name
      const category = categories.find(c => c.id === categoryId);
      if (category) {
        setSelectedCategoryName(category.title);
      }
    } else {
      setSelectedCategory(null);
      setSelectedCategoryName(null);
    }
  }, [searchParams, projects, categories]);

  const handleTaskToggle = async (taskId: string, completed: boolean) => {
    try {
      setIsLoading(true);
      await updateTask(taskId, { completed });
    } catch (err) {
      setError("Failed to update task status. Please try again.");
      console.error("Error toggling task:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTaskSelect = (task: Task) => {
    setSelectedTask(task);
    setIsTaskDialogOpen(true);
  };
  
  const handleOpenQuickTaskDialog = () => {
    setIsQuickTaskDialogOpen(true);
  };

  const handleSaveTask = async (updatedTask: Task) => {
    try {
      setIsLoading(true);
      await updateTask(updatedTask.id, updatedTask);
      setIsTaskDialogOpen(false);
    } catch (err) {
      setError("Failed to save task. Please try again.");
      console.error("Error saving task:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleArchiveCompletedTasks = () => {
    setIsArchiveConfirmDialogOpen(true);
  };

  const handleConfirmArchiveCompleted = async () => {
    try {
      setIsLoading(true);
      // Use the new archive endpoint
      const result = await postTasksArchive();
      // Refresh the task list after successful archiving
      const remoteTasks = await getTasks();
      // Update the tasks state with the refreshed data
      setIsArchiveConfirmDialogOpen(false);
    } catch (err) {
      setError("Failed to archive completed tasks. Please try again.");
      console.error("Error archiving completed tasks:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      setIsLoading(true);
      // Mark the task as completed instead of trying to delete it
      // since our API doesn't support actual deletion
      await updateTask(taskId, { completed: true });
      setIsTaskDialogOpen(false);
    } catch (err) {
      setError("Failed to mark task as completed. Please try again.");
      console.error("Error marking task as completed:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddSubtask = async (parentId: string, subtaskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      setIsLoading(true);
      await addTask(subtaskData);
      
      // Refresh the selected task to show the new subtask
      const updatedTasks = tasks.filter(t => t.id === parentId);
      if (updatedTasks.length > 0) {
        setSelectedTask(updatedTasks[0]);
      }
    } catch (err) {
      setError("Failed to add subtask. Please try again.");
      console.error("Error adding subtask:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddTask = async (taskData: Partial<Task>) => {
    try {
      setIsLoading(true);
      // Ensure title is not undefined before passing to addTask
      if (taskData.title) {
        await addTask({
          ...taskData,
          title: taskData.title,
          completed: taskData.completed ?? false,
          archived: taskData.archived ?? false
        });
      }
    } catch (err) {
      setError("Failed to add task. Please try again.");
      console.error("Error adding task:", err);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isLoaded) {
    return <div className={styles.loading}>Loading tasks...</div>;
  }
  
  const renderErrorMessage = () => {
    if (!error) return null;
    
    return (
      <div className={styles.errorMessage}>
        {error}
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setError(null)}
          className={styles.dismissButton}
        >
          Dismiss
        </Button>
      </div>
    );
  };

  return (
    <div className={styles.container}>
      {renderErrorMessage()}
      <div className={styles.header}>
        <div className={styles.titleContainer}>
          <h1 className={styles.title}>
            {selectedProjectName 
              ? `${selectedProjectName} Tasks` 
              : selectedCategoryName 
                ? `${selectedCategoryName} Tasks` 
                : 'All Tasks'}
          </h1>
          {(selectedProject || selectedCategory) && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/tasks')}
              className={styles.clearFilterButton}
            >
              Clear filter
            </Button>
          )}
        </div>
        <div className={styles.headerActions}>
          <Toggle 
            pressed={hideCompleted}
            onPressedChange={setHideCompleted}
            variant="outline"
            size="sm"
            className={styles.hideCompletedToggle}
          >
            {hideCompleted ? 'Show Completed' : 'Hide Completed'}
          </Toggle>
          <Button
            variant="outline"
            size="sm"
            onClick={handleArchiveCompletedTasks}
            disabled={isLoading}
            className={styles.archiveCompletedButton}
          >
            <Archive size={16} /> Archive Completed
          </Button>
          <Button 
            onClick={handleOpenQuickTaskDialog}
            disabled={isLoading}
          >
            <Plus size={16} /> New Task
          </Button>
        </div>
      </div>
      
      <div className={styles.content}>
        <TaskList
          tasks={tasks}
          projects={projects}
          categories={categories}
          onTaskSelect={handleTaskSelect}
          onTaskToggle={handleTaskToggle}
          onAddTask={handleAddTask}
          assignCategoryToTasks={assignCategoryToTasks as any}
          className={styles.taskList}
          initialProjectFilter={selectedProject}
          initialCategoryFilter={selectedCategory}
          hideCompleted={hideCompleted}
        />
      </div>

      <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
        <DialogContent className={styles.taskDetailDialog}>
          <TaskDetail
            task={selectedTask}
            projects={projects}
            categories={categories}
            onSave={handleSaveTask}
            onDelete={handleDeleteTask}
            onAddSubtask={handleAddSubtask}
            onClose={() => setIsTaskDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={isArchiveConfirmDialogOpen} onOpenChange={setIsArchiveConfirmDialogOpen}>
        <DialogContent className={styles.confirmDialog}>
          <DialogHeader>
            <DialogTitle>Archive Completed Tasks</DialogTitle>
            <DialogDescription>
              Are you sure you want to archive all completed tasks? Archived tasks will be moved to the archive and can be viewed in the Archived Tasks page.
            </DialogDescription>
          </DialogHeader>
          <div className={styles.confirmIcon}>
            <AlertTriangle size={48} />
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsArchiveConfirmDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmArchiveCompleted}
              disabled={isLoading}
            >
              Archive Tasks
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <QuickTaskDialog
        projects={projects}
        categories={categories}
        onSave={handleAddTask}
        open={isQuickTaskDialogOpen}
        onOpenChange={setIsQuickTaskDialogOpen}
      />
    </div>
  );
}