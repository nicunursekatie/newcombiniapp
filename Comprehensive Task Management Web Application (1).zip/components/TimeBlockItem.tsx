import React, { useMemo } from 'react';
import { format, differenceInMinutes, isValid, parse } from 'date-fns';
import { Link } from 'lucide-react';
import { TimeBlockContextMenu } from './TimeBlockContextMenu';
import { Checkbox } from './Checkbox';
import { Task, Project, Category } from '../helpers/TaskStorage';
import { ExtendedTimeBlock } from './TimeBlockTypes';
import styles from './TimeBlockItem.module.css';

export interface TimeBlockItemProps {
  timeBlock: ExtendedTimeBlock;
  tasks: Task[];
  projects?: Project[];
  categories?: Category[];
  onEdit: (block: ExtendedTimeBlock) => void;
  onDelete: (blockId: string) => void;
  onTaskToggle?: (taskId: string, completed: boolean) => void;
  onTaskUnlink?: (taskId: string, timeBlockId: string) => void;
  onDrop?: (e: React.DragEvent, timeBlockId: string) => void;
  className?: string;
}

export const TimeBlockItem: React.FC<TimeBlockItemProps> = ({
  timeBlock,
  tasks,
  projects = [],
  categories = [],
  onEdit,
  onDelete,
  onTaskToggle,
  onTaskUnlink,
  onDrop,
  className = '',
}) => {
  // Find linked tasks if they exist
  const linkedTasks = useMemo(() => {
    const result: Task[] = [];
    
    // Support for legacy single task via taskId
    if (timeBlock.taskId) {
      const task = tasks.find(task => task.id === timeBlock.taskId);
      if (task) {
        result.push(task);
      }
    }
    
    // Support for multiple tasks via tasks array
    if (timeBlock.tasks && timeBlock.tasks.length > 0) {
      timeBlock.tasks.forEach(taskRef => {
        const task = tasks.find(task => task.id === taskRef.id);
        if (task && !result.some(t => t.id === task.id)) { // Avoid duplicates
          result.push(task);
        }
      });
    }
    
    return result;
  }, [timeBlock.taskId, timeBlock.tasks, tasks]);

  // Find projects and categories for the linked tasks
  const getTaskProject = (task: Task) => {
    if (!task.projectId) return null;
    return projects.find(p => p.id === task.projectId);
  };

  const getTaskCategory = (task: Task) => {
    if (!task.categoryId) return null;
    return categories.find(c => c.id === task.categoryId);
  };

  // Parse time strings safely
  const parseTimeString = (timeString: string) => {
    try {
      const parsedDate = parse(timeString, 'HH:mm', new Date());
      return isValid(parsedDate) ? parsedDate : new Date();
    } catch (error) {
      console.warn(`Invalid time format: ${timeString}`);
      return new Date();
    }
  };

  // Calculate duration in minutes
  const duration = useMemo(() => {
    try {
      const startDate = parseTimeString(timeBlock.startTime);
      const endDate = parseTimeString(timeBlock.endTime);
      return differenceInMinutes(endDate, startDate) || 0;
    } catch (error) {
      console.warn('Error calculating duration:', error);
      return 0;
    }
  }, [timeBlock.startTime, timeBlock.endTime]);

  // Format duration as hours and minutes
  const formattedDuration = useMemo(() => {
    const hours = Math.floor(duration / 60);
    const minutes = duration % 60;
    
    if (hours === 0) {
      return `${minutes}m`;
    } else if (minutes === 0) {
      return `${hours}h`;
    } else {
      return `${hours}h ${minutes}m`;
    }
  }, [duration]);

  // Handle drag over event
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'link';
  };

  // Handle drop event
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (onDrop) {
      onDrop(e, timeBlock.id);
    }
  };

  // Handle task completion toggle
  const handleTaskToggle = (taskId: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    if (onTaskToggle) {
      onTaskToggle(taskId, e.target.checked);
    }
  };

  // Handle task unlink
  const handleTaskUnlink = (taskId: string) => () => {
    if (onTaskUnlink) {
      onTaskUnlink(taskId, timeBlock.id);
    }
  };

  // Get style based on category color if available
  const getCategoryStyle = () => {
    // If there's only one task, use its category color for the border
    if (linkedTasks.length === 1) {
      const category = getTaskCategory(linkedTasks[0]);
      if (category) {
        return {
          borderLeft: `3px solid ${category.color}`,
        };
      }
    }
    // If there are multiple tasks with different categories, use a gradient
    else if (linkedTasks.length > 1) {
      const categories = linkedTasks
        .map(task => getTaskCategory(task))
        .filter(Boolean) as Category[];
      
      if (categories.length > 0) {
        return {
          borderLeft: `3px solid ${categories[0].color}`,
        };
      }
    }
    return {};
  };

  return (
    <TimeBlockContextMenu
      block={timeBlock}
      onEdit={onEdit}
      onDelete={onDelete}
      onUnlinkTask={linkedTasks.length === 1 && onTaskUnlink ? handleTaskUnlink(linkedTasks[0].id) : undefined}
    >
      <div 
        className={`${styles.timeBlock} ${className}`}
        style={getCategoryStyle()}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        data-testid={`time-block-${timeBlock.id}`}
      >
        <div className={styles.timeInfo}>
          <div className={styles.timeRange}>
            {(() => {
              try {
                const startDate = parseTimeString(timeBlock.startTime);
                const endDate = parseTimeString(timeBlock.endTime);
                return `${format(startDate, 'h:mm a')} - ${format(endDate, 'h:mm a')}`;
              } catch (error) {
                console.warn('Error formatting time range:', error);
                return 'Invalid time';
              }
            })()}
          </div>
          <div className={styles.duration}>{formattedDuration}</div>
        </div>
        
        <div className={styles.content}>
          <h3 className={styles.title}>{timeBlock.title}</h3>
          
          {linkedTasks.length > 0 && (
            <div className={linkedTasks.length > 1 ? styles.linkedTasksContainer : styles.linkedTask}>
              {linkedTasks.map(task => (
                <div key={task.id} className={styles.linkedTask}>
                  <div className={styles.taskHeader}>
                    <Checkbox 
                      checked={task.completed}
                      onChange={handleTaskToggle(task.id)}
                      className={styles.checkbox}
                    />
                    <span className={`${styles.taskTitle} ${task.completed ? styles.completed : ''}`}>
                      {task.title}
                    </span>
                    {/* Link icon removed as requested */}
                  </div>
                  
                  {(getTaskProject(task) || getTaskCategory(task)) && (
                    <div className={styles.taskMeta}>
                      {getTaskProject(task) && (
                        <div className={styles.taskProject}>
                          {getTaskProject(task)!.title}
                        </div>
                      )}
                      
                      {getTaskCategory(task) && (
                        <div 
                          className={styles.taskCategory}
                          style={{ backgroundColor: getTaskCategory(task)!.color }}
                        >
                          {getTaskCategory(task)!.title}
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Display subtasks if they exist */}
                  {task.subtasks && task.subtasks.length > 0 && (
                    <div className={styles.subtasks}>
                      {task.subtasks.map(subtask => (
                        <div key={subtask.id} className={styles.subtask}>
                          <Checkbox 
                            checked={subtask.completed}
                            onChange={onTaskToggle ? (e) => onTaskToggle(subtask.id, e.target.checked) : undefined}
                            className={styles.checkbox}
                          />
                          <span className={`${styles.subtaskTitle} ${subtask.completed ? styles.completed : ''}`}>
                            {subtask.title}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </TimeBlockContextMenu>
  );
};