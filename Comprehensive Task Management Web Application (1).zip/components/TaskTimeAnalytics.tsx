import React, { useMemo } from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { Clock, Calendar, CheckCircle, Briefcase, Tag } from 'lucide-react';
import { useTimeEstimates } from '../helpers/useTimeEstimates';
import { Task } from '../helpers/TaskStorage';
import { 
  ChartContainer, 
  ChartTooltip, 
  ChartTooltipContent 
} from './Chart';
import styles from './TaskTimeAnalytics.module.css';

interface TaskTimeAnalyticsProps {
  className?: string;
  tasks?: Task[];
}

export const TaskTimeAnalytics: React.FC<TaskTimeAnalyticsProps> = ({ 
  className,
  tasks: propTasks
}) => {
  const { tasks: hookTasks, formatTime, totalEstimate } = useTimeEstimates();
  
  // Use provided tasks or fall back to all tasks from the hook
  const tasks = useMemo(() => propTasks || hookTasks, [propTasks, hookTasks]);
  
  // Calculate total estimated time
  const totalEstimatedTime = useMemo(() => {
    return tasks.reduce((total, task) => total + totalEstimate(task), 0);
  }, [tasks, totalEstimate]);
  
  // Calculate time for incomplete tasks
  const incompleteTasksTime = useMemo(() => {
    return tasks
      .filter(task => !task.completed)
      .reduce((total, task) => total + totalEstimate(task), 0);
  }, [tasks, totalEstimate]);
  
  // Calculate time for today's tasks
  const todayTasksTime = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return tasks
      .filter(task => {
        const dueDate = task.dueDate;
        return dueDate && dueDate >= today && dueDate < tomorrow;
      })
      .reduce((total, task) => total + totalEstimate(task), 0);
  }, [tasks, totalEstimate]);
  
  // Calculate completion rate
  const completionRate = useMemo(() => {
    const completedTasksTime = tasks
      .filter(task => task.completed)
      .reduce((total, task) => total + totalEstimate(task), 0);
    
    return totalEstimatedTime > 0 
      ? Math.round((completedTasksTime / totalEstimatedTime) * 100) 
      : 0;
  }, [tasks, totalEstimate, totalEstimatedTime]);
  
  // Group by project
  const projectData = useMemo(() => {
    const projectMap = new Map<string, number>();
    
    tasks.forEach(task => {
      if (task.projectId) {
        const currentTotal = projectMap.get(task.projectId) || 0;
        projectMap.set(task.projectId, currentTotal + totalEstimate(task));
      } else {
        const currentTotal = projectMap.get('unassigned') || 0;
        projectMap.set('unassigned', currentTotal + totalEstimate(task));
      }
    });
    
    // Convert to array for chart
    return Array.from(projectMap.entries())
      .map(([id, minutes]) => ({
        id,
        name: id === 'unassigned' ? 'Unassigned' : id,
        value: minutes,
        formattedValue: formatTime(minutes)
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5); // Top 5 projects
  }, [tasks, totalEstimate, formatTime]);
  
  // Group by category
  const categoryData = useMemo(() => {
    const categoryMap = new Map<string, number>();
    
    tasks.forEach(task => {
      if (task.categoryId) {
        const currentTotal = categoryMap.get(task.categoryId) || 0;
        categoryMap.set(task.categoryId, currentTotal + totalEstimate(task));
      } else {
        const currentTotal = categoryMap.get('uncategorized') || 0;
        categoryMap.set('uncategorized', currentTotal + totalEstimate(task));
      }
    });
    
    // Convert to array for chart
    return Array.from(categoryMap.entries())
      .map(([id, minutes]) => ({
        id,
        name: id === 'uncategorized' ? 'Uncategorized' : id,
        value: minutes,
        formattedValue: formatTime(minutes)
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5); // Top 5 categories
  }, [tasks, totalEstimate, formatTime]);
  
  // Chart configurations
  const projectChartConfig = {
    value: { label: 'Time' }
  };
  
  const categoryChartConfig = {
    value: { label: 'Time' }
  };
  
  const pieChartColors = [
    'var(--chart-color-1)',
    'var(--chart-color-2)',
    'var(--chart-color-3)',
    'var(--chart-color-4)',
    'var(--chart-color-5)',
  ];
  
  return (
    <div className={`${styles.container} ${className || ''}`}>
      <h2 className={styles.title}>Time Analytics</h2>
      
      {/* Summary statistics */}
      <div className={styles.summaryGrid}>
        <div className={styles.statCard}>
          <Clock className={styles.statIcon} />
          <div className={styles.statContent}>
            <h3 className={styles.statTitle}>Total Estimated</h3>
            <p className={styles.statValue}>{formatTime(totalEstimatedTime)}</p>
          </div>
        </div>
        
        <div className={styles.statCard}>
          <CheckCircle className={styles.statIcon} />
          <div className={styles.statContent}>
            <h3 className={styles.statTitle}>Incomplete Tasks</h3>
            <p className={styles.statValue}>{formatTime(incompleteTasksTime)}</p>
          </div>
        </div>
        
        <div className={styles.statCard}>
          <Calendar className={styles.statIcon} />
          <div className={styles.statContent}>
            <h3 className={styles.statTitle}>Today's Tasks</h3>
            <p className={styles.statValue}>{formatTime(todayTasksTime)}</p>
          </div>
        </div>
      </div>
      
      {/* Project breakdown */}
      <div className={styles.chartSection}>
        <h3 className={styles.sectionTitle}>
          <Briefcase size={18} />
          Time by Project
        </h3>
        
        <div className={styles.chartContainer}>
          {projectData.length > 0 ? (
            <ChartContainer config={projectChartConfig}>
              <BarChart data={projectData}>
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar 
                  dataKey="value" 
                  fill="var(--chart-color-1)" 
                  name="Time" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ChartContainer>
          ) : (
            <div className={styles.emptyChart}>No project data available</div>
          )}
        </div>
      </div>
      
      {/* Category breakdown */}
      <div className={styles.chartSection}>
        <h3 className={styles.sectionTitle}>
          <Tag size={18} />
          Time by Category
        </h3>
        
        <div className={styles.chartContainer}>
          {categoryData.length > 0 ? (
            <div className={styles.pieChartWrapper}>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={({ name, percent }) => 
                      `${name}: ${Math.round(percent * 100)}%`
                    }
                    labelLine={false}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={pieChartColors[index % pieChartColors.length]} 
                      />
                    ))}
                  </Pie>
                  <ChartTooltip 
                    formatter={(value: number) => formatTime(value)}
                  />
                </PieChart>
              </ResponsiveContainer>
              
              <div className={styles.pieChartLegend}>
                {categoryData.map((entry, index) => (
                  <div key={entry.id} className={styles.legendItem}>
                    <div 
                      className={styles.legendColor} 
                      style={{ backgroundColor: pieChartColors[index % pieChartColors.length] }}
                    />
                    <span className={styles.legendName}>{entry.name}</span>
                    <span className={styles.legendValue}>{entry.formattedValue}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className={styles.emptyChart}>No category data available</div>
          )}
        </div>
      </div>
      
      {/* Completion rate */}
      <div className={styles.completionSection}>
        <h3 className={styles.sectionTitle}>Completion Rate</h3>
        
        <div className={styles.progressContainer}>
          <div className={styles.progressBar}>
            <div 
              className={styles.progressFill} 
              style={{ width: `${completionRate}%` }}
            />
          </div>
          <div className={styles.progressLabel}>
            {completionRate}% of estimated time completed
          </div>
        </div>
      </div>
    </div>
  );
};