import React from 'react';
import { Battery, BatteryLow, BatteryMedium, BatteryFull, Zap, Heart, Brain } from 'lucide-react';
import { RadioGroup, RadioGroupItem } from './RadioGroup';
import { Label } from './Label';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './Tooltip';
import { Task } from '../helpers/TaskStorage';
import styles from './TaskEnergyEditor.module.css';
import { useIsMobile } from '../helpers/useIsMobile';

interface TaskEnergyEditorProps {
  task: Task;
  onChange: (updates: Partial<Task>) => void;
  className?: string;
}

export const TaskEnergyEditor = ({ 
  task, 
  onChange, 
  className = '' 
}: TaskEnergyEditorProps) => {
  const isMobile = useIsMobile();
  
  const handleEnergyLevelChange = (value: string) => {
    onChange({ 
      energyLevel: value as 'low' | 'medium' | 'high' 
    });
  };

  const handleEmotionalWeightChange = (value: string) => {
    onChange({
      emotionalWeight: value as 'none' | 'minimal' | 'significant'
    });
  };

  const handleMentalComplexityChange = (value: string) => {
    onChange({
      mentalComplexity: value as 'easy' | 'moderate' | 'complex'
    });
  };

  const renderEnergyIcon = (level: string) => {
    switch (level) {
      case 'low':
        return <BatteryLow size={isMobile ? 16 : 18} className={styles.lowIcon} />;
      case 'medium':
        return <BatteryMedium size={isMobile ? 16 : 18} className={styles.mediumIcon} />;
      case 'high':
        return <BatteryFull size={isMobile ? 16 : 18} className={styles.highIcon} />;
      default:
        return <Battery size={isMobile ? 16 : 18} />;
    }
  };

  const renderEmotionalIcon = (level: string) => {
    const size = isMobile ? 16 : 18;
    switch (level) {
      case 'none':
        return <Heart size={size} className={styles.emotionalNone} />;
      case 'minimal':
        return <Heart size={size} className={styles.emotionalMinimal} />;
      case 'significant':
        return <Heart size={size} className={styles.emotionalSignificant} />;
      default:
        return <Heart size={size} />;
    }
  };

  const renderComplexityIcon = (level: string) => {
    const size = isMobile ? 16 : 18;
    switch (level) {
      case 'easy':
        return <Brain size={size} className={styles.complexityEasy} />;
      case 'moderate':
        return <Brain size={size} className={styles.complexityModerate} />;
      case 'complex':
        return <Brain size={size} className={styles.complexityComplex} />;
      default:
        return <Brain size={size} />;
    }
  };

  return (
    <div className={`${styles.container} ${className}`}>
      <TooltipProvider>
        <div className={styles.section}>
          <div className={styles.sectionHeader}>
            <h3 className={styles.sectionTitle}>Energy Level Required</h3>
            <Tooltip>
              <TooltipTrigger className={styles.infoTrigger}>?</TooltipTrigger>
              <TooltipContent>
                <p>How much energy do you need to complete this task?</p>
                <ul className={styles.tooltipList}>
                  <li><strong>Low:</strong> Can do when tired or distracted</li>
                  <li><strong>Medium:</strong> Requires some focus and energy</li>
                  <li><strong>High:</strong> Needs full concentration and energy</li>
                </ul>
              </TooltipContent>
            </Tooltip>
          </div>
          
          <RadioGroup 
            value={task.energyLevel || 'medium'} 
            onValueChange={handleEnergyLevelChange}
            className={styles.radioGroup}
          >
            <div className={styles.optionsContainer}>
              <div className={styles.option}>
                <RadioGroupItem value="low" id="energy-low" />
                <Label htmlFor="energy-low" className={styles.radioLabel}>
                  {renderEnergyIcon('low')}
                  <span>Low</span>
                </Label>
              </div>
              
              <div className={styles.option}>
                <RadioGroupItem value="medium" id="energy-medium" />
                <Label htmlFor="energy-medium" className={styles.radioLabel}>
                  {renderEnergyIcon('medium')}
                  <span>Medium</span>
                </Label>
              </div>
              
              <div className={styles.option}>
                <RadioGroupItem value="high" id="energy-high" />
                <Label htmlFor="energy-high" className={styles.radioLabel}>
                  {renderEnergyIcon('high')}
                  <span>High</span>
                </Label>
              </div>
            </div>
          </RadioGroup>
        </div>

        <div className={styles.section}>
          <div className={styles.sectionHeader}>
            <h3 className={styles.sectionTitle}>Emotional Weight</h3>
            <Tooltip>
              <TooltipTrigger className={styles.infoTrigger}>?</TooltipTrigger>
              <TooltipContent>
                <p>How emotionally challenging is this task?</p>
                <ul className={styles.tooltipList}>
                  <li><strong>None:</strong> No emotional impact</li>
                  <li><strong>Minimal:</strong> Slight emotional resistance</li>
                  <li><strong>Significant:</strong> Strong emotional resistance</li>
                </ul>
              </TooltipContent>
            </Tooltip>
          </div>
          
          <RadioGroup 
            value={task.emotionalWeight || 'none'} 
            onValueChange={handleEmotionalWeightChange}
            className={styles.radioGroup}
          >
            <div className={styles.optionsContainer}>
              <div className={styles.option}>
                <RadioGroupItem value="none" id="emotional-none" />
                <Label htmlFor="emotional-none" className={styles.radioLabel}>
                  {renderEmotionalIcon('none')}
                  <span>None</span>
                </Label>
              </div>
              
              <div className={styles.option}>
                <RadioGroupItem value="minimal" id="emotional-minimal" />
                <Label htmlFor="emotional-minimal" className={styles.radioLabel}>
                  {renderEmotionalIcon('minimal')}
                  <span>Minimal</span>
                </Label>
              </div>
              
              <div className={styles.option}>
                <RadioGroupItem value="significant" id="emotional-significant" />
                <Label htmlFor="emotional-significant" className={styles.radioLabel}>
                  {renderEmotionalIcon('significant')}
                  <span>Significant</span>
                </Label>
              </div>
            </div>
          </RadioGroup>
        </div>

        <div className={styles.section}>
          <div className={styles.sectionHeader}>
            <h3 className={styles.sectionTitle}>Mental Complexity</h3>
            <Tooltip>
              <TooltipTrigger className={styles.infoTrigger}>?</TooltipTrigger>
              <TooltipContent>
                <p>How mentally demanding is this task?</p>
                <ul className={styles.tooltipList}>
                  <li><strong>Easy:</strong> Simple, straightforward thinking</li>
                  <li><strong>Moderate:</strong> Requires some problem-solving</li>
                  <li><strong>Complex:</strong> Needs deep focus and analysis</li>
                </ul>
              </TooltipContent>
            </Tooltip>
          </div>
          
          <RadioGroup 
            value={task.mentalComplexity || 'easy'} 
            onValueChange={handleMentalComplexityChange}
            className={styles.radioGroup}
          >
            <div className={styles.optionsContainer}>
              <div className={styles.option}>
                <RadioGroupItem value="easy" id="complexity-easy" />
                <Label htmlFor="complexity-easy" className={styles.radioLabel}>
                  {renderComplexityIcon('easy')}
                  <span>Easy</span>
                </Label>
              </div>
              
              <div className={styles.option}>
                <RadioGroupItem value="moderate" id="complexity-moderate" />
                <Label htmlFor="complexity-moderate" className={styles.radioLabel}>
                  {renderComplexityIcon('moderate')}
                  <span>Moderate</span>
                </Label>
              </div>
              
              <div className={styles.option}>
                <RadioGroupItem value="complex" id="complexity-complex" />
                <Label htmlFor="complexity-complex" className={styles.radioLabel}>
                  {renderComplexityIcon('complex')}
                  <span>Complex</span>
                </Label>
              </div>
            </div>
          </RadioGroup>
        </div>
      </TooltipProvider>
    </div>
  );
};