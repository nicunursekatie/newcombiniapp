import React, { useEffect, useMemo } from 'react';
import { useWorkScheduleModifiers } from '../helpers/useWorkScheduleModifiers';
import { AlertCircle } from 'lucide-react';
import styles from './WorkSchedulePrefetcher.module.css';

interface WorkSchedulePrefetcherProps {
  startDate: Date;
  endDate: Date;
  showErrorIndicator?: boolean;
}

/**
 * A component that prefetches work schedule data for a date range
 * and caches it in React Query, so individual calendar components
 * can reuse the cached data instead of making separate API calls.
 */
export const WorkSchedulePrefetcher: React.FC<WorkSchedulePrefetcherProps> = ({
  startDate,
  endDate,
  showErrorIndicator = true,
}) => {
  // Memoize the date range to avoid unnecessary re-fetches
  const dateRange = useMemo(() => {
    return {
      start: startDate,
      end: endDate,
    };
  }, [startDate.toISOString(), endDate.toISOString()]);

  // This hook will fetch and cache the work schedule data
  // for the given date range
  const { isLoading, error } = useWorkScheduleModifiers(
    dateRange.start,
    dateRange.end
  );

  // This effect is kept for potential future instrumentation
  // but console logs have been removed
  useEffect(() => {
    // Prefetching work schedule data for the date range
    // The useWorkScheduleModifiers hook handles the actual data fetching
  }, [dateRange.start, dateRange.end, isLoading, error]);

  // Only render the error indicator if there's an error and showErrorIndicator is true
  if (error && showErrorIndicator) {
    return (
      <div className={styles.errorContainer} title={`Error: ${error.message}`}>
        <AlertCircle className={styles.errorIcon} size={16} />
        <span className={styles.errorText}>Schedule data error</span>
      </div>
    );
  }

  // This component doesn't render anything visible when there's no error
  return null;
};