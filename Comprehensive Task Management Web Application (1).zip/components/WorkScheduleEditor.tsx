import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Calendar } from "./Calendar";
import { format } from "date-fns";
import { Popover, PopoverContent, PopoverTrigger } from "./Popover";
import { Button } from "./Button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./Tooltip";
import { Sun, Sunrise, Sunset, X, HelpCircle, CheckCircle } from "lucide-react";
import { useWorkSchedule, ScheduleType, WorkDay } from "../helpers/useWorkSchedule";
import { toast } from "sonner";
import styles from "./WorkScheduleEditor.module.css";

interface WorkScheduleEditorProps {
  className?: string;
  onClose?: () => void;
  initialDate?: Date;
}

// Helper function to compare dates without time
const isSameDay = (date1: Date, date2: Date): boolean => {
  // Normalize both dates to remove time component
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  
  d1.setHours(0, 0, 0, 0);
  d2.setHours(0, 0, 0, 0);
  
  return d1.getTime() === d2.getTime();
};

export const WorkScheduleEditor: React.FC<WorkScheduleEditorProps> = ({
  className,
  onClose,
  initialDate,
}) => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(initialDate || new Date());
  const [selectedMonth, setSelectedMonth] = useState<Date>(initialDate || new Date());
  const [scheduleType, setScheduleType] = useState<ScheduleType | null>(null);
  const [workDays, setWorkDays] = useState<WorkDay[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const { getSchedule, addWorkDay, updateWorkDay, removeWorkDay } = useWorkSchedule();

  // Helper function to format date for display
  const formatDate = (date: Date): string => {
    return date.toLocaleDateString(undefined, { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  // Load work schedule for the current month
  useEffect(() => {
    const loadSchedule = async () => {
      setIsLoading(true);
      try {
        // Calculate first and last day of the month
        const firstDay = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth(), 1);
        const lastDay = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1, 0);
        
        const schedule = await getSchedule(firstDay, lastDay);
        setWorkDays(schedule);
        
        // If a date is selected, update the schedule type
        if (selectedDate) {
          const workDay = schedule.find(
            (day) => day.date.toDateString() === selectedDate.toDateString()
          );
          setScheduleType(workDay?.type || null);
        }
      } catch (error) {
        console.error("[WorkScheduleEditor] Error loading schedule:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadSchedule();
  }, [selectedMonth, getSchedule, selectedDate]);

  // Update schedule type when selected date changes
  useEffect(() => {
    if (selectedDate) {
      // Normalize selected date for comparison
      const normalizedSelectedDate = new Date(selectedDate);
      normalizedSelectedDate.setHours(0, 0, 0, 0);
      
      console.log("[WorkScheduleEditor] Looking for schedule type for date:", normalizedSelectedDate.toISOString());
      
      const workDay = workDays.find(
        (day) => isSameDay(new Date(day.date), normalizedSelectedDate)
      );
      
      console.log("[WorkScheduleEditor] Found work day:", workDay);
      setScheduleType(workDay?.type || null);
    }
  }, [selectedDate, workDays]);

  // Handle month change in calendar
  const handleMonthChange = (month: Date) => {
    setSelectedMonth(month);
  };

  // Helper function to get schedule description
  const getScheduleDescription = (type: ScheduleType): string => {
    return type === "full" 
      ? "Full day (7:00 AM - 7:00 PM)" 
      : type === "morning" 
        ? "Morning (7:00 AM - 1:00 PM)" 
        : "Afternoon (1:00 PM - 7:00 PM)";
  };

  // Helper function to save schedule changes
  const saveScheduleChange = useCallback(async (date: Date, type: ScheduleType | null) => {
    console.log(`[WorkScheduleEditor] saveScheduleChange called with date:`, date, `type:`, type);

    setIsSaving(true);
    
    // Create a deep copy of the date to avoid reference issues
    const dateForUpdate = new Date(date.getTime());
    
    // Apply optimistic update to UI immediately
    const updatedWorkDays = [...workDays];
    const existingIndex = updatedWorkDays.findIndex(
      (day) => isSameDay(new Date(day.date), dateForUpdate)
    );
    
    // Optimistically update the local state
    if (type === null) {
      // Remove from local state if it exists
      if (existingIndex !== -1) {
        updatedWorkDays.splice(existingIndex, 1);
      }
    } else {
      // Add or update in local state
      const { startTime, endTime } = type === "full" 
        ? { startTime: "07:00", endTime: "19:00" } 
        : type === "morning" 
          ? { startTime: "07:00", endTime: "13:00" } 
          : { startTime: "13:00", endTime: "19:00" };
          
      if (existingIndex !== -1) {
        updatedWorkDays[existingIndex] = { 
          ...updatedWorkDays[existingIndex], 
          type, 
          startTime, 
          endTime 
        };
      } else {
        updatedWorkDays.push({ 
          date: dateForUpdate, 
          type, 
          startTime, 
          endTime 
        });
      }
    }
    
    console.log("[WorkScheduleEditor] Optimistically updating workDays:", updatedWorkDays);
    
    // Update UI immediately with optimistic data - create a new array to ensure state change is detected
    console.log("[WorkScheduleEditor] Setting optimistic workDays update:", updatedWorkDays);
    setWorkDays([...updatedWorkDays]);
    setScheduleType(type);
    
    try {
      const existingWorkDay = existingIndex !== -1 ? updatedWorkDays[existingIndex] : undefined;
      
      if (type === null) {
        // Remove work day if it exists
        if (existingWorkDay) {
          console.log(`[WorkScheduleEditor] Removing work day`);
          await removeWorkDay(date);
          console.log(`[WorkScheduleEditor] Work day removed successfully`);
          toast.success("Schedule removed", {
            description: `No work scheduled for ${format(date, 'MMMM d, yyyy')}`,
            icon: <X size={18} />
          });
        }
      } else if (existingWorkDay) {
        // Update existing work day
        console.log(`[WorkScheduleEditor] Updating work day to type:`, type);
        await updateWorkDay(date, type);
        console.log(`[WorkScheduleEditor] Work day updated successfully`);
        
        toast.success("Schedule updated", {
          description: `${format(date, 'MMMM d, yyyy')}: ${getScheduleDescription(type)}`,
          icon: <CheckCircle size={18} />
        });
      } else {
        // Add new work day
        console.log(`[WorkScheduleEditor] Adding new work day with type:`, type);
        await addWorkDay(date, type);
        console.log(`[WorkScheduleEditor] New work day added successfully`);
        
        toast.success("Schedule added", {
          description: `${format(date, 'MMMM d, yyyy')}: ${getScheduleDescription(type)}`,
          icon: <CheckCircle size={18} />
        });
      }
      
      // Force refresh the schedule after saving to ensure data consistency
      const firstDay = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth(), 1);
      const lastDay = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1, 0);
      console.log("[WorkScheduleEditor] Refreshing schedule from server after save");
      const serverSchedule = await getSchedule(firstDay, lastDay);
      console.log("[WorkScheduleEditor] Server schedule after save:", serverSchedule);
      setWorkDays(serverSchedule);
      
      // Update the selected date's schedule type based on refreshed data
      if (selectedDate) {
        const refreshedWorkDay = serverSchedule.find(
          (day) => isSameDay(new Date(day.date), selectedDate)
        );
        console.log("[WorkScheduleEditor] Refreshed work day for selected date:", refreshedWorkDay);
        setScheduleType(refreshedWorkDay?.type || null);
      }
      
    } catch (error) {
      console.error(`[WorkScheduleEditor] Error saving schedule change:`, error);
      toast.error("Failed to update schedule", {
        description: "Please try again later",
      });
      
      // Revert optimistic update on error by refreshing from server
      const firstDay = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth(), 1);
      const lastDay = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1, 0);
      try {
        const revertedSchedule = await getSchedule(firstDay, lastDay);
        setWorkDays(revertedSchedule);
        
        // Update selected schedule type based on reverted data
        if (selectedDate) {
          const workDay = revertedSchedule.find(
            (day) => isSameDay(new Date(day.date), selectedDate)
          );
          setScheduleType(workDay?.type || null);
        }
      } catch (secondError) {
        console.error("[WorkScheduleEditor] Failed to revert optimistic update:", secondError);
      }
    } finally {
      setIsSaving(false);
    }
  }, [workDays, removeWorkDay, updateWorkDay, addWorkDay, selectedMonth, getSchedule]);

  // Handle schedule type selection
  const handleScheduleTypeSelect = useCallback((type: ScheduleType | null) => {
    if (!selectedDate) {
      toast.error("Please select a date first", {
        description: "Select a date on the calendar before setting a schedule",
      });
      return;
    }
    
    setScheduleType(type);
    saveScheduleChange(selectedDate, type);
  }, [selectedDate, saveScheduleChange]);



  // Create modifiers for the calendar - ensure names match exactly with CSS classes in Calendar.module.css
  const calendarModifiers = useMemo(() => {
    console.log("[WorkScheduleEditor] Creating calendar modifiers from workDays:", workDays);
    
    // Normalize dates to avoid time-related comparison issues
    const normalizeDate = (date: Date): Date => {
      const normalized = new Date(date);
      normalized.setHours(0, 0, 0, 0);
      return normalized;
    };
    
    const fullDays = workDays
      .filter(wd => wd.type === "full")
      .map(wd => {
        const date = normalizeDate(new Date(wd.date));
        console.log(`[WorkScheduleEditor] Adding full day modifier for: ${date.toISOString()}`);
        return date;
      });
      
    const morningDays = workDays
      .filter(wd => wd.type === "morning")
      .map(wd => {
        const date = normalizeDate(new Date(wd.date));
        console.log(`[WorkScheduleEditor] Adding morning modifier for: ${date.toISOString()}`);
        return date;
      });
      
    const afternoonDays = workDays
      .filter(wd => wd.type === "afternoon")
      .map(wd => {
        const date = normalizeDate(new Date(wd.date));
        console.log(`[WorkScheduleEditor] Adding afternoon modifier for: ${date.toISOString()}`);
        return date;
      });
    
    console.log("[WorkScheduleEditor] Final modifiers:", {
      fullDaySchedule: fullDays,
      morningSchedule: morningDays,
      afternoonSchedule: afternoonDays
    });
    
    return {
      fullDaySchedule: fullDays,
      morningSchedule: morningDays,
      afternoonSchedule: afternoonDays
    };
  }, [workDays]);

  // Log workDays changes for debugging
  useEffect(() => {
    console.log("[WorkScheduleEditor] workDays updated:", workDays);
    
    // Debug date comparison logic
    if (workDays.length > 0 && selectedDate) {
      // Normalize selected date for comparison
      const normalizedSelectedDate = new Date(selectedDate);
      normalizedSelectedDate.setHours(0, 0, 0, 0);
      
      const matchingDay = workDays.find(day => 
        isSameDay(new Date(day.date), normalizedSelectedDate)
      );
      
      console.log("[WorkScheduleEditor] Selected date:", normalizedSelectedDate.toISOString());
      console.log("[WorkScheduleEditor] Date comparison test:");
      
      workDays.forEach(day => {
        const dayDate = new Date(day.date);
        dayDate.setHours(0, 0, 0, 0);
        
        const isMatch = isSameDay(dayDate, normalizedSelectedDate);
        console.log(`- Day ${dayDate.toISOString()} matches selected date: ${isMatch}`);
        console.log(`  Normalized day: ${dayDate.toISOString()}`);
        console.log(`  Normalized selected: ${normalizedSelectedDate.toISOString()}`);
        console.log(`  Time comparison: ${dayDate.getTime() === normalizedSelectedDate.getTime()}`);
      });
      
      console.log("[WorkScheduleEditor] Found matching day:", matchingDay);
    }
    
    // Log calendar modifiers for debugging
    console.log("[WorkScheduleEditor] Current calendar modifiers:", calendarModifiers);
  }, [workDays, selectedDate, calendarModifiers]);

  return (
    <div className={`${styles.container} ${className || ""}`}>
      <div className={styles.header}>
        <h2 className={styles.title}>Work Schedule</h2>
        {onClose && (
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="Close">
            <X size={18} />
          </Button>
        )}
      </div>
      
      <div className={styles.mainContent}>
        <div className={styles.calendarContainer}>
          <Calendar
            key={`calendar-${workDays.length}-${selectedDate?.toISOString() || 'none'}-${JSON.stringify(calendarModifiers)}`}
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            onMonthChange={handleMonthChange}
            className={styles.calendar}
            modifiers={calendarModifiers}
            footer={
          <div className={styles.calendarLegend}>
            <div className={`${styles.legendItem} ${styles.legendFullDay}`}>
              <Sun className={styles.fullDayIcon} size={14} />
              <span>Full day</span>
            </div>
            <div className={`${styles.legendItem} ${styles.legendMorning}`}>
              <Sunrise className={styles.morningIcon} size={14} />
              <span>Morning</span>
            </div>
            <div className={`${styles.legendItem} ${styles.legendAfternoon}`}>
              <Sunset className={styles.afternoonIcon} size={14} />
              <span>Afternoon</span>
            </div>
          </div>
            }
          />
        </div>
      
        <div className={styles.scheduleControls}>
          <div className={styles.selectedDate}>
            <h3>{selectedDate ? formatDate(selectedDate) : "Select a date"}</h3>
            {isSaving && <p className={styles.savingIndicator}>Saving...</p>}
            {!isSaving && selectedDate && (
              <p className={styles.scheduleInfo}>
                {scheduleType === "full" && "Full day: 7:00 AM - 7:00 PM"}
                {scheduleType === "morning" && "Morning: 7:00 AM - 1:00 PM"}
                {scheduleType === "afternoon" && "Afternoon: 1:00 PM - 7:00 PM"}
                {scheduleType === null && "No work scheduled"}
              </p>
            )}
          </div>
          
          <div className={styles.scheduleTypeButtonsContainer}>
            <div className={styles.scheduleTypeButtons}>
              <Button 
                variant={scheduleType === "full" ? "primary" : "outline"}
                onClick={() => handleScheduleTypeSelect("full")}
                disabled={!selectedDate || isLoading || isSaving}
                className={styles.scheduleButton}
                size="sm"
              >
                <Sun size={14} className={styles.fullDayIcon} />
                Full Day
              </Button>
              
              <Button 
                variant={scheduleType === "morning" ? "primary" : "outline"}
                onClick={() => handleScheduleTypeSelect("morning")}
                disabled={!selectedDate || isLoading || isSaving}
                className={styles.scheduleButton}
                size="sm"
              >
                <Sunrise size={14} className={styles.morningIcon} />
                Morning
              </Button>
              
              <Button 
                variant={scheduleType === "afternoon" ? "primary" : "outline"}
                onClick={() => handleScheduleTypeSelect("afternoon")}
                disabled={!selectedDate || isLoading || isSaving}
                className={styles.scheduleButton}
                size="sm"
              >
                <Sunset size={14} className={styles.afternoonIcon} />
                Afternoon
              </Button>
            </div>
            
            <Button 
              variant={scheduleType === null ? "primary" : "outline"}
              onClick={() => handleScheduleTypeSelect(null)}
              disabled={!selectedDate || isLoading || isSaving}
              className={styles.noScheduleButton}
              size="sm"
            >
              <X size={14} />
              No Schedule
            </Button>
          </div>
        </div>
      </div>
      
      {onClose && (
        <div className={styles.footer}>
          <Button variant="outline" size="sm" onClick={onClose}>
            Close
          </Button>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon-sm" className={styles.helpButton}>
                  <HelpCircle size={14} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Select a date on the calendar, then use the buttons to set your schedule type.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      )}
    </div>
  );
};