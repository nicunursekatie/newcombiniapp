"use client";

import React, { useState, useEffect } from 'react';
import { format, isValid } from 'date-fns';
import { 
  Calendar as CalendarIcon, 
  Tag, 
  FolderKanban, 
  Trash2, 
  Check,
  X,
  Clock,
  Info,
  HelpCircle
} from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './Tooltip';
import { DatePickerWithShortcuts } from './DatePickerWithShortcuts';
import { TaskEnergyEditor } from './TaskEnergyEditor';
import { SubtaskManager } from './SubtaskManager';
import styles from './TaskDetail.module.css';
import { Task, Project, Category } from '../helpers/TaskStorage';
import { Input } from './Input';
import { Textarea } from './Textarea';
import { Button } from './Button';
import { Checkbox } from './Checkbox';
import { Badge } from './Badge';
import { Separator } from './Separator';

interface TaskDetailProps {
  task: Task | null;
  projects: Project[];
  categories: Category[];
  onSave: (task: Task) => void;
  onDelete: (taskId: string) => void;
  onAddSubtask: (parentId: string, subtask: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onClose?: () => void;
  className?: string;
}

export const TaskDetail = ({
  task,
  projects,
  categories,
  onSave,
  onDelete,
  onAddSubtask,
  onClose,
  className = '',
}: TaskDetailProps) => {
  const [editedTask, setEditedTask] = useState<Task | null>(null);
  const [totalEstimate, setTotalEstimate] = useState<number>(0);

  // Initialize form when task changes
  useEffect(() => {
    setEditedTask(task ? { ...task } : null);
  }, [task]);
  
  // Calculate total time estimate and update parent task estimate if it has subtasks
  useEffect(() => {
    if (!editedTask) {
      setTotalEstimate(0);
      return;
    }
    
    const hasSubtasks = editedTask.subtasks && editedTask.subtasks.length > 0;
    
    if (hasSubtasks && editedTask.subtasks) {
      // Calculate sum of subtask estimates
      const subtasksTotal = editedTask.subtasks.reduce((sum, subtask) => 
        sum + (subtask.estimatedMinutes || 0), 0);
      
      // Automatically set parent task's estimate to match subtasks total
      setEditedTask(prev => {
        if (!prev) return null;
        return { ...prev, estimatedMinutes: subtasksTotal };
      });
      
      setTotalEstimate(subtasksTotal);
    } else {
      // For tasks without subtasks, just use their own estimate
      setTotalEstimate(editedTask.estimatedMinutes || 0);
    }
  }, [editedTask?.subtasks]);

  if (!editedTask) {
    return (
      <div className={`${styles.container} ${className}`}>
        <div className={styles.emptyState}>
          <p>Select a task to view details</p>
        </div>
      </div>
    );
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditedTask(prev => {
      if (!prev) return null;
      return { ...prev, [name]: value };
    });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setEditedTask(prev => {
      if (!prev) return null;
      return { ...prev, [name]: checked };
    });
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setEditedTask(prev => {
      if (!prev) return null;
      
      // If value is empty, clear the date
      if (!value) {
        return { ...prev, dueDate: undefined };
      }
      
      // Create date at noon to avoid timezone issues
      const date = new Date(`${value}T12:00:00`);
      
      // Only set the date if it's valid
      if (isValid(date)) {
        return { ...prev, dueDate: date };
      }
      
      // If invalid date, keep the previous value
      return prev;
    });
  };

  const handleSave = () => {
    if (editedTask) {
      onSave(editedTask);
    }
  };

  const handleDelete = () => {
    if (editedTask) {
      onDelete(editedTask.id);
      if (onClose) onClose();
    }
  };

  const handleAddSubtask = (subtaskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (!editedTask) return;
    
    onAddSubtask(editedTask.id, {
      ...subtaskData,
      parentTaskId: editedTask.id,
      projectId: editedTask.projectId,
      categoryId: editedTask.categoryId,
    });
  };

  const handleSubtaskChange = (updatedSubtask: Task) => {
    if (!editedTask || !editedTask.subtasks) return;
    
    const updatedSubtasks = editedTask.subtasks.map(subtask => 
      subtask.id === updatedSubtask.id ? updatedSubtask : subtask
    );
    
    // Update subtasks array
    setEditedTask({
      ...editedTask,
      subtasks: updatedSubtasks
    });
  };
  
  const handleReorderSubtasks = (fromIndex: number, toIndex: number) => {
    if (!editedTask?.subtasks) return;
    
    const newSubtasks = [...editedTask.subtasks];
    const [movedItem] = newSubtasks.splice(fromIndex, 1);
    newSubtasks.splice(toIndex, 0, movedItem);
    
    setEditedTask({
      ...editedTask,
      subtasks: newSubtasks
    });
  };
  
  // Check if task has subtasks
  const hasSubtasks = editedTask?.subtasks && editedTask.subtasks.length > 0;

  // Find the category for the current task
  const taskCategory = categories.find(cat => cat.id === editedTask.categoryId);

  return (
    <div className={`${styles.container} ${className}`}>
      <div className={styles.header}>
        <h2 className={styles.title}>Task Details</h2>
        {onClose && (
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="Close">
            <X size={18} />
          </Button>
        )}
      </div>

      <div className={styles.form}>
        <div className={styles.formGroup}>
          <div className={styles.formRow}>
            <Checkbox 
              id="completed" 
              name="completed"
              checked={editedTask.completed} 
              onChange={handleCheckboxChange} 
            />
            <Input
              name="title"
              value={editedTask.title}
              onChange={handleChange}
              placeholder="Task title"
              className={styles.titleInput}
            />
          </div>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Description</label>
          <Textarea
            name="description"
            value={editedTask.description || ''}
            onChange={handleChange}
            placeholder="Add description..."
            className={styles.description}
          />
        </div>

        <div className={styles.formRow}>
          <div className={styles.formGroup}>
            <label className={styles.label}>
              <CalendarIcon size={16} className={styles.labelIcon} />
              Due Date
            </label>
            <DatePickerWithShortcuts
              value={editedTask.dueDate && isValid(editedTask.dueDate) ? editedTask.dueDate : undefined}
              onChange={(date) => {
                setEditedTask(prev => {
                  if (!prev) return null;
                  return { ...prev, dueDate: date };
                });
              }}
              placeholder="Select due date"
              showWorkSchedule={true}
            />
          </div>
        </div>

        <div className={styles.formRow}>
          <div className={styles.formGroup}>
            <label className={styles.label}>
              <FolderKanban size={16} className={styles.labelIcon} />
              Project
            </label>
            <select
              name="projectId"
              value={editedTask.projectId || ''}
              onChange={handleChange}
              className={styles.select}
            >
              <option value="">No Project</option>
              {projects.map(project => (
                <option key={project.id} value={project.id}>
                  {project.title}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.formGroup}>
            <label className={styles.label}>
              <Tag size={16} className={styles.labelIcon} />
              Category
            </label>
            <select
              name="categoryId"
              value={editedTask.categoryId || ''}
              onChange={handleChange}
              className={styles.select}
            >
              <option value="">No Category</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        {taskCategory && (
          <div className={styles.categoryBadge}>
            <Badge 
              style={{ backgroundColor: taskCategory.color, color: 'white' }}
            >
              {taskCategory.title}
            </Badge>
          </div>
        )}

        <div className={styles.formRow}>
          <div className={styles.formGroup}>
            <label className={styles.label}>
              <Clock size={16} className={styles.labelIcon} />
              Time Estimate (minutes)
            </label>
            <div className={styles.estimateInputWrapper}>
              <Input
                type="number"
                name="estimatedMinutes"
                value={editedTask.estimatedMinutes || ''}
                onChange={(e) => {
                  if (hasSubtasks) return;
                  const value = e.target.value ? parseInt(e.target.value, 10) : undefined;
                  setEditedTask(prev => prev ? { ...prev, estimatedMinutes: value } : null);
                }}
                min="0"
                placeholder="0"
                className={styles.numberInput}
                disabled={hasSubtasks}
                readOnly={hasSubtasks}
              />
              {hasSubtasks && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button type="button" className={styles.helpButton} aria-label="Time estimate info">
                        <HelpCircle size={16} />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>
                      Time estimate is automatically calculated from subtasks ({editedTask.estimatedMinutes || 0} minutes)
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
          </div>
          
          <div className={styles.formGroup}>
            <label className={styles.label}>Priority</label>
            <select
              name="priority"
              value={editedTask.priority || ''}
              onChange={handleChange}
              className={styles.select}
            >
              <option value="">Not set</option>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>

        <div className={styles.energySection}>
          <TaskEnergyEditor 
            task={editedTask} 
            onChange={(updates) => {
              setEditedTask(prev => prev ? { ...prev, ...updates } : null);
            }}
          />
        </div>
        
        {totalEstimate > 0 && (
          <div className={styles.totalEstimate}>
            <Clock size={16} />
            <span>Total time estimate: {totalEstimate} minutes</span>
          </div>
        )}

        <Separator />

        <div className={styles.subtasksSection}>
          <h3 className={styles.subtasksTitle}>Subtasks</h3>
          
          <SubtaskManager
            subtasks={editedTask.subtasks || []}
            onSubtaskChange={handleSubtaskChange}
            onAddSubtask={handleAddSubtask}
            onReorderSubtasks={handleReorderSubtasks}
            parentTaskId={editedTask.id}
            className={styles.subtaskManager}
          />
        </div>

        <div className={styles.actions}>
          <Button variant="destructive" onClick={handleDelete}>
            <Trash2 size={16} /> Delete
          </Button>
          <Button onClick={handleSave}>
            <Check size={16} /> Save Changes
          </Button>
        </div>
      </div>
    </div>
  );
};