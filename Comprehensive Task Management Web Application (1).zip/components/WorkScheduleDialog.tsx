import React from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "./Dialog";
import { Button } from "./Button";
import { WorkScheduleEditor } from "./WorkScheduleEditor";
import { Calendar as CalendarIcon } from "lucide-react";
import styles from "./WorkScheduleDialog.module.css";

interface WorkScheduleDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSave?: () => void;
  initialDate?: Date;
  className?: string;
}

export const WorkScheduleDialog: React.FC<WorkScheduleDialogProps> = ({
  isOpen,
  onClose,
  onSave,
  initialDate,
  className
}) => {


  return (
    <Dialog 
      open={isOpen} 
      onOpenChange={(open) => {
        if (!open) {
          onClose();
        }
      }}
    >
      <DialogContent className={`${styles.dialogContent} ${className || ""}`}>
        <DialogHeader>
          <DialogTitle className={styles.dialogTitle}>
            <CalendarIcon className={styles.calendarIcon} />
            Work Schedule
          </DialogTitle>
          <DialogDescription>
            Set your work schedule to help with task planning and time management.
          </DialogDescription>
        </DialogHeader>
        
        <div className={styles.editorContainer}>
          <WorkScheduleEditor 
            onClose={onClose} 
            initialDate={initialDate}
            className={styles.workScheduleEditor}
          />
        </div>
        
        <DialogFooter className={styles.dialogFooter}>
          <Button 
            variant="outline" 
            onClick={onClose}
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};