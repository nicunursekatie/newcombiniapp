import React, { useEffect, useState, useRef } from 'react';
import { Clock, Calendar, Bug } from 'lucide-react';
import { format, isEqual, parseISO, isSameDay } from 'date-fns';
import { useWorkSchedule, WorkDay } from '../helpers/useWorkSchedule';
import { LoadingSpinner } from './LoadingSpinner';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './Tooltip';
import styles from './WorkScheduleOverlay.module.css';

export interface WorkScheduleOverlayProps {
  startDate: Date;
  endDate: Date;
  view: 'month' | 'week' | 'day';
  className?: string;
}

export const WorkScheduleOverlay: React.FC<WorkScheduleOverlayProps> = ({
  startDate,
  endDate,
  view,
  className = '',
}) => {
  const [workDays, setWorkDays] = useState<WorkDay[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { getSchedule } = useWorkSchedule();

  // Debug mode state
  const [debugMode, setDebugMode] = useState(false);
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchWorkSchedule = async () => {
      setIsLoading(true);
      setError(null);
      
      console.log(`[WorkScheduleOverlay] Fetching schedule for range:`, {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        view
      });
      
      try {
        const schedule = await getSchedule(startDate, endDate);
        console.log(`[WorkScheduleOverlay] Fetched ${schedule.length} work days:`, 
          schedule.map(day => ({
            date: day.date.toISOString(),
            type: day.type,
            timeRange: `${day.startTime}-${day.endTime}`
          }))
        );
        setWorkDays(schedule);
      } catch (err) {
        console.error('[WorkScheduleOverlay] Error fetching schedule:', err);
        setError('Failed to load work schedule');
      } finally {
        setIsLoading(false);
      }
    };

    fetchWorkSchedule();
  }, [startDate, endDate, getSchedule]);

  // Debug effect to check DOM for date elements after render
  useEffect(() => {
    if (!debugMode) return;
    
    // Wait for next frame to ensure DOM is updated
    const timeoutId = setTimeout(() => {
      if (view === 'month') {
        const dateElements = document.querySelectorAll('[data-date]');
        console.log(`[WorkScheduleOverlay] Found ${dateElements.length} date elements in DOM:`, 
          Array.from(dateElements).map(el => ({
            date: el.getAttribute('data-date'),
            rect: el.getBoundingClientRect()
          }))
        );
        
        // Check if our overlay indicators are positioned correctly
        const indicators = document.querySelectorAll(`.${styles.monthIndicatorWrapper}`);
        console.log(`[WorkScheduleOverlay] Found ${indicators.length} month indicators:`,
          Array.from(indicators).map(el => ({
            date: el.getAttribute('data-date'),
            rect: el.getBoundingClientRect(),
            visible: isElementVisible(el as HTMLElement)
          }))
        );
      }
    }, 100);
    
    return () => clearTimeout(timeoutId);
  }, [workDays, view, debugMode]);

  // Helper to check if a date has a work schedule
  const getWorkDayForDate = (date: Date): WorkDay | undefined => {
    const workDay = workDays.find(workDay => 
      isEqual(
        new Date(workDay.date.getFullYear(), workDay.date.getMonth(), workDay.date.getDate()),
        new Date(date.getFullYear(), date.getMonth(), date.getDate())
      )
    );
    
    if (debugMode && workDay) {
      console.log(`[WorkScheduleOverlay] Found work day for ${date.toISOString()}:`, {
        type: workDay.type,
        timeRange: `${workDay.startTime}-${workDay.endTime}`
      });
    }
    
    return workDay;
  };
  
  // Helper to check if an element is visible in the viewport
  const isElementVisible = (element: HTMLElement): boolean => {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  };

  // Helper to format time range for display
  const formatTimeRange = (startTime: string, endTime: string): string => {
    try {
      return `${format(new Date(`2000-01-01T${startTime}`), 'h:mm a')} - ${format(new Date(`2000-01-01T${endTime}`), 'h:mm a')}`;
    } catch (error) {
      return `${startTime} - ${endTime}`;
    }
  };

  // Render month view indicators (dots or small bars)
  const renderMonthIndicator = (date: Date) => {
    const workDay = getWorkDayForDate(date);
    if (!workDay) return null;

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`${styles.monthIndicator} ${styles[workDay.type]}`} style={{ pointerEvents: 'auto' }}>
              <Clock size={12} className={styles.monthIndicatorIcon} />
              <span className={styles.screenReaderText}>
                Work scheduled: {workDay.type} shift
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <div className={styles.tooltipContent}>
              <Clock size={14} className={styles.tooltipIcon} />
              <span>
                {workDay.type === 'full' ? 'Full day' : workDay.type === 'morning' ? 'Morning shift' : 'Afternoon shift'}
                <br />
                {formatTimeRange(workDay.startTime, workDay.endTime)}
              </span>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  };

  // Render week view indicators (background color for the day column)
  const renderWeekIndicator = (date: Date) => {
    const workDay = getWorkDayForDate(date);
    if (!workDay) return null;

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`${styles.weekIndicator} ${styles[workDay.type]}`}>
              <div className={styles.weekIndicatorContent}>
                <Clock size={16} className={styles.weekIndicatorIcon} />
                <span className={styles.weekIndicatorLabel}>
                  {workDay.type === 'full' ? 'Full day' : 
                   workDay.type === 'morning' ? 'Morning' : 
                   'Afternoon'}
                </span>
              </div>
              <span className={styles.screenReaderText}>
                Work scheduled: {workDay.type} shift
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <div className={styles.tooltipContent}>
              <Calendar size={14} className={styles.tooltipIcon} />
              <span>
                {format(date, 'EEEE, MMMM d')}
                <br />
                <Clock size={14} className={styles.tooltipIcon} style={{marginTop: '4px'}} />
                {workDay.type === 'full' ? 'Full day' : workDay.type === 'morning' ? 'Morning shift' : 'Afternoon shift'}
                <br />
                {formatTimeRange(workDay.startTime, workDay.endTime)}
              </span>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  };

  // Render day view indicators (detailed time blocks)
  const renderDayIndicator = (date: Date) => {
    const workDay = getWorkDayForDate(date);
    if (!workDay) return null;

    return (
      <div className={`${styles.dayIndicator} ${styles[workDay.type]}`}>
        <div className={styles.dayIndicatorHeader}>
          <Clock size={18} className={styles.dayIndicatorIcon} />
          <span className={styles.dayIndicatorTitle}>
            {workDay.type === 'full' ? 'Full Day Work Schedule' : 
             workDay.type === 'morning' ? 'Morning Work Schedule' : 
             'Afternoon Work Schedule'}
          </span>
        </div>
        <div className={styles.dayIndicatorTime}>
          {formatTimeRange(workDay.startTime, workDay.endTime)}
        </div>
        <div className={styles.dayIndicatorDescription}>
          {workDay.type === 'full' 
            ? 'You have a full day work schedule today (7am-7pm).' 
            : workDay.type === 'morning' 
              ? 'You have a morning work schedule today (7am-1pm).'
              : 'You have an afternoon work schedule today (1pm-7pm).'}
        </div>
      </div>
    );
  };

  // Generate an array of dates for the current view
  const getDatesInView = (): Date[] => {
    const dates: Date[] = [];
    let currentDate = new Date(startDate);
    
    while (currentDate <= endDate) {
      dates.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }
    
    if (debugMode) {
      console.log(`[WorkScheduleOverlay] Generated ${dates.length} dates in view:`, 
        dates.map(d => format(d, 'yyyy-MM-dd'))
      );
    }
    
    return dates;
  };
  
  // Debug function to find date elements in DOM
  const findDateElementsInDOM = () => {
    const dateElements = document.querySelectorAll('[data-date]');
    console.log(`[WorkScheduleOverlay] Found ${dateElements.length} date elements in DOM`);
    
    // Check for each work day if there's a matching DOM element
    workDays.forEach(workDay => {
      const dateStr = format(workDay.date, 'yyyy-MM-dd');
      const matchingElement = document.querySelector(`[data-date="${dateStr}"]`);
      console.log(`[WorkScheduleOverlay] Work day ${dateStr} (${workDay.type}): matching element exists: ${!!matchingElement}`, 
        matchingElement ? {
          rect: matchingElement.getBoundingClientRect(),
          parent: matchingElement.parentElement?.tagName
        } : 'No matching element'
      );
    });
    
    // Log overlay position and dimensions
    if (overlayRef.current) {
      console.log(`[WorkScheduleOverlay] Overlay position:`, {
        rect: overlayRef.current.getBoundingClientRect(),
        style: {
          position: window.getComputedStyle(overlayRef.current).position,
          zIndex: window.getComputedStyle(overlayRef.current).zIndex
        }
      });
    }
  };



  if (isLoading) {
    return (
      <div className={`${styles.loadingContainer} ${className}`}>
        <LoadingSpinner size="md" />
        <p className={styles.debugText}>Loading work schedule...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`${styles.errorContainer} ${className}`}>
        <p className={styles.errorMessage}>{error}</p>
        <button 
          className={styles.debugButton}
          onClick={() => console.log('[WorkScheduleOverlay] Current state:', { workDays, startDate, endDate, view })}
        >
          Debug Error
        </button>
      </div>
    );
  }

  // Render based on view type
  if (view === 'month') {
    const datesInView = getDatesInView();
    const datesWithSchedule = datesInView.filter(date => getWorkDayForDate(date));
    
    if (debugMode) {
      console.log(`[WorkScheduleOverlay] Month view rendering: ${datesWithSchedule.length}/${datesInView.length} dates have schedules`);
    }
    
    return (
      <div 
        ref={overlayRef}
        className={`${styles.monthOverlay} ${className}`} 
        data-testid="work-schedule-month-overlay"
      >
        {datesInView.map((date, index) => {
          const workDay = getWorkDayForDate(date);
          if (!workDay) return null;
          
          const dateStr = format(date, 'yyyy-MM-dd');
          if (debugMode) {
            console.log(`[WorkScheduleOverlay] Rendering indicator for ${dateStr} (${workDay.type})`);
            
            // Check if there's a matching date element in the DOM
            setTimeout(() => {
              const dateElement = document.querySelector(`[data-date="${dateStr}"]`);
              console.log(`[WorkScheduleOverlay] Date element for ${dateStr} exists: ${!!dateElement}`);
            }, 0);
          }
          
          // Find the corresponding date element in the DOM
          const dateElement = document.querySelector(`[data-date="${dateStr}"]`);
          if (!dateElement && debugMode) {
            console.log(`[WorkScheduleOverlay] No DOM element found for date ${dateStr}`);
            return null;
          }
          
          // Position the indicator based on the date element
          let style = {};
          if (dateElement) {
            const rect = dateElement.getBoundingClientRect();
            const containerRect = overlayRef.current?.getBoundingClientRect();
            if (containerRect) {
              style = {
                position: 'absolute',
                top: `${rect.top - containerRect.top + 4}px`,
                left: `${rect.right - containerRect.left - 30}px`,
                width: '24px',
                height: '24px',
                zIndex: 'var(--z-overlay-low)'
              };
            }
          }
          
          return (
            <div 
              key={`month-indicator-${dateStr}`}
              className={styles.monthIndicatorWrapper}
              data-date={dateStr}
              data-schedule-type={workDay.type}
              style={style as React.CSSProperties}
            >
              {renderMonthIndicator(date)}
            </div>
          );
        })}
        
        {/* Debug controls */}
        <div className={styles.debugControls}>
          <button 
            className={styles.debugButton}
            onClick={() => setDebugMode(!debugMode)}
            title="Toggle debug mode"
          >
            <Bug size={16} />
            {debugMode ? 'Disable Debug' : 'Debug'}
          </button>
          
          {debugMode && (
            <>
              <button 
                className={styles.debugButton}
                onClick={findDateElementsInDOM}
                title="Find date elements in DOM"
              >
                Find Elements
              </button>
              <div className={styles.debugInfo}>
                <p>Work Days: {workDays.length}</p>
                <p>Dates with Schedule: {datesWithSchedule.length}/{datesInView.length}</p>
                <p>View: {view}</p>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  if (view === 'week') {
    const datesInView = getDatesInView();
    const datesWithSchedule = datesInView.filter(date => getWorkDayForDate(date));
    
    if (debugMode) {
      console.log(`[WorkScheduleOverlay] Week view rendering: ${datesWithSchedule.length}/${datesInView.length} dates have schedules`);
    }
    
    return (
      <div 
        ref={overlayRef}
        className={`${styles.weekOverlay} ${className}`} 
        data-testid="work-schedule-week-overlay"
      >
        {datesInView.map((date, index) => {
          const workDay = getWorkDayForDate(date);
          if (!workDay) return null;
          
          const dateStr = format(date, 'yyyy-MM-dd');
          if (debugMode) {
            console.log(`[WorkScheduleOverlay] Rendering week indicator for ${dateStr} (${workDay.type})`);
          }
          
          return (
            <div 
              key={`week-indicator-${dateStr}`}
              className={styles.weekIndicatorWrapper}
              data-date={dateStr}
              data-schedule-type={workDay.type}
            >
              {renderWeekIndicator(date)}
            </div>
          );
        })}
        
        {/* Debug controls */}
        {debugMode && (
          <div className={styles.debugControls}>
            <button 
              className={styles.debugButton}
              onClick={() => setDebugMode(false)}
            >
              <Bug size={16} />
              Disable Debug
            </button>
            <div className={styles.debugInfo}>
              <p>Work Days: {workDays.length}</p>
              <p>Dates with Schedule: {datesWithSchedule.length}/{datesInView.length}</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Day view
  const workDay = getWorkDayForDate(startDate);
  
  if (debugMode) {
    console.log(`[WorkScheduleOverlay] Day view rendering for ${format(startDate, 'yyyy-MM-dd')}:`, 
      workDay ? { type: workDay.type, timeRange: `${workDay.startTime}-${workDay.endTime}` } : 'No schedule'
    );
  }
  
  return (
    <div 
      ref={overlayRef}
      className={`${styles.dayOverlay} ${className}`} 
      data-testid="work-schedule-day-overlay"
      data-date={format(startDate, 'yyyy-MM-dd')}
    >
      {workDay ? renderDayIndicator(startDate) : (
        debugMode && (
          <div className={styles.debugNoSchedule}>
            <p>No work schedule for this day</p>
            <p>Date: {format(startDate, 'yyyy-MM-dd')}</p>
          </div>
        )
      )}
      
      {/* Debug controls */}
      <div className={styles.debugControls}>
        <button 
          className={styles.debugButton}
          onClick={() => setDebugMode(!debugMode)}
          title="Toggle debug mode"
        >
          <Bug size={16} />
          {debugMode ? 'Disable Debug' : 'Debug'}
        </button>
        
        {debugMode && (
          <div className={styles.debugInfo}>
            <p>Date: {format(startDate, 'yyyy-MM-dd')}</p>
            <p>Has Schedule: {workDay ? 'Yes' : 'No'}</p>
            {workDay && <p>Type: {workDay.type}</p>}
          </div>
        )}
      </div>
    </div>
  );
};