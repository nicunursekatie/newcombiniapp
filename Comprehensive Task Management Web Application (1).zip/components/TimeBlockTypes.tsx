export interface TimeBlock {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  date: string;
  taskId?: string | null;
  tasks?: { id: string }[];
}

export interface ExtendedTimeBlock extends TimeBlock {
  // Any additional properties that might be added in the future
}