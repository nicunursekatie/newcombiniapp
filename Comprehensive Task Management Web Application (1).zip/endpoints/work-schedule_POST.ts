import { db } from "../helpers/db";
import { workSchedule } from "../helpers/schema";
import { schema } from "./work-schedule_POST.schema";
import { eq } from "drizzle-orm";

export async function handle(request: Request) {
  console.log("Handling work-schedule POST request");
  
  try {
    // Parse the request body
    const json = await request.json();
    console.log("Request body:", json);
    
    // Validate the request body using the schema
    const validatedData = schema.parse(json);
    console.log("Validated data:", validatedData);
    
    const { action, date } = validatedData;
    
    // Handle different actions
    switch (action) {
      case "add":
      case "update": {
        // For add/update actions, scheduleType will be present
        const { scheduleType } = validatedData;
        console.log(`${action === "add" ? "Adding" : "Updating"} work schedule for date ${date}`);
        
        // Check if the entry already exists
        const existingEntry = await db
          .select()
          .from(workSchedule)
          .where(eq(workSchedule.date, date));
        
        console.log("Existing entry:", existingEntry);
        
        if (existingEntry.length > 0) {
          // Update existing entry
          console.log(`Updating existing entry for date ${date} to ${scheduleType}`);
          await db
            .update(workSchedule)
            .set({ scheduleType })
            .where(eq(workSchedule.date, date));
        } else {
          // Insert new entry
          console.log(`Inserting new entry for date ${date} with type ${scheduleType}`);
          await db
            .insert(workSchedule)
            .values({ date, scheduleType });
        }
        
        // Return the updated/added entry
        return Response.json({
          date,
          scheduleType
        });
      }
      
      case "delete": {
        console.log(`Deleting work schedule for date ${date}`);
        
        // Delete the entry
        await db
          .delete(workSchedule)
          .where(eq(workSchedule.date, date));
        
        return Response.json({
          success: true,
          message: `Work schedule for ${date} has been deleted`
        });
      }
      
      default:
        console.error(`Invalid action: ${action}`);
        return Response.json(
          { error: "Invalid action", message: `Action '${action}' is not supported` },
          { status: 400 }
        );
    }
  } catch (error: unknown) {
    console.error("Error processing work schedule request:", error);
    
    // Return appropriate error response
    if (error instanceof Error) {
      if (error.name === "ZodError") {
        return Response.json(
          { error: "Invalid request data", details: (error as any).errors },
          { status: 400 }
        );
      }
      
      return Response.json(
        { error: "Failed to process work schedule request", message: error.message },
        { status: 500 }
      );
    }
    
    return Response.json(
      { error: "Failed to process work schedule request", message: "Unknown error" },
      { status: 500 }
    );
  }
}