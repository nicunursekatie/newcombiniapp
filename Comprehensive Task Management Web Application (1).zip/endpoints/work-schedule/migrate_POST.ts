import { db } from "../../helpers/db";
import { workSchedule } from "../../helpers/schema";
import { sql } from "drizzle-orm";
import { schema } from "./migrate_POST.schema";

export async function handle(request: Request) {
  console.log("Starting work schedule migration endpoint");
  
  try {
    // Parse the request body
    const body = await request.json();
    schema.parse(body);
    
    console.log("Request validated, proceeding with migration");
    
    try {
      // Check if the table exists
      console.log("Checking if work_schedule table exists");
      const tableExists = await db.execute(sql`
        SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_schema = 'public' 
          AND table_name = 'work_schedule'
        );
      `);
      
      console.log("Table exists check result:", tableExists);
      
      if (!tableExists[0]?.exists) {
        console.log("Table doesn't exist, creating work_schedule table");
        
        // Create the table if it doesn't exist
        await db.execute(sql`
          CREATE TABLE IF NOT EXISTS work_schedule (
            date DATE PRIMARY KEY NOT NULL,
            schedule_type VARCHAR(20) NOT NULL CHECK (
              schedule_type IN ('full_day', 'morning', 'afternoon')
            )
          );
        `);
        
        console.log("work_schedule table created successfully");
      } else {
        console.log("work_schedule table already exists");
        
        // Verify the schema is correct
        console.log("Verifying table schema");
        
        // Check if the schedule_type column has the correct constraint
        const checkConstraintExists = await db.execute(sql`
          SELECT EXISTS (
            SELECT FROM information_schema.check_constraints
            WHERE constraint_name = 'work_schedule_schedule_type_check'
          );
        `);
        
        console.log("Check constraint exists result:", checkConstraintExists);
        
        if (!checkConstraintExists[0]?.exists) {
          console.log("Adding missing check constraint to schedule_type column");
          
          await db.execute(sql`
            ALTER TABLE work_schedule 
            ADD CONSTRAINT work_schedule_schedule_type_check 
            CHECK (schedule_type IN ('full_day', 'morning', 'afternoon'));
          `);
          
          console.log("Check constraint added successfully");
        }
      }
      
      // Verify we can insert and query data
      console.log("Testing table functionality with a sample operation");
      
      // Insert a test record
      const testDate = new Date();
      testDate.setHours(0, 0, 0, 0); // Normalize to start of day
      
      // Format date as ISO string (YYYY-MM-DD) for PostgreSQL
      const formattedDate = testDate.toISOString().split('T')[0];
      
      await db.insert(workSchedule)
        .values({
          date: formattedDate,
          scheduleType: 'full_day'
        })
        .onConflictDoUpdate({
          target: workSchedule.date,
          set: { scheduleType: 'full_day' }
        });
      
      // Query to verify
      const result = await db.select()
        .from(workSchedule)
        .where(sql`date = ${formattedDate}`);
      
      console.log("Test query result:", result);
      
      // Delete the test record
      await db.delete(workSchedule)
        .where(sql`date = ${formattedDate}`);
      
      console.log("Migration completed successfully");
      
      return Response.json({ 
        success: true, 
        message: "Work schedule table migration completed successfully" 
      });
      
    } catch (dbError) {
      console.error("Database error during migration:", dbError);
      return Response.json({ 
        success: false, 
        message: "Database error during migration", 
        error: dbError instanceof Error ? dbError.message : String(dbError) 
      }, { status: 500 });
    }
    
  } catch (error) {
    console.error("Error processing request:", error);
    return Response.json({ 
      success: false, 
      message: "Invalid request", 
      error: error instanceof Error ? error.message : String(error) 
    }, { status: 400 });
  }
}