import { z } from "zod";

// Simple schema since this is an admin operation with no required inputs
export const schema = z.object({
  // Empty object - no inputs required for this migration endpoint
});

export type OutputType = {
  success: boolean;
  message: string;
  error?: string;
};

export const postWorkScheduleMigrate = async (
  body: z.infer<typeof schema> = {}, 
  init?: RequestInit
): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  
  const result = await fetch(`/_api/work-schedule/migrate`, {
    method: "POST",
    body: JSON.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  return result.json();
};