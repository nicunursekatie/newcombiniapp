import { z } from "zod";

// Define the base schema
const baseSchema = z.object({
  action: z.enum(["add", "update", "delete"]),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, {
    message: "Date must be in YYYY-MM-DD format"
  })
});

// Define the schema for add and update actions
const addUpdateSchema = baseSchema.extend({
  action: z.enum(["add", "update"]),
  scheduleType: z.enum(["full_day", "morning", "afternoon"])
});

// Define the schema for delete action
const deleteSchema = baseSchema.extend({
  action: z.literal("delete")
});

// Combine the schemas using discriminated union
export const schema = z.discriminatedUnion("action", [
  addUpdateSchema,
  deleteSchema
]);

// Define the output types
export type AddUpdateOutputType = {
  date: string;
  scheduleType: 'full_day' | 'morning' | 'afternoon';
};

export type DeleteOutputType = {
  success: boolean;
  message: string;
};

export type OutputType = AddUpdateOutputType | DeleteOutputType;

// Client request helper function
export const postWorkSchedule = async (
  body: z.infer<typeof schema>,
  init?: RequestInit
): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  
  const result = await fetch(`/_api/work-schedule`, {
    method: "POST",
    body: JSON.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorData = await result.json();
    throw new Error(errorData.message || 'Failed to update work schedule');
  }
  
  return result.json();
};