import { db } from "../../helpers/db";
import { projects } from "../../helpers/schema";
import { schema } from "./reorder_POST.schema";
import { eq, inArray } from "drizzle-orm";

export async function handle(request: Request) {
  try {
    const json = await request.json();
    const { projectIds } = schema.parse(json);

    // Validate that all project IDs exist
    const existingProjects = await db.select({ id: projects.id })
      .from(projects)
      .where(
        inArray(projects.id, projectIds)
      );

    // Check if all provided project IDs exist in the database
    if (existingProjects.length !== projectIds.length) {
      const existingIds = new Set(existingProjects.map(p => p.id));
      const missingIds = projectIds.filter(id => !existingIds.has(id));
      return Response.json(
        { error: `The following project IDs do not exist: ${missingIds.join(', ')}` },
        { status: 400 }
      );
    }

    // Update the position of each project based on its index in the projectIds array
    const updatePromises = projectIds.map((projectId, index) => {
      return db.update(projects)
        .set({ position: index })
        .where(eq(projects.id, projectId));
    });

    await Promise.all(updatePromises);

    return Response.json({ success: true });
  } catch (error) {
    console.error("Error reordering projects:", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "Failed to reorder projects" },
      { status: 400 }
    );
  }
}