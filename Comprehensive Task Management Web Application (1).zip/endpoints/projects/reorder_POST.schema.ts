import { z } from "zod";

export const schema = z.object({
  projectIds: z.array(z.string())
    .min(1, "At least one project ID is required")
    .describe("Array of project IDs in their new order")
});

export type OutputType = {
  success: boolean;
  error?: string;
};

export const postProjectsReorder = async (
  body: z.infer<typeof schema>,
  init?: RequestInit
): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/projects/reorder`, {
    method: "POST",
    body: JSON.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  return result.json();
};