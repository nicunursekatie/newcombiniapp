import { db } from "../../helpers/db";
import { tasks } from "../../helpers/schema";
import { schema } from "./archive_POST.schema";
import { eq, and } from "drizzle-orm";

export async function handle(request: Request) {
  try {
    // Parse the request body
    const json = await request.json();
    const validatedData = schema.parse(json);
    
    // Update all completed tasks to be archived
    const result = await db.update(tasks)
      .set({ archived: true })
      .where(
        and(
          eq(tasks.status, "completed"),
          eq(tasks.archived, false)
        )
      )
      .returning();
    
    // Return the number of tasks that were archived
    return Response.json({ 
      archivedCount: result.length,
      message: `Successfully archived ${result.length} completed tasks`
    });
    
  } catch (error: unknown) {
    console.error("Error archiving tasks:", error);
    return Response.json(
      { 
        message: "Failed to archive completed tasks", 
        error: error instanceof Error ? error.message : String(error) 
      },
      { status: 400 }
    );
  }
}