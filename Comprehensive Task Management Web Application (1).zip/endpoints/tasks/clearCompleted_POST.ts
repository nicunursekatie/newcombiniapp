import { db } from "../../helpers/db";
import { tasks } from "../../helpers/schema";
import { eq } from "drizzle-orm";
import { schema } from "./clearCompleted_POST.schema";

export async function handle(request: Request) {
  try {
    // Validate the request body against the schema
    const body = await request.json();
    schema.parse(body);

    // Update all tasks with status 'completed' to have status 'deleted'
    const result = await db
      .update(tasks)
      .set({ status: 'deleted' })
      .where(eq(tasks.status, 'completed'))
      .returning({ id: tasks.id });

    return Response.json({
      success: true,
      message: `${result.length} completed tasks marked as deleted`,
      tasksAffected: result.length,
      taskIds: result.map(task => task.id)
    });
  } catch (error) {
    console.error("Error clearing completed tasks:", error);
    return Response.json(
      { 
        success: false, 
        message: error instanceof Error ? error.message : "An unknown error occurred" 
      }, 
      { status: 400 }
    );
  }
}