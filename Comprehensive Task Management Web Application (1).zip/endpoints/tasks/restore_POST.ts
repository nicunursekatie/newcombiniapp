import { db } from "../../helpers/db";
import { tasks } from "../../helpers/schema";
import { schema } from "./restore_POST.schema";
import { eq, inArray } from "drizzle-orm";

export async function handle(request: Request) {
  try {
    // Parse and validate the request body
    const json = await request.json();
    const validatedData = schema.parse(json);
    
    // Ensure we have task IDs to restore
    if (validatedData.taskIds.length === 0) {
      return Response.json({ 
        restoredCount: 0,
        message: "No task IDs provided for restoration" 
      });
    }
    
    // Update the archived flag to false for the specified tasks
    const result = await db.update(tasks)
      .set({ archived: false })
      .where(
        inArray(tasks.id, validatedData.taskIds)
      )
      .returning();
    
    // Return the number of tasks that were restored
    return Response.json({ 
      restoredCount: result.length,
      message: `Successfully restored ${result.length} tasks`
    });
    
  } catch (error: unknown) {
    console.error("Error restoring tasks:", error);
    return Response.json(
      { 
        message: "Failed to restore tasks", 
        error: error instanceof Error ? error.message : String(error) 
      },
      { status: 400 }
    );
  }
}