import { z } from "zod";

export const schema = z.object({
  taskIds: z.array(z.string()).min(1, "At least one task ID must be provided")
});

export type OutputType = {
  restoredCount: number;
  message: string;
};

export const postTasksRestore = async (body: z.infer<typeof schema>, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/tasks/restore`, {
    method: "POST",
    body: JSON.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorData = await result.json();
    throw new Error(errorData.message || "Failed to restore tasks");
  }
  
  return result.json();
};