import { z } from "zod";

// Simple schema for the archive endpoint - no input required
export const schema = z.object({});

export type OutputType = {
  archivedCount: number;
  message: string;
};

export const postTasksArchive = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch(`/_api/tasks/archive`, {
    method: "POST",
    body: JSON.stringify({}),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorData = await result.json();
    throw new Error(errorData.message || "Failed to archive completed tasks");
  }
  
  return result.json();
};