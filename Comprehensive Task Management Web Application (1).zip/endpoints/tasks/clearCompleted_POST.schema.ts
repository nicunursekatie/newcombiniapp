import { z } from "zod";

// Empty schema since this endpoint doesn't require any input parameters
export const schema = z.object({});

export type OutputType = {
  success: boolean;
  message: string;
  tasksAffected?: number;
  taskIds?: string[];
};

export const postClearCompleted = async (body: z.infer<typeof schema> = {}, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/tasks/clearCompleted`, {
    method: "POST",
    body: JSON.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  return result.json();
};