import { z } from "zod";

// Define the schema for request validation
export const schema = z.object({
  startDate: z.string()
    .refine((val) => !isNaN(Date.parse(val)), {
      message: "startDate must be a valid date string"
    }),
  endDate: z.string()
    .refine((val) => !isNaN(Date.parse(val)), {
      message: "endDate must be a valid date string"
    })
}).refine((data) => {
  const start = new Date(data.startDate);
  const end = new Date(data.endDate);
  return end >= start;
}, {
  message: "endDate must be greater than or equal to startDate",
  path: ["endDate"]
});

// Define the output type
export type OutputType = Array<{
  date: string;
  scheduleType: 'full_day' | 'morning' | 'afternoon';
}>;

// Client request helper function
export const getWorkSchedule = async (
  params: z.infer<typeof schema>,
  init?: RequestInit
): Promise<OutputType> => {
  const validatedParams = schema.parse(params);
  
  // Build URL with query parameters
  const url = new URL('/_api/work-schedule', window.location.origin);
  url.searchParams.append('startDate', validatedParams.startDate);
  url.searchParams.append('endDate', validatedParams.endDate);
  
  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      ...init?.headers,
    },
  });
  
  if (!result.ok) {
    const errorData = await result.json();
    throw new Error(errorData.message || 'Failed to fetch work schedule');
  }
  
  return result.json();
};