import { db } from "../../helpers/db";
import { timeBlocks, timeBlockTasks } from "../../helpers/schema";
import { schema } from "./delete_POST.schema";
import { eq } from "drizzle-orm";

export async function handle(request: Request) {
  try {
    const json = await request.json();
    const { id } = schema.parse(json);

    // Check if the time block exists before attempting to delete
    const existingTimeBlock = await db.query.timeBlocks.findFirst({
      where: eq(timeBlocks.id, id)
    });

    if (!existingTimeBlock) {
      return Response.json(
        { error: `Time block with ID ${id} not found` },
        { status: 404 }
      );
    }

    // Delete the time block tasks relationships first
    // Note: This is technically redundant due to cascade delete in the database,
    // but we're doing it explicitly for code clarity and to ensure proper cleanup
    await db.delete(timeBlockTasks).where(eq(timeBlockTasks.timeBlockId, id));

    // Delete the time block
    await db.delete(timeBlocks).where(eq(timeBlocks.id, id));

    return Response.json({ success: true, message: "Time block deleted successfully" });
  } catch (error) {
    console.error("Error deleting time block:", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "Unknown error occurred" },
      { status: 400 }
    );
  }
}