import { z } from "zod";

export const schema = z.object({
  id: z.string().min(1, "Time block ID is required")
});

export type OutputType = {
  success: boolean;
  message: string;
} | {
  error: string;
};

export const postTimeBlocksDelete = async (
  body: z.infer<typeof schema>,
  init?: RequestInit
): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  
  const result = await fetch(`/_api/timeBlocks/delete`, {
    method: "POST",
    body: JSON.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorData = await result.json();
    throw new Error(errorData.error || "Failed to delete time block");
  }
  
  return result.json();
};