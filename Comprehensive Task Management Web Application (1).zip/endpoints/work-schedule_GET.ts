import { db } from "../helpers/db";
import { workSchedule } from "../helpers/schema";
import { schema } from "./work-schedule_GET.schema";
import { eq, and, gte, lte } from "drizzle-orm";

export async function handle(request: Request) {
  console.log("Handling work-schedule GET request");
  
  try {
    // Parse URL to get query parameters
    const url = new URL(request.url);
    const startDate = url.searchParams.get("startDate");
    const endDate = url.searchParams.get("endDate");
    
    console.log(`Request parameters - startDate: ${startDate}, endDate: ${endDate}`);
    
    // Validate query parameters using the schema
    const validatedParams = schema.parse({ startDate, endDate });
    console.log("Parameters validated successfully");
    
    // Format dates for PostgreSQL (YYYY-MM-DD)
    const start = validatedParams.startDate;
    const end = validatedParams.endDate;
    
    console.log(`Querying work schedules between ${start} and ${end}`);
    
    // Query the database for work schedules within the date range
    const schedules = await db
      .select()
      .from(workSchedule)
      .where(
        and(
          gte(workSchedule.date, start),
          lte(workSchedule.date, end)
        )
      )
      .orderBy(workSchedule.date);
    
    console.log(`Found ${schedules.length} work schedule entries`);
    
    // Format the response
    const formattedSchedules = schedules.map(schedule => ({
      date: schedule.date, // Already in YYYY-MM-DD format
      scheduleType: schedule.scheduleType
    }));
    
    console.log("Returning formatted work schedules");
    return Response.json(formattedSchedules);
  } catch (error: unknown) {
    console.error("Error processing work schedule request:", error);
    
    // Return appropriate error response
    if (error instanceof Error) {
      if (error.name === "ZodError") {
        return Response.json(
          { error: "Invalid request parameters", details: (error as any).errors },
          { status: 400 }
        );
      }
      
      return Response.json(
        { error: "Failed to retrieve work schedules", message: error.message },
        { status: 500 }
      );
    }
    
    return Response.json(
      { error: "Failed to retrieve work schedules", message: "Unknown error" },
      { status: 500 }
    );
  }
}