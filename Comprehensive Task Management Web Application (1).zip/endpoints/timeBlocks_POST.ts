import { db } from "../helpers/db";
import { timeBlocks, timeBlockTasks } from "../helpers/schema";
import { schema } from "./timeBlocks_POST.schema";
import { v4 as uuidv4 } from "uuid";
import { eq, and } from "drizzle-orm";

export async function handle(request: Request) {
  try {
    const json = await request.json();
    const validatedData = schema.parse(json);
    
    // Check if we're updating an existing time block or creating a new one
    if (validatedData.id) {
      // Update existing time block
      const existingTimeBlock = await db.query.timeBlocks.findFirst({
        where: eq(timeBlocks.id, validatedData.id)
      });
      
      if (!existingTimeBlock) {
        return Response.json(
          { error: `Time block with ID ${validatedData.id} not found` },
          { status: 404 }
        );
      }
      
      // Update the time block
      const updatedTimeBlock = await db
        .update(timeBlocks)
        .set({
          title: validatedData.title,
          startTime: validatedData.startTime,
          endTime: validatedData.endTime,
          date: validatedData.date,
          taskId: validatedData.taskId === null ? null : validatedData.taskId || null
        })
        .where(eq(timeBlocks.id, validatedData.id))
        .returning();
      
      // Handle task associations
      if (validatedData.taskIds && validatedData.taskIds.length > 0) {
        // First, remove existing associations
        await db
          .delete(timeBlockTasks)
          .where(eq(timeBlockTasks.timeBlockId, validatedData.id));
        
        // Then, add new associations
        const timeBlockTasksData = validatedData.taskIds.map(taskId => ({
          timeBlockId: validatedData.id!,
          taskId
        }));
        
        await db
          .insert(timeBlockTasks)
          .values(timeBlockTasksData);
      } else if (validatedData.taskId) {
        // Handle single taskId for backward compatibility
        // First, remove existing associations
        await db
          .delete(timeBlockTasks)
          .where(eq(timeBlockTasks.timeBlockId, validatedData.id));
        
        // Then, add the single task association
        await db
          .insert(timeBlockTasks)
          .values({
            timeBlockId: validatedData.id,
            taskId: validatedData.taskId
          });
      }
      
      // Fetch the updated time block with its tasks
      const timeBlockWithTasks = await db.query.timeBlocks.findFirst({
        where: eq(timeBlocks.id, validatedData.id),
        with: {
          task: true, // Keep for backward compatibility
          timeBlockTasks: {
            with: {
              task: true
            }
          }
        }
      });
      
      // Transform the result to include the tasks array
      const tasks = timeBlockWithTasks?.timeBlockTasks?.map(tbt => ({
        id: tbt.task.id,
        title: tbt.task.title
      })) || [];
      
      return Response.json({
        ...timeBlockWithTasks,
        tasks,
        timeBlockTasks: undefined // Remove the timeBlockTasks from the response
      });
      
    } else {
      // Create new time block
      const newTimeBlockId = uuidv4();
      
      const newTimeBlock = await db
        .insert(timeBlocks)
        .values({
          id: newTimeBlockId,
          title: validatedData.title,
          startTime: validatedData.startTime,
          endTime: validatedData.endTime,
          date: validatedData.date,
          taskId: validatedData.taskId === null ? null : validatedData.taskId || null
        })
        .returning();
      
      // Handle task associations
      if (validatedData.taskIds && validatedData.taskIds.length > 0) {
        const timeBlockTasksData = validatedData.taskIds.map(taskId => ({
          timeBlockId: newTimeBlockId,
          taskId
        }));
        
        await db
          .insert(timeBlockTasks)
          .values(timeBlockTasksData);
      } else if (validatedData.taskId) {
        // Handle single taskId for backward compatibility
        await db
          .insert(timeBlockTasks)
          .values({
            timeBlockId: newTimeBlockId,
            taskId: validatedData.taskId
          });
      }
      
      // Fetch the new time block with its tasks
      const timeBlockWithTasks = await db.query.timeBlocks.findFirst({
        where: eq(timeBlocks.id, newTimeBlockId),
        with: {
          task: true, // Keep for backward compatibility
          timeBlockTasks: {
            with: {
              task: true
            }
          }
        }
      });
      
      // Transform the result to include the tasks array
      const tasks = timeBlockWithTasks?.timeBlockTasks?.map(tbt => ({
        id: tbt.task.id,
        title: tbt.task.title
      })) || [];
      
      return Response.json({
        ...timeBlockWithTasks,
        tasks,
        timeBlockTasks: undefined // Remove the timeBlockTasks from the response
      });
    }
  } catch (error) {
    console.error("Error processing time block:", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "Unknown error occurred" },
      { status: 400 }
    );
  }
}